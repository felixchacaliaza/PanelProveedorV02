export interface IStatusField {
  state: "" | "error",
  message: string
}

export interface IStatusFieldForm{
  [key:string]:IStatusField
}
