export interface ILimit{
  min:number,
  max:number
}
