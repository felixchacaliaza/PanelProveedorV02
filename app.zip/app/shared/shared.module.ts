
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { CLoaderDark } from './components/c-loader-dark/c-loader-dark';
import { CommonModule } from '@angular/common';
import { StartService } from './services/start.service';
import { ppelOnlyAddressDirective } from './directives/address.directive';
import { ppelOnlyBusinessNameDirective } from './directives/business-name.directive';
import { ppelOnlyEmailDirective } from './directives/email.directive';

import { ModalService } from './services/modal-service';
import { ClearStorageService } from './services/clear-storage-service';
import { ScreenService } from './services/screen.service';
import { CustomFormValidateService } from './services/custom-form-validate.service';
import { CPDFViewer } from './components/c-pdf-viewer/c-pdf-viewer';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { ppelOnlyRoleDirective } from './directives/role.directive';
import { ppelNotCopyDirective } from './directives/copy.directive';
import { ppelNotCutDirective } from './directives/cut.directive';
import { ppelNotPasteDirective } from './directives/paste.directive';


@NgModule({
    imports: [
        CommonModule,
        PdfViewerModule
    ],
    declarations: [
        CLoaderDark,
        CPDFViewer,
        // Directives
        ppelOnlyAddressDirective,
        ppelOnlyBusinessNameDirective,
        ppelOnlyEmailDirective,
        ppelOnlyRoleDirective,
        ppelNotCopyDirective,
        ppelNotCutDirective,
        ppelNotPasteDirective
    ],
    providers: [
        ClearStorageService,
        CustomFormValidateService,   
        ModalService,
        ScreenService,
        StartService
    ],
    exports: [
        CLoaderDark,
        CPDFViewer,
        // Directives
        ppelOnlyAddressDirective,
        ppelOnlyBusinessNameDirective,
        ppelOnlyEmailDirective,
        ppelOnlyRoleDirective,
        ppelNotCopyDirective,
        ppelNotCutDirective,
        ppelNotPasteDirective
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SharedModule { }
