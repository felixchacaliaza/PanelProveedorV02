import { Directive, HostListener } from "@angular/core";

@Directive({
  selector:'bcp-input[ppelNotPaste], bcp-dropdown-input[ppelNotPaste], bcp-captcha[ppelNotPaste]'
})
export class ppelNotPasteDirective{

  @HostListener('paste', ['$event']) blockPaste(e: KeyboardEvent) {
    e.preventDefault();
  }

}
