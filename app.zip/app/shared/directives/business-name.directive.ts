import { Directive, ElementRef, HostListener, Renderer2, ViewChild } from '@angular/core';

export class OnlyBusinessName {
  currentValue: any;
  lastValue: any;
  regex: RegExp = new RegExp(/^([a-zA-Z0-9 áéíóúÁÉÍÓÚñÑ]|\.|\'|\-|\&)*$/);

  stopPropagation(event: Event, textToEvaluate): void {
    if (!this.isValid(textToEvaluate)) {
      event.preventDefault();
    }
  }

  isValid(textToEvaluate) {
    return this.regex.test(textToEvaluate);
  }
}


@Directive({
  selector: 'bcp-input[ppelOnlyBusinessName]'
})
export class ppelOnlyBusinessNameDirective extends OnlyBusinessName {
  private value: string = "";


  constructor(
    private el: ElementRef,
    private render: Renderer2
  ) {
    super();
  }

  @HostListener('ctrlChange', ['$event']) onCtrlChange(event) {
    this.value = event.detail;
  }

  @HostListener('ctrlBlur') onCtrlBlur() {
    if (this.value.trim()) {
      this.render.setProperty(this.el.nativeElement, 'state', '');
      this.render.setProperty(this.el.nativeElement, 'message', '');
    } else {
      this.render.setProperty(this.el.nativeElement, 'state', 'error');
      this.render.setProperty(this.el.nativeElement, 'message', 'Se necesita llenar este dato')
    }
  }

  @HostListener('ctrlKeyDown',['$event.detail'])
  onCtrlKeyDown(event:KeyboardEvent){
    this.lastValue = this.el.nativeElement.ctrlValue;
  }

  @HostListener('ctrlKeyPress', ['$event.detail'])
  onctrlkeydown(event: KeyboardEvent) {
    this.stopPropagation(event, event.key);
  }

  @HostListener('ctrlInput',['$event.detail'])
  onCtrlInput(event:KeyboardEvent){
    this.currentValue = this.el.nativeElement.ctrlValue;
    if(!this.isValid(this.currentValue)){
      (event.target as HTMLInputElement).value = this.lastValue;
      this.el.nativeElement.ctrlValue = this.lastValue;
    }
  }

}
