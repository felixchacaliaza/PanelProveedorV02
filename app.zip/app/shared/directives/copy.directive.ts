import { Directive, HostListener } from "@angular/core";

@Directive({
  selector:'bcp-input[ppelNotCopy], bcp-dropdown-input[ppelNotCopy], bcp-captcha[ppelNotCopy]'
})
export class ppelNotCopyDirective{

  @HostListener('copy', ['$event']) blockCopy(e: KeyboardEvent) {
    e.preventDefault();
  }

}
