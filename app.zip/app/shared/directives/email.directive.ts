import { Directive, ElementRef, HostListener, Renderer2 } from '@angular/core';

export class OnlyEmail {
  currentValue: any;
  lastValue: any;
  regex: RegExp = new RegExp(/^[a-zA-Z0-9\.\_\@\-]*$/);

  stopPropagation(event: Event, textToEvaluate): void {
    if (!this.isValid(textToEvaluate)) {
      event.preventDefault();
    }
  }

  isValid(textToEvaluate: string) {
    return this.regex.test(textToEvaluate);
  }
}


@Directive({
  selector: 'bcp-input[ppelOnlyEmail]'
})
export class ppelOnlyEmailDirective extends OnlyEmail {


  constructor(
    private el: ElementRef
  ) {
    super();
  }

  @HostListener('ctrlKeyDown', ['$event.detail'])
  onctrlkeydown(event: KeyboardEvent) {
    this.lastValue =this.el.nativeElement.ctrlValue;
  }


  @HostListener('ctrlKeyPress', ['$event.detail'])
  onctrlkeypress(event:KeyboardEvent) {
    this.stopPropagation(event, event.key);
  }

  @HostListener('ctrlInput', ['$event.detail'])
  onctrlinput(event: KeyboardEvent) {
    this.currentValue = this.el.nativeElement.ctrlValue;
    if (!this.isValid(this.currentValue)) {
      (event.target as HTMLInputElement).value = this.lastValue;
      this.el.nativeElement.ctrlValue = this.lastValue; 
    } 
  }
}
