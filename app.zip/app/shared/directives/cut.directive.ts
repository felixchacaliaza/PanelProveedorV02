import { Directive, HostListener } from "@angular/core";

@Directive({
  selector:'bcp-input[ppelNotCut], bcp-dropdown-input[ppelNotCut], bcp-captcha[ppelNotCut]'
})
export class ppelNotCutDirective{

  @HostListener('cut', ['$event']) blockCut(e: KeyboardEvent) {
    e.preventDefault();
  }

}
