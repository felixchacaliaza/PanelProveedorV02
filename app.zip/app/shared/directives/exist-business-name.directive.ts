import { Injectable } from "@angular/core";
import { AsyncValidator, AbstractControl, ValidationErrors } from '@angular/forms';
import { CurrentAccountsHttp } from '@src/app/core/http/current-accounts.http';
import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class ExistBusinessName implements AsyncValidator {

    constructor(
        private _currennt: CurrentAccountsHttp
    ) { }

    validate(control: AbstractControl): Promise<ValidationErrors | null> | Observable<ValidationErrors | null> {
        return this._currennt.validateBusinessName(control.value)
            .pipe(map(resp => {
                return null
            }))
            .toPromise()
            .catch(error => of({ invalidName: true }))

    }
}