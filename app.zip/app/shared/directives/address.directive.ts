import { Directive, HostListener, ElementRef, Renderer2, Host } from '@angular/core';

export class OnlyAddress {
  currentValue: any;
  lastValue;
  regex: RegExp = new RegExp(/^([a-zA-Z0-9 ]|\.|\,|\-|ñ|Ñ)*$/);

  stopPropagation(event: Event, textToEvaluate): void {

    if (!this.isValid(textToEvaluate)) {
      event.preventDefault();
    }
  }
  isValid(textToEvaluate) {
    return this.regex.test(textToEvaluate);
  }
}

@Directive({
  selector: 'bcp-input[ppelOnlyAddress]'
})
export class ppelOnlyAddressDirective extends OnlyAddress {
  private value: string = '';
  constructor(
    private el: ElementRef,
    private render: Renderer2
  ) {
    super();
  }

  @HostListener('ctrlChange', ['$event']) onCtrlChange(event) {
    this.value = event.detail;
  }

  @HostListener('ctrlKeyDown',['$event.detail'])
  onCtrlKeyDown(event:KeyboardEvent){
    this.lastValue = this.el.nativeElement.ctrlValue;
  }

  @HostListener('ctrlKeyPress', ['$event.detail'])
  onCtrlKeyPress(event: KeyboardEvent) {
    return this.stopPropagation(event, event.key);
  }

  @HostListener('ctrlInput',['$event.detail'])
  onCtrlInput(event:KeyboardEvent){
    this.currentValue = this.el.nativeElement.ctrlValue;
    if(!this.isValid(this.currentValue)){
      (event.target as HTMLInputElement).value = this.lastValue;
      this.el.nativeElement.ctrlValue = this.lastValue;
    }
  }

}
