import { AbstractControl } from '@angular/forms';

export function ppelSelectAutoComplete(control: AbstractControl) {
  const isCorrect: boolean = control.value.value !== "" && control.value.value !== undefined && control.value.value !== null ? true : false;

  if (!isCorrect) {
    return {
      invalidSelectAutoComplete: true
    }
  }

  return null;

}


