import { BcpValidators } from "@bcp/ng-core-v3/forms";
import { ppelSelectAutoComplete } from "./bcp-select-autocomplete/bcp-select-autocomplete.validator";
import { ppelBusinessNameUseCreateCurrentAccount } from "./business-name/business-name.validator";

export class ppelValidators extends BcpValidators {

  static customSelectAutoComplete = ppelSelectAutoComplete;
  static customBusinessNameUseCreateCurrentAccount = ppelBusinessNameUseCreateCurrentAccount;



}
