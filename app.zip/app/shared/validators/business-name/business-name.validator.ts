import { AsyncValidatorFn, AbstractControl, ValidationErrors, AsyncValidator } from "@angular/forms";
import { CurrentAccountsHttp } from "@src/app/core/http/current-accounts.http";
import { Observable, of } from "rxjs";
import { map, catchError } from "rxjs/operators";
import { resolve } from 'url';
import { HttpErrorResponse } from '@angular/common/http';


export function ppelBusinessNameUseCreateCurrentAccount(_currentAccounstHttp: CurrentAccountsHttp): AsyncValidatorFn {
  return (control: AbstractControl): Promise<Promise<ValidationErrors | null> | Observable<ValidationErrors | null>> => {

    if (!control.value) {
      return new Promise<any>((resolve) => {
        {
          invalidName: true
        }
    });
    } else {
      return _currentAccounstHttp.validateBusinessName(control.value).pipe(map(
        (data) => {
          return null
        }
      )).toPromise().catch((error: HttpErrorResponse) => {
        if(error.status == 409){
          return {
            invalidName: true
          }
        }else{
          return {
            errorValidation: true
          }
        }


      });
    }


  };
}


