
import { CLoaderDark } from './c-loader-dark';

describe("@CLoaderDark", () => {

    let app: CLoaderDark;

    beforeEach(() => {
        app = new CLoaderDark();
    })

    it("SHOULD create the component", () => {
        expect(app).toBeTruthy()
    })

    describe("#ngAfterViewInit", () => {
        it("should open the component progress bar", () => {
            app.progressIndicator = { nativeElement: { open: function () { } } }

            app.ngAfterViewInit()
        })
    })


})