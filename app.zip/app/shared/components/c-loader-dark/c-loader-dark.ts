import { Component, ViewChild, ElementRef, OnInit, AfterViewInit, Input } from "@angular/core";

@Component({
    selector: "c-loader-dark",
    templateUrl: "./c-loader-dark.html",
    styleUrls: ["./c-loader-dark.scss"]
})
export class CLoaderDark implements AfterViewInit {
    @ViewChild('progressIndicator')
    progressIndicator: ElementRef<any>

    @Input() message: string = "Espere un momento por favor";

    ngAfterViewInit() {
       this._openProgressIndicator();
    }

    private _openProgressIndicator():void{
        this.progressIndicator.nativeElement.open();
    }

}