import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from "@angular/core";
import { ScreenService } from '../../services/screen.service';


@Component({
  selector: "c-pdf-viewer",
  templateUrl: "./c-pdf-viewer.html",
  styleUrls: ["./c-pdf-viewer.scss"]
})
export class CPDFViewer implements OnChanges {

  @Input() document: any;
  zoomPdf: number = 1;
  @Input() init = false;
  @Output() onReload = new EventEmitter<any>();


  constructor(private screenSrv: ScreenService) {
    this.updateZoomDocument();

    window.addEventListener("orientationchange", () => {
      setTimeout(() => { this.updateZoomDocument(); }, 0);
    });
    window.addEventListener("resize", () => {
      setTimeout(() => { this.updateZoomDocument(); }, 0);
    })
  }


  ngOnChanges(changes: SimpleChanges) {

    this.document = this.document

    if (this.init) {
      this.document.numberPage = 1;
      this.initTop()
    }
  }

  onZoomOut() {
    this.zoomPdf += 0.1;
  }

  onZoomIn() {
    this.zoomPdf -= 0.1;
  }

  updateZoomDocument() {
    if (this.screenSrv.checkScreen('375px')) {
      this.zoomPdf = 0.25;
    }
    else if (this.screenSrv.checkScreen('375px')) {
      this.zoomPdf = 0.30;
    }
    else if (this.screenSrv.checkScreen('424px')) {
      this.zoomPdf = 0.35;
    } else {
      if (this.screenSrv.checkScreen('769px')) {
        this.zoomPdf = 0.45;
      } else {
        this.zoomPdf = 0.45;
      }
    }
  }

  onPrevPage() {
    if (!(this.document.numberPage == 1)) {
      this.document.numberPage--;
    }

  }

  onNextPage() {
    if (!(this.document.numberPage == this.document.totalPage)) {
      this.document.numberPage++;
    }
  }

  afterLoadComplete(pdfData: any) {
    this.document.totalPage = pdfData.numPages;
  }

  reLoad() {
    setTimeout(() => { this.document.state = 'loading'; }, 0);
    this.onReload.emit(this.document.code);
  }

  initTop():void{
    let element = document.getElementById("zone-preview");
    if(element){
      element.scrollIntoView({ block: "start", behavior: 'smooth' });
  }


}
}
