import { Injectable } from "@angular/core";
import { Subject } from 'rxjs';


@Injectable()
export class ModalService{

  private modalSubject = new Subject<boolean>();
  public modalSubscriber = this.modalSubject.asObservable();


  setModalState(isAutomatic:boolean){
    this.modalSubject.next(isAutomatic);
    this.modalSubject.complete();
  }

  openModal(idModalSection){
    const modalSection: Element = document.querySelector(`#${idModalSection}`);
    modalSection['open']();
  }

  closeModal(idModalSection){ 
      const modalSection:Element = document.querySelector(`#${idModalSection}`);
      modalSection['close']();

  }


}
