import { CustomFormValidateService } from "./custom-form-validate.service";
import { HttpClient } from '@angular/common/http';
import { CurrentAccountsHttp } from '@src/app/core/http/current-accounts.http';

describe("@CustomFormValidateService",()=>{
    let service: CustomFormValidateService;
    let stubCurrenAccountHttp = jasmine.createSpyObj(CurrentAccountsHttp,["validateBusinessName"])

    beforeEach(()=>{
        service = new CustomFormValidateService(stubCurrenAccountHttp);
        stubCurrenAccountHttp.validateBusinessName.and.returnValue(true)
    })

    describe("#getStatusValidEmpty",()=>{
        it("SHOULD validate status empty WHEN the method is called",()=>{
            //act
            let status = service.getStatusValidEmpty("testvalue",false);
            //assert
            expect(status.state).toBe("")
        })

        it("SHOULD validate status empty WHEN the method is called",()=>{
            //Act
            let status = service.getStatusValidEmpty(undefined,false);
            //Assert
            expect(status.state).toEqual("error")
        })

        it("SHOULD validate status empty WHEN the method is called",()=>{
            //Act
            let status = service.getStatusValidEmpty(undefined,true);
            //Assert
            expect(status.state).toEqual("error")
        })
    })

    describe("#getStatusValidAmount",()=>{
        it("SHOULD validate status empty WHEN the method is called",()=>{
            //act
            let status = service.getStatusValidAmount(undefined);
            //assert
            expect(status.state).toBe("error")
        })

        it("SHOULD validate status empty WHEN the method is called",()=>{
            //Act
            let status = service.getStatusValidAmount("0");
            //Assert
            expect(status.state).toEqual("error")
        })

        it("SHOULD validate status empty WHEN the method is called",()=>{
            //Act
            let status = service.getStatusValidAmount("1000");
            //Assert
            expect(status.state).toEqual("")
        })
    })

    describe("#getStatusValidAnualSaleAmount",()=>{
        it("SHOULD validate status amount WHEN the method is called",()=>{
            //act
            let status = service.getStatusValidAnualSaleAmount(undefined);
            //assert
            expect(status.state).toBe("error")
        })

        it("SHOULD validate status amount WHEN the method is called",()=>{
            //Act
            let status = service.getStatusValidAnualSaleAmount("0");
            //Assert
            expect(status.state).toEqual("error")
        })

        it("SHOULD validate status amount WHEN the method is called",()=>{
            //Act
            let status = service.getStatusValidAnualSaleAmount("1100");
            //Assert
            expect(status.state).toEqual("error")
        })

        it("SHOULD validate status amount WHEN the method is called",()=>{
            //Act
            let status = service.getStatusValidAnualSaleAmount("910000");
            //Assert
            expect(status.state).toEqual("error")
        })

        it("SHOULD validate status amount WHEN the method is called",()=>{
            //Act
            let status = service.getStatusValidAnualSaleAmount("900000");
            //Assert
            expect(status.state).toEqual("")
        })
    })


    describe("#getStatusBusinessNameUseCreateCurrentAccount",()=>{
        it("SHOULD validate status amount WHEN the method is called",async()=>{
            //act
            let status = await service.getStatusBusinessNameUseCreateCurrentAccount(undefined);
            //assert
            // expect(status.state).toBe("error")
        })

        it("SHOULD validate status amount WHEN the method is called",async()=>{
            //act
            let status = await service.getStatusBusinessNameUseCreateCurrentAccount("ppel");
            //assert
            // expect(status.state).toBe("")
        })
    })

})