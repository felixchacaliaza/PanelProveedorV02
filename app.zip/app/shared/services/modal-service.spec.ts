import { async, TestBed, inject } from "@angular/core/testing";

import { ModalService } from './modal-service';


describe("@ModalService", () => {

    let service: ModalService;

    // beforeEach(async(() => {
    //     TestBed.configureTestingModule({
    //         imports: [
    //         ],
    //         providers: [
    //             ModalService
    //         ]
    //     }).compileComponents();
    // }));

    beforeEach(()=>{
        service = new ModalService();
    })

    it('I should create the service',() => {      
        expect(service).toBeTruthy();
    });

    describe("#setModalState", () => {
        it('Should set state modal', () => {         

            service.setModalState(true);
        });
    });

    describe("#openModal", () => {
        it('Should open modal', () => {
         
            spyOn(document,"querySelector").and.returnValue(<any>{ open: function(){}})
            service.openModal("modalExpiredSesion");
        });
    });

    describe("#closeModal", () => {
        it('Should close modal', () => {
            spyOn(document,"querySelector").and.returnValue(<any>{ close: function(){}})
            service.closeModal("modalExpiredSesion");
        });
    });   

});









