import { Injectable } from "@angular/core";
import { BreakpointObserver } from '@angular/cdk/layout';

@Injectable()
export class ScreenService {

  constructor(private breakPointObserver: BreakpointObserver) { }

  checkScreen(size: string): boolean {
    const result = this.breakPointObserver.isMatched(`(max-width: ${size})`);
    return result;
  }

}
