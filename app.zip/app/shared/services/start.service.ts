import { Injectable } from "@angular/core";
import { BcpSessionStorage } from '@bcp/ng-core-v3';
import { Router } from '@angular/router';
import { environment } from '@src/environments/environment';


@Injectable()
export class StartService{

    constructor(
        private _bcpSessionStorage: BcpSessionStorage,
        private _router: Router
    ){

    }

    load():Promise<any>{
        return new Promise(async(resolve, reject)=>{
            if(!this.hasLogInWeb){
                return reject('not found')
            }else{
                resolve(true)
            }
        })
    }

    private get hasLogInWeb():boolean{
        if(!this.R2D2 && !this.BB8){
            if(!environment.mock) {
                this._router.navigate(["auth/login"]);
                return false;
            }
            else{
                this._headersDefault();
                return true;
            }
        }
        return true;
    }

    private _headersDefault():void{
        this._bcpSessionStorage.set("R2D2","Bearer flow4-flow4-flow4-flow4-flow4");
        this._bcpSessionStorage.set("BB8","znak-znak-znak-znak-znak");
        this._bcpSessionStorage.set("AK","flow4-flow4-flow4-flow4-flow4");
        this._bcpSessionStorage.set("RTK","flow4-flow4-flow4-flow4-flow4");
        this._bcpSessionStorage.set("channelOrigin","1");
        this._bcpSessionStorage.set("productOrigin","PPEL-PRCTACTE");

        this._bcpSessionStorage.set("mnbcp.usr",JSON.stringify({names:"Elmo",personType:"N",customerType:"CL",ruc:"",isInConsist: true, personId:"987654321000",documentType:"1"}));
    }

    get R2D2(){ return this._bcpSessionStorage.get("R2D2")}
    get BB8(){ return this._bcpSessionStorage.get("BB8")}
    get AK(){ return this._bcpSessionStorage.get("AK")}
}
