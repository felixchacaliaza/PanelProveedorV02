
import { ScreenService } from './screen.service';
import { BreakpointObserver } from '@angular/cdk/layout';

describe("@ScreenService", () => {

  let service: ScreenService;
  const StubBreakpointObserver = jasmine.createSpyObj(BreakpointObserver, ["isMatched"])

  beforeEach(() => {
    service = new ScreenService(StubBreakpointObserver);
  })

  it('I Should create the service', () => {
    expect(service).toBeTruthy();
  });

  describe("#checkScreen", () => {
    it('You should check if the indicated size is responsive and return true', () => {
      StubBreakpointObserver.isMatched.and.returnValue(true);
      expect(service.checkScreen('767px')).toBeTruthy();
    });

    it('You should check if the indicated size is responsive and return false', () => {
      StubBreakpointObserver.isMatched.and.returnValue(false);
      expect(service.checkScreen('767px')).toBeFalsy();
    });
  });



})
