import { Injectable } from '@angular/core';
import { CurrentAccountsHttp } from '@src/app/core/http/current-accounts.http';
import { IStatusField } from '../interfaces/IStatusField';


const MSG = {
  EMPTY: 'Se necesita llenar este dato',
  NO_SELECTED: 'Se necesita seleccionar este campo',
  INCOMPLETE: {
    DOCUMENT_RUC: 'El número de RUC está incompleto.',
    DOCUMENT_DNI: 'El número de DNI está incompleto.',
    PHONE: "El número de celular está incompleto."
  },
  INVALID: {
    EMAIL: 'El correo está errado o incompleto.',
    PHONE: 'El número de celular está errado o incompleto.',
    ADDRESS: '',
    DOCUMENT: 'No luce como un documento',
    AMOUNT: 'Monto no válido',
    BUSINESS_NAME: 'La razón social ingresada ya ha creado una cuenta corriente'
  },
  STEP: {
    AMOUNT: 'El monto es incorrecto, recuerde que la unidad de medida es 1,000'
  },
  INCORRET: {
    AMOUNT: 'El monto es incorrecto, recuerde que el monto maximo es 900,000.00'
  }
}

const STATE_ERROR = "error";

@Injectable()
export class CustomFormValidateService {

  constructor(private _currentAccounstHttp: CurrentAccountsHttp) { }

  getStatusValidEmpty(value: string, isTypeSelected: boolean = false): IStatusField {
    let status: IStatusField = { state: '', message: '' };
    if (!value) {
      if (isTypeSelected) return status = { state: STATE_ERROR, message: MSG.NO_SELECTED }
      else return status = { state: STATE_ERROR, message: MSG.EMPTY }
    }
    else return status;
  }

  getStatusValidAmount(value: string): IStatusField {
    let status: IStatusField = { state: '', message: '' };
    if (!value) {
      status = { state: STATE_ERROR, message: MSG.EMPTY };
    } else {
      if (parseInt(value) == 0) {
        status = { state: STATE_ERROR, message: MSG.INVALID.AMOUNT }
      }
    }
    return status;
  }
  getStatusValidAnualSaleAmount(value: string): IStatusField {
    let status: IStatusField = { state: '', message: '' };
    if (!value) {
      status = { state: STATE_ERROR, message: MSG.EMPTY };
    } else {
      if (parseFloat(value) < 0.01) {
        status = { state: STATE_ERROR, message: MSG.INVALID.AMOUNT }
      } else {
        if (parseInt(value) % 1000 != 0) {
          status = { state: STATE_ERROR, message: MSG.STEP.AMOUNT }
        } else {
          if (parseInt(value) > 900000) {
            status = { state: STATE_ERROR, message: MSG.INCORRET.AMOUNT }
          }
        }
      }
    }
    return status;
  }

  async getStatusBusinessNameUseCreateCurrentAccount(value: string): Promise<IStatusField> {
    let status: IStatusField = { state: '', message: '' };
    if (!value) {
      status = { state: STATE_ERROR, message: MSG.EMPTY };
    } else {

      try {
        const a = await this._currentAccounstHttp.validateBusinessName(value).toPromise();
        return status;
      } catch (e) {
        status = { state: STATE_ERROR, message: MSG.INVALID.BUSINESS_NAME }
        return status;
      }


    }

  }


}

