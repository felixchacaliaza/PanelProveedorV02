import { Injectable } from '@angular/core';
import { Emitter, Emittable } from '@ngxs-labs/emitter';
import { StepState, StepStateModel } from '@src/app/states/step.state';
import { CustomizeAccountState, CustomizeAccountStateModel } from '@src/app/states/customize-account.state';
import { RegisterPersonalDataState, RegisterPersonalDataStateModel } from '@src/app/states/register-personal-data.state';
import { RegisterCompanyDataState, RegisterCompanyDataStateModel } from '@src/app/states/register-company-data.state';
import { DetailsAccountState, DetailsAccountStateModel } from '@src/app/states/details-account.state';


@Injectable()
export class ClearStorageService {

  @Emitter(StepState.register)
  stepStateRegister: Emittable<StepStateModel>;

  @Emitter(CustomizeAccountState.register)
  customizeAccountRegister: Emittable<CustomizeAccountStateModel>;

  @Emitter(RegisterPersonalDataState.register)
  registerPersonalData: Emittable<RegisterPersonalDataStateModel>;

  @Emitter(RegisterCompanyDataState.register)
  registerCompanyData: Emittable<RegisterCompanyDataStateModel>;

  @Emitter(DetailsAccountState.register)
  detailsAccount: Emittable<DetailsAccountStateModel>;

  constructor() { }

  clearSesionStorage(): void {

    this.stepStateRegister.emit({
      infoCtaCte: { state: false, simpleUseStatement: false },
      companyProcessConstitution: { state: false, question: null },
      legalRepresentative: { state: false, question: null },
      companyPartEconomic: { state: false, question: null, groupEconomic: '' },
      politicallyExposedPerson: { state: false, question: null, position: '', laborCenter: '' },
      typeEconomicActivityCompany: { state: false, activityEconomic: '' },
      subsidiaryTransnationalCorporation: { state: false, question: null },
      typeEconomicActivityCompanyDenied: { state: false, question: null },
      onlyStep: 0
    });

    this.customizeAccountRegister.emit({
      state: false,
      money: "",
      moneyDescription: "",
      department: "",
      district: "",
      placeFrequentUse: "",
      typeAccount: ""
    });

    this.registerPersonalData.emit({
      state: false,
      email: '',
      phone: '',
      laborType: '',
      profession: '',
      laborCenter: '',
      codeDepartment: '',
      department:"",
      province:"",
      district:"",
      codeProvince: '',
      codeDistrict: '',
      address: ''
    });

    this.registerCompanyData.emit({
      state: false,
      businessName: '',
      codetypeCompanyName: '',
      typeBusiness: [],
      codetypeCompany: '',
      socialCapital: '',
      departments: [],
      department: '',
      codeDepartment: '',
      provinces: [],
      province: '',
      codeProvince: '',
      districts: [],
      district: '',
      codeDistrict: '',
      address: '',
      fileData: '',
      file:"",
      fileItem: ''
    });

    this.detailsAccount.emit({
      state: false,
      typeAccount: '',
      moneyDescription: '',
      placeFrequentUse: '',
      emailLegalRepresentative: '',
      accountNumber: '',
      cci: '',
      businessName: '',
      requestNumber: ''
    })


  }

}
