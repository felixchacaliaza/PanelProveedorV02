/* tslint:disable:no-unused-variable */


import { ClearStorageService } from './clear-storage-service';
import { of, Observable } from 'rxjs';
import { waitForAsync, TestBed } from '@angular/core/testing';
import { NgxsEmitPluginModule } from '@ngxs-labs/emitter';

describe('Service: ClearStorage', () => {

  let service: ClearStorageService;

  beforeEach(waitForAsync(()=>{
    TestBed.configureTestingModule({
      imports:[NgxsEmitPluginModule]
    })
  }))

  beforeEach(() => {
    service = new ClearStorageService();
  });

 });
