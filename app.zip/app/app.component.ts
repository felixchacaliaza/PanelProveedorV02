import { Component } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { map, filter } from 'rxjs/operators';
import { Emitter, Emittable } from '@ngxs-labs/emitter';
import { StepState, StepStateModel } from './states/step.state';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {

  @Emitter(StepState.register)
  stepRegister: Emittable<StepStateModel>;
  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private titleService: Title
  ) {
    this.stepRegister.emit({
      infoCtaCte: { state: false, simpleUseStatement: false },
      companyProcessConstitution: { state: false, question: null },
      legalRepresentative: { state: false, question: null },
      companyPartEconomic: { state: false, question: null, groupEconomic: '' },
      politicallyExposedPerson: { state: false, question: null, position: '', laborCenter: '' },
      typeEconomicActivityCompany: { state: false, activityEconomic: '' },
      subsidiaryTransnationalCorporation: { state: false, question: null },
      typeEconomicActivityCompanyDenied: { state: false, question: null },
      onlyStep: 0

    });
    this.router.events.pipe(
      filter(event => event instanceof NavigationEnd),
      map(() => {
        let child = this.activatedRoute.firstChild;
        while (child) {
          if (child.firstChild) {
            child = child.firstChild;
          } else if (child.snapshot.data && child.snapshot.data["title"]) {
            return child.snapshot.data["title"];
          } else {
            return null;
          }
        }
      })
    ).subscribe((data: any) => {
      if (data) {
        this.titleService.setTitle(data)
      }
    })
  }

  ngOnInit(): void {
    this.router.initialNavigation();
  }
}
