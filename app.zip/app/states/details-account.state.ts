import { State, Selector, StateContext } from '@ngxs/store';
import { Receiver, EmitterAction } from '@ngxs-labs/emitter';
import { Injectable } from '@angular/core';


export interface DetailsAccountStateModel {

    state?: boolean,
    typeAccount?: string;
    moneyDescription?: string;
    placeFrequentUse?: string;
    emailLegalRepresentative?: string;
    accountNumber?: string;
    cci?: string;
    businessName?: string;
    requestNumber?: string;

}

@State<DetailsAccountStateModel>({
  name: 'detailsAccount',
  defaults: {
    state: false,
    typeAccount: '',
    moneyDescription: '',
    placeFrequentUse: '',
    emailLegalRepresentative: '',
    accountNumber: '',
    cci: '',
    businessName: '',
    requestNumber: ''
  }
})
@Injectable()
export class DetailsAccountState {

  @Selector()
  static currentState(state: DetailsAccountStateModel) {
    return state;
  }

  @Receiver()
  static register(ctx: StateContext<DetailsAccountStateModel>, { payload }: EmitterAction<DetailsAccountStateModel>) {
    ctx.setState(Object.assign({}, ctx.getState(), payload))
  }

}
