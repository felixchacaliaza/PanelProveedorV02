import { NgModule } from "@angular/core";
import { NgxsModule } from '@ngxs/store';
import { StepState } from './step.state';
import { CustomizeAccountState } from './customize-account.state';
import { RegisterPersonalDataState } from './register-personal-data.state';
import { NgxsStoragePluginModule } from '@ngxs/storage-plugin';
import { NgxsEmitPluginModule } from '@ngxs-labs/emitter';
import { RegisterCompanyDataState } from './register-company-data.state';
import { DetailsAccountState } from './details-account.state';
import { StatePresenter } from './state.presenter';

@NgModule({
    imports:[
        NgxsModule.forRoot([StepState,CustomizeAccountState,RegisterPersonalDataState,RegisterCompanyDataState,DetailsAccountState]),
        NgxsStoragePluginModule.forRoot({
          key:['step','customizeAccount','registerPersonalData','registerCompanyData','detailsAccount'],
          storage : 1
        }),
        NgxsEmitPluginModule.forRoot()
    ],
    providers:[
        StatePresenter
    ]

})
export class StateManagerModule{}