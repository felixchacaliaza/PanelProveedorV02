import { Observable } from 'rxjs';
import { Injectable } from "@angular/core";
import { Emitter, Emittable } from '@ngxs-labs/emitter';
import { RegisterPersonalDataState, RegisterPersonalDataStateModel } from './register-personal-data.state';
import { DetailsAccountState, DetailsAccountStateModel } from './details-account.state';
import { CustomizeAccountState, CustomizeAccountStateModel } from './customize-account.state';
import { RegisterCompanyDataState, RegisterCompanyDataStateModel } from './register-company-data.state';
import { Store } from "@ngxs/store";
import { StepStateModel, StepState } from "./step.state";

@Injectable()
export class StatePresenter {

  @Emitter(RegisterPersonalDataState.register)
  personalStateRegister: Emittable<RegisterPersonalDataStateModel>;

  @Emitter(DetailsAccountState.register)
  detailStateRegister: Emittable<DetailsAccountStateModel>;

  @Emitter(CustomizeAccountState.register)
  customizeStateRegister: Emittable<CustomizeAccountStateModel>;

  @Emitter(RegisterCompanyDataState.register)
  companyStateRegister: Emittable<RegisterCompanyDataStateModel>;

  stepState$ = this._store.select<StepStateModel>(StepState.currentState);
  registerCompanyDataState$ = this._store.select<RegisterCompanyDataStateModel>(RegisterCompanyDataState.currentState);
  customizeAccountState$ = this._store.select<CustomizeAccountStateModel>(CustomizeAccountState.currentState);
  detailsAccountState$ = this._store.select<DetailsAccountStateModel>(DetailsAccountState.currentState);
  registerPersonalDataState$ = this._store.select<RegisterPersonalDataStateModel>(RegisterPersonalDataState.currentState);

  constructor(private _store: Store) {

  }

  updateStateEvaluation(data): void {

  }

  updateStateCustomize(data: any): void {
    this.customizeStateRegister.emit(data);
  }

  updateStatePerson(data: any): void {
    this.personalStateRegister.emit(data);
  }

  updateStateCompany(data: any): void {
    this.companyStateRegister.emit(data)
  }

  updateStateDetail(data: any): void {
    this.detailStateRegister.emit(data)
  }

  selectStateStep(): Observable<StepStateModel> {
    return this.stepState$;
  }

  selectStateRegisterCompany(): Observable<RegisterCompanyDataStateModel> {
    return this.registerCompanyDataState$;
  }

  selectStateCustomizeAccount(): Observable<CustomizeAccountStateModel> {
    return this.customizeAccountState$;
  }

  selectStateDetailAccount(): Observable<DetailsAccountStateModel> {
    return this.detailsAccountState$;
  }

  selectStateRegisterPersonal(): Observable<RegisterPersonalDataStateModel> {
    return this.registerPersonalDataState$;
  }
}
