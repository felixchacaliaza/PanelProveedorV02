import { State, Selector, StateContext } from '@ngxs/store';
import { Receiver, EmitterAction } from '@ngxs-labs/emitter';
import { Injectable } from '@angular/core';


export interface ConstantStateModel {
    stage?: string;
    personType?: string;
    customerType?: string;
    documentType?: string;
    action?: string;
    actionLog?:string;
    personName?: string;
    derivation?: boolean;
    isClient?:boolean;
    inConsist?: boolean;
    haveAnAccount?: boolean;
    viewCheckPdp?:boolean;
    showModalExpire?:boolean;
    isDocumentOpening?:boolean;
    isDocumentDisbursement?: boolean;
    isSentQualify?: boolean;
    reSimulate?: boolean;
    ruc?:string;
    validatePower?: boolean;
}

@State<ConstantStateModel>({
    name: 'constant',
    defaults: {
        stage: "",
        personType: "",
        customerType: "",
        documentType: "",
        action: "",
        actionLog: "",
        personName: "",
        derivation: false,
        isClient:true,
        inConsist: false,
        haveAnAccount: true,
        viewCheckPdp: true,
        showModalExpire: false,
        isDocumentOpening: false,
        isDocumentDisbursement: true,
        isSentQualify: false,
        reSimulate: false,
        ruc:"",
        validatePower: false
    }
})
@Injectable()
export class ConstantState {

    @Selector()
    static currentState(state: ConstantStateModel) {
        return state;
    }

    @Receiver()
    static register(ctx: StateContext<ConstantStateModel>, { payload }: EmitterAction<ConstantStateModel>) {
        ctx.setState(Object.assign({},ctx.getState(),payload));
    }

}