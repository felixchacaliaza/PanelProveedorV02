import { State, Selector, StateContext } from '@ngxs/store';
import { Receiver, EmitterAction } from '@ngxs-labs/emitter';
import { Injectable } from '@angular/core';


export interface RegisterCompanyDataStateModel {

    state?: boolean,
    businessName?: string,
    codetypeCompanyName?: string,
    typeBusiness?:any[],
    codetypeCompany?: string,
    socialCapital?: string,
    departments?:any[],
    department?: string,
    codeDepartment? : string,
    provinces?:any[];
    province?: string,
    codeProvince? : string,
    districts?:any[],
    district?: string,
    codeDistrict? : string,
    address? : string,
    file?: string,
    fileData?: any,
    fileItem?: any

}

@State<RegisterCompanyDataStateModel>({
  name: 'registerCompanyData',
  defaults: {
    state: false,
    businessName: '',
    codetypeCompanyName: '',
    typeBusiness:[],
    codetypeCompany:'',
    socialCapital: '',
    departments: [],
    department:'',
    codeDepartment: '',
    provinces:[],
    province: '',
    codeProvince: '',
    districts:[],
    district: '',
    codeDistrict: '',
    address: '',
    file: '',
    fileData: '',
    fileItem: ''
  }
})
@Injectable()
export class RegisterCompanyDataState {

  @Selector()
  static currentState(state: RegisterCompanyDataStateModel) {
    return state;
  }

  @Receiver()
  static register(ctx: StateContext<RegisterCompanyDataStateModel>, { payload }: EmitterAction<RegisterCompanyDataStateModel>) {
    ctx.setState(Object.assign({}, ctx.getState(), payload))
  }

}
