import { State, Selector, StateContext } from '@ngxs/store';
import { Receiver, EmitterAction } from '@ngxs-labs/emitter';
import { Injectable } from '@angular/core';


export interface RegisterPersonalDataStateModel {

  state?: boolean,
  email?: string;
  phone?: string;
  laborType?: string;
  profession?: string;
  laborCenter?: string;
  codeDepartment?: string;
  department?: string;
  codeProvince?: string;
  province?: string;
  codeDistrict?: string;
  district?: string;
  address?: string;

}

@State<RegisterPersonalDataStateModel>({
  name: 'registerPersonalData',
  defaults: {
    state: false,
    email: '',
    phone: '',
    laborType: '',
    profession: '',
    laborCenter: '',
    codeDepartment: '',
    department:"",
    codeProvince: '',
    province:"",
    codeDistrict: '',
    district:"",
    address: ''
  }
})
@Injectable()
export class RegisterPersonalDataState {

  @Selector()
  static currentState(state: RegisterPersonalDataStateModel) {
    return state;
  }

  @Receiver()
  static register(ctx: StateContext<RegisterPersonalDataStateModel>, { payload }: EmitterAction<RegisterPersonalDataStateModel>) {
    ctx.setState(Object.assign({}, ctx.getState(), payload))
  }

}
