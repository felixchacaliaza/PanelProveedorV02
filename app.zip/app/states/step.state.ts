import { State, Selector, StateContext } from '@ngxs/store';
import { Receiver, EmitterAction } from '@ngxs-labs/emitter';
import { Injectable } from '@angular/core';


export interface StepStateModel {
  infoCtaCte?: {
    state?: boolean,
    simpleUseStatement?: boolean
  };
  companyProcessConstitution?: {

    state?: boolean,
    question?: boolean
  };
  legalRepresentative?: {

    state?: boolean,
    question?: boolean
  };
  companyPartEconomic?: {

    state?: boolean,
    question?: boolean,
    groupEconomic?: string
  };
  politicallyExposedPerson?: {

    state?: boolean,
    question?: boolean,
    position?: string,
    laborCenter?: string
  };
  typeEconomicActivityCompany?: {

    state?: boolean,
    activityEconomic?: string
  };

  typeEconomicActivityCompanyDenied?: {

    state?: boolean,
    question?: boolean
  };
  subsidiaryTransnationalCorporation?: {

    state?: boolean,
    question?: boolean
  };
  onlyStep?: number;
}

@State<StepStateModel>({
  name: 'step',
  defaults: {
    infoCtaCte: { state: false, simpleUseStatement: false },
    companyProcessConstitution: { state: false, question: null },
    legalRepresentative: { state: false, question: null },
    companyPartEconomic: { state: false, question: null, groupEconomic: '' },
    politicallyExposedPerson: { state: false, question: null, position: '', laborCenter: '' },
    typeEconomicActivityCompany: { state: false, activityEconomic: '' },
    subsidiaryTransnationalCorporation: { state: false, question: null },
    typeEconomicActivityCompanyDenied: { state: false, question: null },
    onlyStep: 0
  }
})
@Injectable()
export class StepState {

  @Selector()
  static currentState(state: StepStateModel) {
    return state;
  }

  @Receiver()
  static register(ctx: StateContext<StepStateModel>, { payload }: EmitterAction<StepStateModel>) {
    ctx.setState(Object.assign({}, ctx.getState(), payload))
  }

}
