import { State, Selector, StateContext } from '@ngxs/store';
import { Receiver, EmitterAction } from '@ngxs-labs/emitter';
import { Injectable } from '@angular/core';


export interface CustomizeAccountStateModel {

  state?: boolean,
  money?: string;
  moneyDescription?: string;
  department?: string;
  district?: string;
  typeAccount?: string;
  placeFrequentUse?: string;
}

@State<CustomizeAccountStateModel>({
  name: 'customizeAccount',
  defaults: {
    state: false,
    money: '',
    moneyDescription: '',
    department: "",
    district: "",
    typeAccount: "",
    placeFrequentUse: ""
  }
})
@Injectable()
export class CustomizeAccountState {

  @Selector()
  static currentState(state: CustomizeAccountStateModel) {
    return state;
  }

  @Receiver()
  static register(ctx: StateContext<CustomizeAccountStateModel>, { payload }: EmitterAction<CustomizeAccountStateModel>) {
    ctx.setState(Object.assign({}, ctx.getState(), payload))
  }

}
