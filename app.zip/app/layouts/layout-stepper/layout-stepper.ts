import { Component } from "@angular/core";
import { Router } from '@angular/router';

@Component({
    selector:"layout-stepper",
    templateUrl:"./layout-stepper.html",
    styleUrls:["./layout-stepper.scss"]
})
export class LayoutStepper{

    constructor(
        public router: Router
    ){
        
    }
}