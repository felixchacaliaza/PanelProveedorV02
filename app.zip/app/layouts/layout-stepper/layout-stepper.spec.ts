/* tslint:disable:no-unused-variable */
import { LayoutStepper } from './layout-stepper';
import { Router } from '@angular/router';


describe('@LayoutStepper', () => {
  let component: LayoutStepper;
  const StubRouter = jasmine.createSpyObj(Router,["url"])

  beforeEach(() => {
    component = new LayoutStepper(StubRouter)
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
