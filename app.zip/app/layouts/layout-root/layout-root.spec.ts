
import { LayoutRoot } from './layout-root';
import { ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { BcpMicroFrontendRouter } from '@bcp/ng-micro-frontends-v3/router';
import { TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { SessionHttp } from '@src/app/core/http/session.http';
import { of } from 'rxjs';
import { ClearStorageService } from '@src/app/shared/services/clear-storage-service';
import { BcpSessionStorage } from '@bcp/ng-core-v3';


describe('@LayoutRoot', () => {
    let app: LayoutRoot;
    const StubRouter = jasmine.createSpyObj(Router, ["url"]);
    const StubMicroFrontendRouter = jasmine.createSpyObj(BcpMicroFrontendRouter, ["navigateByUrl"]);
    const StubChangeDetectorRef = jasmine.createSpyObj(ChangeDetectorRef, ["detectChanges"])
    const StubSessionHttp = jasmine.createSpyObj(SessionHttp,["close"])
    const StubClearStorageService = jasmine.createSpyObj(ClearStorageService,["clearSesionStorage"])
    const StubBcpSessionStorage = jasmine.createSpyObj(BcpSessionStorage,["remove"])
    let spyResize: any = jasmine.createSpy();

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports:[ReactiveFormsModule]
        }).compileComponents();

        app = new LayoutRoot(StubChangeDetectorRef, StubRouter, StubMicroFrontendRouter,StubSessionHttp,StubClearStorageService,StubBcpSessionStorage);
        window.addEventListener("resize", spyResize);
    })

    it('SHOULD create the app', () => {
        expect(app).toBeTruthy();
    });

    describe("When call method btnCloseSession", () => {
        it("should close sesion if the page is the end", () => {
            StubRouter.url = "/cta-cte/felicitaciones";
            StubMicroFrontendRouter.navigateByUrl.and.callFake(()=>{});
            StubSessionHttp.close.and.callFake(()=>of());
            app.form.get("reason").setValue("abc")

            app.btnCloseSession();

            // expect(StubMicroFrontendRouter.navigateByUrl).toHaveBeenCalledWith("cerro-sesion")

        })

        it("should open modal if the page isn't the end", () => {
            StubRouter.url = "/cta-cte/datos-personales";
            const spy: any = spyOn(document, "getElementById").and.returnValue(<any>{ open: function () { } });

            app.btnCloseSession();


        })
    })

    describe("When call method btnModalSend", () => {
        it("should close modal of session", () => {
            const spy: any = spyOn(document, "getElementById").and.returnValue(<any>{ close: function () { } });
            StubSessionHttp.close.and.callFake(()=>of());
            StubMicroFrontendRouter.navigateByUrl.and.callFake(()=>{});

            app.btnModalSend();
        })
    })

    describe("When call method ngAfterViewInit", () => {
        it("should check screen's height", () => {
            StubChangeDetectorRef.detectChanges.and.callThrough();
            app.layoutSecond = { nativeElement: { offsetWidth: 700 } };

            app.ngAfterViewInit();

        })
    })




});
