import { AfterViewInit, ChangeDetectorRef, Component, ElementRef, ViewChild, HostListener } from "@angular/core";
import { Router } from '@angular/router';
import { BcpMicroFrontendRouter } from '@bcp/ng-micro-frontends-v3/router';
import { SessionHttp } from '@src/app/core/http/session.http';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ClearStorageService } from "@src/app/shared/services/clear-storage-service";
import { BcpSessionStorage } from "@bcp/ng-core-v3";

@Component({
  selector: "layout-root",
  templateUrl: "./layout-root.html",
  styleUrls: ["./layout-root.scss"]
})
export class LayoutRoot implements AfterViewInit {

  @ViewChild('layoutSecond')
  layoutSecond: ElementRef;

  styleMinWidth = '';
  form: FormGroup = new FormGroup({ reason: new FormControl("", [Validators.required]) });
  constructor(
    private changeDetectorRef: ChangeDetectorRef,
    private _router: Router,
    private _microFrontendRouter: BcpMicroFrontendRouter,
    private _sessionHttp: SessionHttp,
    private _clearStorageService: ClearStorageService,
    private _bcpSessionStorage: BcpSessionStorage
  ) {

  }

  ngAfterViewInit(): void {
    this.getChangeHeight();
  }

  btnCloseSession(): void {
    if (this._router.url == "/cta-cte/felicitaciones") {
      this.closeSession()
    } else {
      let element: any = document.getElementById("modalCloseSession");
      element["open"]();
    }

  }

  btnModalSend(): void {
    let element: any = document.getElementById("modalCloseSession");
    element["close"]();
    this.closeSession();
  }

  getChangeHeight() {
    this.changeDetectorRef.detectChanges();
    let width = this.layoutSecond.nativeElement.offsetWidth;
    this.styleMinWidth = `width: ${width}px`;
    this.changeDetectorRef.detectChanges()
  }

  closeSession(): void {
    this._sessionHttp.close(this.form.get("reason").value)
      .toPromise()
      .then(() => {
        this._microFrontendRouter.navigateByUrl("cerro-sesion");
      })
      .catch(() => {
        this._microFrontendRouter.navigateByUrl("cerro-sesion");
      })
  }
  brandSidebarClicked(event) {
    this._clearStorageService.clearSesionStorage();
    this._microFrontendRouter.navigateByUrl("/producto/lista","catalogo")
    this._bcpSessionStorage.remove("productOrigin")
}
  @HostListener("window:resize", ["$event"])
  onChangeHeight(event) {
    this.getChangeHeight();
  }
}
