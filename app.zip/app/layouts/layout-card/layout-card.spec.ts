/* tslint:disable:no-unused-variable */
import { LayoutCard } from './layout-card';


describe('@LayoutCard', () => {
  let component: LayoutCard;

  beforeEach(() => {
    component = new LayoutCard();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
