import { Component } from "@angular/core";

@Component({
    selector:"layout-card",
    templateUrl:"./layout-card.html",
    styleUrls:["./layout-card.scss"]
})
export class LayoutCard{
    
}