
export const FILE_OPTIONS = [
    { icon: 'trash-b', message: 'Eliminar', action: 'remove' }
]

export  const EXTENSIONS = [ "pdf"];

export const MAX_FILE_SIZE = 35000000;

export const MAX_FILE_LIMIT = 1;

export const RESOURCE_INFO = {
    card: {
        image: '/illustrations/spots/svg/sp_file_arrow_to_up_d.svg',
        dragIcon: 'arrow-to-up-r',
        label: {
            title: 'Arrastra el archivo o haz click',
            subtitle: 'Adjunta la minuta de tu negocio',
            dragTitle: 'Por favor, arrastra hasta aquí tu archivo(s).',
        }
    },
    fileItem: {
        error: {
            subtitlePrimary: '¡Error!',
            icon: 'exclamation-triangle-b',
            subtitleSecondary: {
                exceedsMaxSize: 'El archivo seleccionado excede el tamaño máximo permitido.',
                invalidExtension: 'La extensión del archivo no es válida.',
                fileAlreadyExists: 'El archivo que intenta subir ya existe.',
                fileAlreadyInProgress: 'El archivo que intenta subir se encuentra en proceso de carga.',
                externalError: 'Ocurrió un error en el proceso de carga del archivo.',
            }
        },
        success: {
            subtitlePrimary: '¡Perfecto!',
            subtitleSecondary: 'Carga completada satisfactoriamente.',
            icon: 'check-circle-b',
        },
        loading: {
            subtitle: 'Carga del archivo en progreso.',
            image: '/illustrations/spots/svg/sp_documents_turn_d.svg',
        }
    }
}