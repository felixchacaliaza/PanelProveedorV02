import { ConstantStateModel } from './../../states/constant.state';
import { Component, OnInit } from "@angular/core";
import { ValidationHttp } from '@src/app/core/http/validation.http';
import { Router } from '@angular/router';
import { BcpSessionStorage } from '@bcp/ng-core-v3';
import { ClearStorageService } from '@src/app/shared/services/clear-storage-service';

@Component({
    selector: "view-evaluation",
    templateUrl: "./view-evaluation.html",
    styleUrls: ["./view-evaluation.scss"]
})
export class ViewEvaluation implements OnInit {
  personType: string;
    constructor(
        private _validationHttp: ValidationHttp,
        private _router: Router,
        private _bcpSessionStorage: BcpSessionStorage,
        private _clearStorageSrv: ClearStorageService
    ) {
        this.personType  = JSON.parse(localStorage.getItem("constant")).personType;
        this._bcpSessionStorage.set("productOrigin", "PPEL-APCTACTE");
        this._clearStorageSrv.clearSesionStorage();
    }

    ngOnInit() {

        this._startValidation();
    }

    /**
     * Inicia la validación del usuario
     */
    private _startValidation(): void {
      if(this.personType !== 'N') {
        this._router.navigateByUrl("cta-cte/error")

      }else {
        this._validationHttp.validateTheOpeningHours()
            .toPromise()
            .then(response => {
                return this._validationHttp.validateTheAllowedSegment().toPromise()
            })
            .then(response => {
                this._router.navigateByUrl("cta-cte/informacion")
            })
      }

    }

}
