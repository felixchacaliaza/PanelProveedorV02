
import { ViewEvaluation } from './view-evaluation';
import { ValidationHttp } from '@src/app/core/http/validation.http';
import { of } from 'rxjs';
import { BcpSessionStorage } from '@bcp/ng-core-v3';
import { ClearStorageService } from '@src/app/shared/services/clear-storage-service';
import { Router } from '@angular/router';
import { ConstantStateModel } from '@src/app/states/constant.state';


describe('@ViewEvaluation', () => {
  let app: ViewEvaluation;


  const StubValidationHttp = jasmine.createSpyObj(ValidationHttp, ["validateTheOpeningHours", "validateTheAllowedSegment"])
  const StubRouter = jasmine.createSpyObj(Router, ["navigateByUrl"]);
  const StubBcpsessionStorage = jasmine.createSpyObj(BcpSessionStorage, ["set"]);
  const StubClearStorage = jasmine.createSpyObj(ClearStorageService, ["clearSesionStorage"]);
  const StubPersonType = jasmine.createSpyObj(String, ["personType"]);
  beforeEach(() => {
    app = new ViewEvaluation(StubValidationHttp, StubRouter, StubBcpsessionStorage, StubClearStorage);

  })

  function storageMock() {
    var storage = {};
    return {
      setItem: function (key, value) {
        storage[key] = value || '';
      },
      getItem: function (key) {
        return key in storage ? storage[key] : null;
      },
      removeItem: function (key) {
        delete storage[key];
      },
      get length() {
        return Object.keys(storage).length;
      },
      key: function (i) {
        var keys = Object.keys(storage);
        return keys[i] || null;
      }
    };
  }
  let mockConfig = JSON.stringify({
    personType: "J",
  });

  let m =  storageMock();
  m.setItem('constant', mockConfig);

     Object.defineProperty(window, 'localStorage', { value: m });
  it('SHOULD create the app', () => {
    app.personType = JSON.parse(m.getItem('constant')).personType;
    expect(app).toBeTruthy();
  });

  xdescribe("#ngOnInit", () => {
    it("SHOULD start the validation WHEN you start the page", () => {

      StubBcpsessionStorage.set.and.callThrough();
      StubClearStorage.clearSesionStorage.and.callThrough();
      StubValidationHttp.validateTheOpeningHours.and.callFake(() => of({}))
      StubValidationHttp.validateTheAllowedSegment.and.callFake(() => of())

      app.ngOnInit()

      expect(StubValidationHttp.validateTheOpeningHours).toHaveBeenCalled()
    })
  })


});
