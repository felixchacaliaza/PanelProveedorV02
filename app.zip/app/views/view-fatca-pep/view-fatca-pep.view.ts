import { Component } from "@angular/core";
import { BreakpointObserver } from '@angular/cdk/layout';
import { StepStateModel } from '@src/app/states/step.state';
import { ModalService } from '@src/app/shared/services/modal-service';
import { StatePresenter } from "@src/app/states/state.presenter";

@Component({
  selector: "view-fatca-pep",
  templateUrl: "./view-fatca-pep.view.html",
  styleUrls: ["./view-fatca-pep.view.scss"]
})
export class ViewFatcaAndPEP {
  currentModal: string = "";
  isScreenMobile: boolean = false;
  stepState: StepStateModel;
  constructor(
    private modalSrv: ModalService,
    private breakPointObserver: BreakpointObserver,
    private _statePresenter : StatePresenter
  ) {

    this._statePresenter.selectStateStep().subscribe(stepState => {
      this.stepState = stepState
    });
    this.isScreenMobile = this.isMobile();

    window.addEventListener("resize", () => {
      setTimeout(() => { this.isScreenMobile = this.isMobile(); }, 0);
    })
  }

  ctrlCloseModalCapitalSocial($event): void {
    this.currentModal = "";
  }



  openModal(modalName: string) {
    this.currentModal = modalName;
    this.modalSrv.openModal(modalName);
  }


  closeModal(modalName: string) {

    this.currentModal = "";
    this.modalSrv.closeModal(modalName);
  }

  isMobile(): boolean {
    let result = this.breakPointObserver.isMatched("(max-width: 767px)");
    return result;
  }
}
