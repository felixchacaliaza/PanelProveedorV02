import { Injectable } from "@angular/core";
import { FormGroup, FormBuilder } from '@angular/forms';
import { DetailFormModel } from '../models/detail-form.model';
import { Subject } from 'rxjs';

@Injectable()
export class DetailFormPresenter {

    form: FormGroup;

    destroy$ = new Subject();

    constructor(
        private _formBuilder: FormBuilder
    ) {
        const { getErrorMessage, ...rest } = new DetailFormModel();
        this.form = this._formBuilder.group({
            ...rest
        });
        this.form.getError = (control: string) => getErrorMessage(control, this.form);
    }

}