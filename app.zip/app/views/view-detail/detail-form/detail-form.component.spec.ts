import { DetailFormComponent } from "./detail-form.component";
import { DetailFormPresenter } from './detail-form.presenter';

describe("@DetailFormComponent", () => {
    let component: DetailFormComponent;
    const StubDetailFormPresenter = jasmine.createSpyObj(DetailFormPresenter, ["destroy$", "form"])
    beforeEach(() => {
        component = new DetailFormComponent(StubDetailFormPresenter);
    })

    describe("#ngOnDestroy", () => {
        it("should delete subscribe form", () => {
            const spyNext = jasmine.createSpy();
            StubDetailFormPresenter.destroy$ = {
                next: spyNext,
                complete: jasmine.createSpy()
            }

            component.ngOnDestroy();

            expect(spyNext).toHaveBeenCalled()
        })

        it("should delete subscribe form", () => {
            const spyComplete = jasmine.createSpy();
            StubDetailFormPresenter.destroy$ = {
                next: jasmine.createSpy(),
                complete: spyComplete
            }

            component.ngOnDestroy();

            expect(spyComplete).toHaveBeenCalled()
        })
    })

    describe("#btnNext",()=>{
        it("should launch emit event",()=>{
            const spyEmit = spyOn(component.onNext,"emit").and.callThrough();

            component.btnNext();

            expect(spyEmit).toHaveBeenCalled();
        })
    })

    describe("#btnBack",()=>{
        it("should lauch emit event",()=>{
            const spyEmit = spyOn(component.onBack,"emit").and.callThrough();

            component.btnBack();

            expect(spyEmit).toHaveBeenCalled()
        })
    })

    describe("#btnViewDocuments",()=>{
        it("should launch emit event modal",()=>{
            const spyEmit = spyOn(component.onModal,"emit").and.callThrough();

            component.btnViewDocuments();

            expect(spyEmit).toHaveBeenCalled()
        })
    })
})