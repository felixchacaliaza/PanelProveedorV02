import { DetailFormPresenter } from "./detail-form.presenter";
import { TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';

describe("@DetailFormPresenter",()=>{
    let presenter: DetailFormPresenter;

    beforeEach(()=>{
        TestBed.configureTestingModule({
            imports:[ReactiveFormsModule],
            providers:[DetailFormPresenter]
        }).compileComponents()

        presenter = TestBed.inject(DetailFormPresenter);
    })
})