import { Component, Output, EventEmitter, ChangeDetectionStrategy, OnDestroy } from "@angular/core";
import { DetailFormPresenter } from './detail-form.presenter';

@Component({
    selector: "ppel-detail-form",
    templateUrl: "./detail-form.component.html",
    styleUrls: ["./detail-form.component.scss"],
    providers: [DetailFormPresenter],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class DetailFormComponent implements OnDestroy {

    @Output()
    onNext = new EventEmitter<any>();

    @Output()
    onBack = new EventEmitter<any>();

    @Output()
    onModal = new EventEmitter<string>();

    form = this._presenter.form;

    constructor(
        private _presenter: DetailFormPresenter
    ) {


    }

    ngOnDestroy(){
        this._presenter.destroy$.next();
        this._presenter.destroy$.complete();
    }

    btnNext(): void {
        this.onNext.emit(this.form.value);
    }

    btnBack(): void {
        this.onBack.emit();
    }

    btnViewDocuments() {
        this.onModal.emit("modalDocuments");
    }



}