export const ErrorMessage: { [key: string]: string } = {
    required: "Debes completar esta información",
    pattern: "El valor ingresado es inválido"
}