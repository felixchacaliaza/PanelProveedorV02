import { Injectable } from "@angular/core";
import { CurrentAccountsHttp } from '@src/app/core/http/current-accounts.http';
import { IRegisterCurrentAccountHttpRequest } from '@src/app/core/models/register-current-account.model';
import { BehaviorSubject } from 'rxjs';
import { Router } from '@angular/router';

@Injectable()
export class ViewDetailPresenter{

    private _loader = new BehaviorSubject<boolean>(false);

    get loader$(){
        return this._loader.asObservable();
    }

    constructor(
        private _currentHttp: CurrentAccountsHttp,
        private _router: Router
    ){

    }

    async initCreateAccount(data:IRegisterCurrentAccountHttpRequest){
        this._loader.next(true);
       return await this._registerPersonsCompany()
        .then(response=>{
            return this._registerCurrentAccount(data)
        })
        .then(response=>{
            this._loader.next(false);
            return response;
        })
    }

    redirectToBackPage(){
        this._router.navigateByUrl("cta-cte/datos-negocio")
    }

    redirectToNextPage(){
        this._router.navigateByUrl("cta-cte/felicitaciones");
    }

    private _registerPersonsCompany(){
        return this._currentHttp.registerPersonsCompany().toPromise();
    }

    private _registerCurrentAccount(data:any){

        let dataConvert : IRegisterCurrentAccountHttpRequest = {
          termConditions: data.termConditions === '1'? true : false,
          dataVeracity:  data.dataVeracity === '1'? true : false,
        }
        return this._currentHttp.registerCurrentAccount(dataConvert).toPromise();
    }

}
