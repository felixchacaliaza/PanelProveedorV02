/* tslint:disable:no-unused-variable */
import { ViewDetail } from './view-detail';
import { ModalService } from '@src/app/shared/services/modal-service';
import { ViewDetailPresenter } from './view-detail.presenter';
import { StatePresenter } from '@src/app/states/state.presenter';
import { BreakpointObserver } from '@angular/cdk/layout';
import { waitForAsync, TestBed } from '@angular/core/testing';
import { StateManagerModule } from '@src/app/states/state-manager.module';


describe('@ViewDetail', () => {
  let component: ViewDetail;
  const StubViewDetailPresenter = jasmine.createSpyObj(ViewDetailPresenter,["initCreateAccount","redirectToNextPage","redirectToBackPage"]);
  const StubStatePresente = jasmine.createSpyObj(StatePresenter,["updateStateDetail"]);
  const StubBreakpointObserver = jasmine.createSpyObj(BreakpointObserver,["isMatched"]);
  const StubModalService = jasmine.createSpyObj(ModalService,["openModal","closeModal"]);

  beforeEach(waitForAsync(()=>{
    TestBed.configureTestingModule({
      imports:[
        StateManagerModule
      ]
    }).compileComponents()
  }))

  beforeEach(() => {
    component = new ViewDetail(StubViewDetailPresenter, StubBreakpointObserver, StubModalService, StubStatePresente)
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe("#onBack",()=>{
    it("should go to back page",()=>{
      StubViewDetailPresenter.redirectToBackPage.and.callThrough();

      component.onBack({})

      expect(StubViewDetailPresenter.redirectToBackPage).toHaveBeenCalled()
    })
  })

  describe("#onModal",()=>{
    it("should open a modal",()=>{
      StubModalService.openModal.and.callThrough();

      component.onModal("idmodal");

      expect(StubModalService.openModal).toHaveBeenCalled()
    })
  })

  describe("#ctrlCloseModal",()=>{
    it("should reset var initDocument",()=>{
      component.initDocument = true;

      component.ctrlCloseDocument({});

      expect(component.initDocument).toBe(false)
    })
  })


  describe("#closeModal",()=>{
    it("should close the modal",()=>{
      StubModalService.closeModal.and.callThrough();

      component.closeModal("idmodal");

      expect(StubModalService.closeModal).toHaveBeenCalled()
    })
  })

  describe("#onNext",()=>{
    it("should create the account",()=>{
      StubViewDetailPresenter.initCreateAccount.and.callFake(()=>Promise.resolve({
        account:{ accountNumber: "123",cci:"123"},
        company:{ businessName: "abc"},
        requestNumber: "123"
      }));
      StubStatePresente.updateStateDetail.and.callFake(()=>{})

      component.onNext({});

      expect(StubViewDetailPresenter.initCreateAccount).toHaveBeenCalled()
    })
  })

  describe("#getScreenSize",()=>{
    it("should get the size screen",()=>{
      StubBreakpointObserver.isMatched.and.returnValue(true);

      component.getScreenSize({});

      expect(component.isMobile).toBe(true)
    })
  })
});
