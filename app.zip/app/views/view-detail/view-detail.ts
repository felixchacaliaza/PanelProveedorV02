import { Component, HostListener } from "@angular/core";
import { BreakpointObserver } from '@angular/cdk/layout';
import { IRegisterCurrentAccountHttpRequest } from "./../../core/models/register-current-account.model";
import { ModalService } from '@src/app/shared/services/modal-service';
import { ViewDetailPresenter } from './view-detail.presenter';
import { StatePresenter } from '@src/app/states/state.presenter';

@Component({
  selector: "view-detail",
  templateUrl: "./view-detail.html",
  styleUrls: ["./view-detail.scss"],
  providers: [ViewDetailPresenter]
})
export class ViewDetail {
  public money: string;
  public placeFrequentUse: string;
  public emailLegalRepresentative: string;
  public isMobile: boolean = false;
  public currentModal: string = "";
  public initDocument: boolean = false;

  public loader$ = this._presenter.loader$;

  constructor(
    private _presenter: ViewDetailPresenter,
    private _observer: BreakpointObserver,
    private _modalSrv: ModalService,
    public _statePresenter : StatePresenter
  ) {
    this.isMobile = this._isMobile();

  }

  onNext(data: any) {
    this._presenter.initCreateAccount(<IRegisterCurrentAccountHttpRequest>data)
      .then((response: any) => {
        this._statePresenter.updateStateDetail({
          state: true,
          accountNumber: response.account.accountNumber.split('-').join(' '),
          cci: response.account.cci,
          businessName: response.company.businessName,
          requestNumber: response.requestNumber
        })
        this._presenter.redirectToNextPage();
      })
  }

  onBack(event) {
    this._presenter.redirectToBackPage();
  }

  onModal(idModal: string) {
    this.initDocument = true;
    this._modalSrv.openModal(idModal)
  }

  ctrlCloseDocument($event) {
    this.initDocument = false;
  }


  public closeModal(modalName: string) {
    this.currentModal = "";
    this.initDocument = false;
    this._modalSrv.closeModal(modalName);
  }

  private _isMobile(): boolean {
    return this._observer.isMatched("(min-width: 1px) and (max-width: 767px)");
  }

  @HostListener("window:resize", ["$event"])
  getScreenSize(event) {
    this.isMobile = this._isMobile()
  }

}
