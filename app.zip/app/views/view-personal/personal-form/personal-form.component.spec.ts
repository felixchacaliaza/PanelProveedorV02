import { PersonalFormPresenter } from "./personal-form.presenter";
import { PersonalFormComponent } from './personal-form.component';
import { Subject, of } from 'rxjs';
import { FormGroup, FormControl } from '@angular/forms';

describe("@PersonalFormComponent", () => {
    let component: PersonalFormComponent;
    const StubPersonalFormPresenter = jasmine.createSpyObj(PersonalFormPresenter, ["setForm","initialize", "destroy$", "notifySelect$", "form"]);

    beforeEach(() => {
        component = new PersonalFormComponent(StubPersonalFormPresenter);
        StubPersonalFormPresenter.destroy$ = new Subject();
    })

    describe("#ngOnInit", () => {
        it("Should be called the method initialize of presenter", () => {
            StubPersonalFormPresenter.initialize.and.callThrough();
            StubPersonalFormPresenter.notifySelect$ = of();

            component.ngOnInit();

            expect(StubPersonalFormPresenter.initialize).toHaveBeenCalled();
        })

        it("SHOULD emit event of select WHEN an item is selected", () => {
            StubPersonalFormPresenter.notifySelect$ = of({ key: "", value: "" });
            const spyEmit = spyOn(component.onChangeSelect, "emit").and.callThrough();

            component.ngOnInit();

            expect(spyEmit).toHaveBeenCalled()
        })
    })

    describe("#ngOnDestroy", () => {
        it("SHOULD be call next of subject destroy", () => {
            const spyNext = jasmine.createSpy();
            StubPersonalFormPresenter.destroy$ = {
                next: spyNext, complete: jasmine.createSpy()
            }

            component.ngOnDestroy();

            expect(spyNext).toHaveBeenCalled()
        })

        it("SHOULD be call complete of subject destroy", () => {
            const spyComplete = jasmine.createSpy();
            StubPersonalFormPresenter.destroy$ = {
                next: jasmine.createSpy(), complete: spyComplete
            }

            component.ngOnDestroy();

            expect(spyComplete).toHaveBeenCalled()
        })
    })

    describe("#btnBack", () => {
        it("SHOULD emit event WHEN 'btnBack' button is called", () => {
            const spyBack = spyOn(component.onBack, "emit").and.callThrough();

            component.btnBack();

            expect(spyBack).toHaveBeenCalled()
        })
    })

    describe("#btnNext", () => {
        it("SHOULD emit event WHEN 'btnNext' button is called", () => {
            const spyNext = spyOn(component.onNext, "emit").and.callThrough();
            component.form = new FormGroup({
                email: new FormControl("email@mail.com"),
                phone: new FormControl("987654321"),
                laborType: new FormControl("ind"),
                laborCenter: new FormControl("text"),
                codeDepartment: new FormControl("01"),
                codeProvince: new FormControl("01"),
                codeDistrict: new FormControl("01"),
                address: new FormControl("text")
            })           
            component.departments = [{ code: "01", description: "desc" }]
            component.provinces = [{ code: "01", description: "desc" }]
            component.districts = [{ code: "01", description: "desc" }]

            component.btnNext();

            expect(spyNext).toHaveBeenCalled()
        })
    })

    describe("#data", () => {
        it("SHOULD emit event WHEN 'btnBack' button is called", () => {
            StubPersonalFormPresenter.setForm.and.returnValue()

            component.data = {email: "email@mail.com"};

            expect(StubPersonalFormPresenter.setForm).toHaveBeenCalled()
        })
    })
})