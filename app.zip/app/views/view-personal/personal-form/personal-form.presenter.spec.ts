import { PersonalFormPresenter } from "./personal-form.presenter";
import { TestBed } from '@angular/core/testing';
import { ReactiveFormsModule, FormControl } from '@angular/forms';
import { PersonalFormModel } from '../models/personal-form.model';

describe("@PErsonalFormPresenter",()=>{
    let presenter: PersonalFormPresenter;
    let spyError:any;
    
    beforeEach(()=>{
        TestBed.configureTestingModule({
            imports:[ReactiveFormsModule],
            providers:[PersonalFormPresenter]
        }).compileComponents();

        spyError = spyOn(PersonalFormModel.prototype,"getErrorMessage").and.returnValue({});

        presenter = TestBed.inject(PersonalFormPresenter);
        presenter.initialize();
    });

    describe("When call getError",()=>{
        it("should be call getErrorMessage",()=>{
            presenter.form.getError("email");
            expect(spyError).toHaveBeenCalled()
        })
    })

    describe("When deparment change value",()=>{

        it("Shoul call reset method of province form control",()=>{
            const department = presenter.form.get("codeDepartment") as FormControl;
            const province = presenter.form.get("codeProvince") as FormControl;
            const spyProvinceReset = spyOn(province,"reset").and.callThrough();

            department.patchValue("");

            expect(spyProvinceReset).not.toHaveBeenCalled()

        })

        it("Shoul call reset method of province form control",()=>{
            const department = presenter.form.get("codeDepartment") as FormControl;
            const province = presenter.form.get("codeProvince") as FormControl;
            const spyProvinceReset = spyOn(province,"reset").and.callThrough();

            department.patchValue("01");

            expect(spyProvinceReset).toHaveBeenCalled()

        })

        it("Shoul call reset method of district form control",()=>{
            const department = presenter.form.get("codeDepartment") as FormControl;
            const district = presenter.form.get("codeDistrict") as FormControl;
            const spyDistrictReset = spyOn(district,"reset").and.callThrough();

            department.patchValue("01");

            expect(spyDistrictReset).toHaveBeenCalled()

        })

        it("Shoul call reset method of address form control",()=>{
            const department = presenter.form.get("codeDepartment") as FormControl;
            const address = presenter.form.get("address") as FormControl;
            const spyAddressReset = spyOn(address,"reset").and.callThrough();

            department.patchValue("01");

            expect(spyAddressReset).toHaveBeenCalled()

        })

        it("Shoul call emit event notifySelect",()=>{
            const department = presenter.form.get("codeDepartment") as FormControl;
            let result:any;
            presenter.notifySelect$.subscribe(value=>result = value);

            department.patchValue("01");

            expect(result).toEqual({key:"codeDepartment",value:"01"})

        })
    })

    describe("When province change value",()=>{       

        it("Shoul call reset method of district form control",()=>{
            const province = presenter.form.get("codeProvince") as FormControl;
            const district = presenter.form.get("codeDistrict") as FormControl;
            const spyDistrictReset = spyOn(district,"reset").and.callThrough();

            province.patchValue("01");

            expect(spyDistrictReset).toHaveBeenCalled()

        })

        it("Shoul call reset method of address form control",()=>{
            const province = presenter.form.get("codeProvince");
            const address = presenter.form.get("address");
            const spyAddressReset = spyOn(address,"reset").and.callThrough();

            province.patchValue("01");

            expect(spyAddressReset).toHaveBeenCalled()

        })

        it("Shoul call emit event notifySelect",()=>{
            const department = presenter.form.get("codeDepartment") as FormControl;
            const province = presenter.form.get("codeProvince") as FormControl;
            let result:any;
            presenter.notifySelect$.subscribe(value=>result = value);
            department.patchValue("02")
            province.patchValue("01");

            expect(result).toEqual({key:"codeProvince",value:"02-01"})

        })
    })

    describe("When district change value",()=>{       

      
        it("Shoul call reset method of address form control",()=>{
            const district = presenter.form.get("codeDistrict");
            const address = presenter.form.get("address");
            const spyAddressReset = spyOn(address,"reset").and.callThrough();

            district.patchValue("01");

            expect(spyAddressReset).toHaveBeenCalled()

        })

        it("Shoul call emit event notifySelect",()=>{
            
            const district = presenter.form.get("codeDistrict") as FormControl;
            let result:any;
            presenter.notifySelect$.subscribe(value=>result = value);
            
            district.patchValue("01");

            expect(result).toEqual({key:"codeDistrict",value:"01"})

        })
    })

    describe("when call method setForm",()=>{
        it("should set data in the form",()=>{
            const data = {email: "email@mail.com"}
            presenter.setForm(data);
            expect(presenter.form.get("email").value).toBe("email@mail.com")
        })

        it("not should set data in the form",()=>{
            const data = {}
            presenter.setForm(data);
            expect(presenter.form.get("email").value).toBe("")
        })
    })
})