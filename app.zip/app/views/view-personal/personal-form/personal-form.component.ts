import { Component, Output, EventEmitter, Input, OnInit, OnDestroy, ChangeDetectionStrategy } from "@angular/core";
import { PersonalFormPresenter } from './personal-form.presenter';
import { GeolocationModel } from '@src/app/core/models/geolocation.model';
import { CatalogModel, OccupationModel } from '@src/app/core/models/catalog.model';
import { takeUntil } from 'rxjs/operators';
import { FormGroup } from '@angular/forms';

@Component({
    selector: "ppel-personal-form",
    templateUrl: "./personal-form.component.html",
    styleUrls: ["./personal-form.component.scss"],
    providers: [PersonalFormPresenter],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class PersonalFormComponent implements OnInit, OnDestroy {

    @Input()
    departments: GeolocationModel[] = [];

    @Input()
    provinces: GeolocationModel[] = [];

    @Input()
    districts: GeolocationModel[] = [];

    @Input()
    professions: CatalogModel[] = [];

    @Input()
    occupations: OccupationModel[] = [];

    @Input()
    set data(value:any){
        this._presenter.setForm(value)
    }

    @Output()
    onBack = new EventEmitter<string>();

    @Output()
    onNext = new EventEmitter<any>();

    @Output()
    onChangeSelect = new EventEmitter<any>();

    form: FormGroup = this._presenter.form;

    constructor(
        private _presenter: PersonalFormPresenter
    ) {

    }

    ngOnInit() {
        this._presenter.initialize();
        this._presenter.notifySelect$
            .pipe(takeUntil(this._presenter.destroy$))
            .subscribe(value => this.onChangeSelect.emit(value))
    }

    ngOnDestroy() {
        this._presenter.destroy$.next();
        this._presenter.destroy$.complete();
    }

    btnBack(): void {
        this.onBack.emit();
    }

    btnNext(): void {
        this.onNext.emit(this._buildData());
    }

    private _buildData(){
        return {
            ...this.form.value,
            department: this.departments.find(dp => dp.code == this.form.get("codeDepartment").value).description,
            province:  this.provinces.find(dp => dp.code == this.form.get("codeProvince").value).description,
            district:  this.districts.find(dp => dp.code == this.form.get("codeDistrict").value).description
        }
    }
}