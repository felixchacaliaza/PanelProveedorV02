import { Injectable } from "@angular/core";
import { Observable, BehaviorSubject, Subject } from 'rxjs';
import { FormGroup, FormBuilder } from '@angular/forms';
import { PersonalFormModel } from '../models/personal-form.model';
import { takeUntil } from 'rxjs/operators';

@Injectable()
export class PersonalFormPresenter {
   
    private _codeDepartment = new BehaviorSubject<string>("");
    private _codeProvince = new BehaviorSubject<string>("");
    private _codeDistrict = new BehaviorSubject<string>("");   

    private _notifySelect = new BehaviorSubject<any>("");

    form!: FormGroup;

    destroy$ = new Subject();

    constructor(private _formBuilder: FormBuilder) {

        const { getErrorMessage, ...rest } = new PersonalFormModel();
        this.form = this._formBuilder.group({
            ...rest
        })

        this.form.getError = (control: string) => getErrorMessage(control, this.form);

    }


    get notifySelect$(): Observable<any |unknown> {
        return this._notifySelect.asObservable();
    }

    initialize(): void {
        this._watchDepartment();
        this._watchProvince();
        this._watchDistrict();
    }

    setForm(data:any):void{
        if(data && Object.entries(data).length > 0){
            this.form.patchValue(data)
        }
    }

    private _watchDepartment(): void {
        this.form.get("codeDepartment").valueChanges
            .pipe(takeUntil(this.destroy$))
            .subscribe(codeDepa => {
                if (codeDepa) {
                    this._codeDepartment.next(codeDepa);
                    this.form.get("codeProvince").reset();
                    this.form.get("codeDistrict").reset();
                    this.form.get("address").reset();
                    this._notifySelect.next({ key: "codeDepartment", value: codeDepa });
                }

            })
    }

    private _watchProvince(): void {
        this.form.get("codeProvince").valueChanges
            .pipe(takeUntil(this.destroy$))
            .subscribe(codeProv => {
                if (codeProv) {
                    this._codeProvince.next(codeProv);
                    this.form.get("codeDistrict").reset();
                    this.form.get("address").reset();
                    this._notifySelect.next({ key: "codeProvince", value: `${this.form.get("codeDepartment").value}-${codeProv}` })
                }
            })
    }

    private _watchDistrict(): void {
        this.form.get("codeDistrict").valueChanges
            .pipe(takeUntil(this.destroy$))
            .subscribe(codeDist => {
                if (codeDist) {
                    this._codeDistrict.next(codeDist);
                    this.form.get("address").reset();
                    this._notifySelect.next({ key: "codeDistrict", value: codeDist });
                }
            })
    }



}