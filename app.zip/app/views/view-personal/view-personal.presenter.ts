import { Injectable } from "@angular/core";
import { CatalogHttp } from '@src/app/core/http/catalog.http';
import { GeolocationHttp } from '@src/app/core/http/geolocation.http';
import { BehaviorSubject, Observable, forkJoin } from 'rxjs';
import { GeolocationModel } from '@src/app/core/models/geolocation.model';
import { CatalogModel, OccupationModel } from '@src/app/core/models/catalog.model';
import { map } from 'rxjs/operators';
import { Router } from '@angular/router';
import { IInititalDataHttpRequest } from '@src/app/core/models/initial-data.model';
import { DatosHttp } from '@src/app/core/http/datos.http';

@Injectable()
export class ViewPersonalPresenter {

    private _departments = new BehaviorSubject<GeolocationModel[]>([]);
    private _provinces = new BehaviorSubject<GeolocationModel[]>([]);
    private _districts = new BehaviorSubject<GeolocationModel[]>([]);
    private _professions = new BehaviorSubject<CatalogModel[]>([]);
    private _occupations = new BehaviorSubject<OccupationModel[]>([]);
    private _loader = new BehaviorSubject<boolean>(false);

    get departments$(): Observable<GeolocationModel[]> {
        return this._departments.asObservable();
    }

    get provinces$(): Observable<GeolocationModel[]> {
        return this._provinces.asObservable();
    }

    get districts$(): Observable<GeolocationModel[]> {
        return this._districts.asObservable();
    }

    get professions$(): Observable<CatalogModel[]> {
        return this._professions.asObservable();
    }

    get occupations$(): Observable<OccupationModel[]> {
        return this._occupations.asObservable();
    }

    get loader$() {
        return this._loader.asObservable();
    }

    constructor(
        private _catalogHttp: CatalogHttp,
        private _geolocationHttp: GeolocationHttp,
        private _datosHttp: DatosHttp,
        private _router: Router
    ) {

    }

    async initialize() {
        this._loader.next(true);
        const _callDepartments = this._geolocationHttp.getListDepartment();
        const _callProfessions = this._catalogHttp.getListProfesion();
        const _callOccupations = this._catalogHttp.getListOccupations();

        const { resDepartments, resProfessions, resOccupations } = await forkJoin({
            resDepartments: _callDepartments.pipe(map(response => response)),
            resProfessions: _callProfessions.pipe(map(response => response)),
            resOccupations: _callOccupations.pipe(map(response => response))
        }).toPromise()

        this._departments.next(resDepartments);
        this._professions.next(resProfessions);
        this._occupations.next(resOccupations);
        this._loader.next(false);

    }

    handleError(error) {

    }

    async loadProvince(codeDepartment) {
        this._loader.next(true);
        const _callProvinces = this._geolocationHttp.getListProvince(codeDepartment);
        const { resProvinces } = await forkJoin({
            resProvinces: _callProvinces.pipe(map(response => response))
        }).toPromise()

        this._provinces.next(resProvinces);
        this._loader.next(false);
    }

    async loadDistrict(codeDepartment, codeProvince) {
        this._loader.next(true);
        const _callDistricts = this._geolocationHttp.getListDistrict(codeDepartment, codeProvince);
        const { resDistricts } = await forkJoin({
            resDistricts: _callDistricts.pipe(map(response => response))
        }).toPromise()

        this._districts.next(resDistricts);
        this._loader.next(false);
    }



    resetListDepartments(): void {
        this._departments.next([]);
    }

    resetListProvinces(): void {
        this._provinces.next([]);
    }

    resetListDistricts(): void {
        this._districts.next([]);
    }

    redirectToNextPage(): void {
        this._router.navigateByUrl("cta-cte/datos-negocio");
    }

    redirectToBackPage(): void {
        this._router.navigateByUrl("cta-cte/personaliza");
    }

    async saveData(data: any) {
        this._loader.next(true);
        const request = this._buildRequest(data);
        const _callInitalData = this._datosHttp.initialData(request);
        const { response } = await forkJoin({
            response: _callInitalData.pipe(map(res => res))
        }).toPromise();
        this._loader.next(false);

    }

    private _buildRequest(data): IInititalDataHttpRequest {

        return {
            legalRepresentative: {
                email: data.email,
                phone: data.phone,
                occupation: data.laborType,
                profession: data.profession,
                laborCenter: data.laborCenter,
                address: {
                    department: {
                        description: data.department,
                        code: data.codeDepartment
                    },
                    province: {
                        description: data.province,
                        code: data.codeProvince
                    },
                    district: {
                        description: data.district,
                        code: data.codeDistrict
                    },
                    address: data.address
                }
            },
            configuration: {
                step: 'LEGAL_REPRESENTATIVE_STEP'
            }
        }
    }




}