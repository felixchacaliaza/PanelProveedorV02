import { FormGroup, AbstractControl } from '@angular/forms';
import { ErrorMessages } from './personal-form-constant';
import { BcpValidators } from '@bcp/ng-core-v3/forms';

export class PersonalFormModel {

    email = ["", [BcpValidators.required, BcpValidators.pattern(/^(\w|\.|-)+@[a-zA-Z]+(\.[a-zA-Z]+)*(\.[a-zA-Z]{2,5})+$/)]];
    phone = ["", [BcpValidators.required, BcpValidators.pattern(/^[9][0-9]{8}$/)]];
    laborType = ["", [BcpValidators.required]];
    profession = ["", [BcpValidators.required]];
    laborCenter = ["", [BcpValidators.required]];
    codeDepartment = ["", [BcpValidators.required]];
    codeProvince = ["", [BcpValidators.required]];
    codeDistrict = ["", [BcpValidators.required]];
    address = ["", [BcpValidators.required]];

    getErrorMessage(control: string, form: FormGroup): Object {

        const { touched, dirty, errors } = form.get(control) as AbstractControl;
        const message = { state: "", error: "" };

        if ((!touched && !dirty) || !errors) {
            return message;
        }

        for (const error of Object.entries(errors)) {
            const [typeError] = error;
            message.error = ErrorMessages[String(typeError)];
            message.state = "error";
        }

        return message;
    }

}