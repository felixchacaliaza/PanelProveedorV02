export const ErrorMessages: { [key: string]: string } = {
    required: "Debes completar esta información",
    pattern: "El valor ingresado es inválido"
}

export const ErrorMessagesEmail: { [key: string]: string } = {
    required: "El correo está errado o incompleto.",
    pattern: "El correo está errado o incompleto."
}

export const ErrorMessagesPhone: { [key: string]: string } = {
    required: "Debes completar esta información",
    pattern: "El número de celular está errado.",
    min: "Revisa el número, faltan algunos dígitos"
}