import { Component, OnInit, HostListener } from "@angular/core";
import { BreakpointObserver } from '@angular/cdk/layout';
import { CatalogModel, OccupationModel } from '@src/app/core/models/catalog.model';
import { Observable } from "rxjs";
import { GeolocationModel } from '@src/app/core/models/geolocation.model';
import { RegisterPersonalDataStateModel } from '@src/app/states/register-personal-data.state';
import { ViewPersonalPresenter } from './view-personal.presenter';
import { StatePresenter } from '@src/app/states/state.presenter';

export const STATUS = { state: "", message: "" };

@Component({
  selector: "view-personal",
  templateUrl: "./view-personal.html",
  styleUrls: ["./view-personal.scss"],
  providers: [ViewPersonalPresenter]
})
export class ViewPersonal implements OnInit {

  public registerPersonalDataState: RegisterPersonalDataStateModel;
  public isMobile: boolean = false;
  public departments$: Observable<GeolocationModel[]> = this._presenter.departments$;
  public provinces$: Observable<GeolocationModel[]> = this._presenter.provinces$;
  public districts$: Observable<GeolocationModel[]> = this._presenter.districts$;
  public professions$: Observable<CatalogModel[]> = this._presenter.professions$;
  public occupations$: Observable<OccupationModel[]> = this._presenter.occupations$;
  public data: any;
  public showLoader: boolean;
  public loader$: Observable<boolean> = this._presenter.loader$;

  constructor(
    private _presenter: ViewPersonalPresenter,
    private _statePresenter: StatePresenter,
    private _screen: BreakpointObserver
  ) {
    this.isMobile = this._isScreenMobile();
    this._statePresenter.selectStateRegisterPersonal().subscribe(registerPersonalDataState => {
      this.registerPersonalDataState = registerPersonalDataState
    });
  }

  ngOnInit() {
    this.showLoader = true;
    this._presenter.initialize()
      .then(() => {
        this.showLoader = false;
      })
    this._init();
  }

  public onNext(data: any): void {

    this.showLoader = true;
    this._presenter.saveData(data)
      .then(() => {
        this._statePresenter.updateStatePerson({ state: true, ...data });
        this._statePresenter.updateStateDetail({ emailLegalRepresentative: data.email });
        this.showLoader = false;
        this._presenter.redirectToNextPage();
      })

  }

  public onBack(event): void {
    this._presenter.redirectToBackPage();
  }

  public onChangeSelect(event: any) {
    if (event.key == "codeDepartment") {
      this._presenter.resetListProvinces();
      this._presenter.resetListDistricts();
      this._presenter.loadProvince(event.value);
    }

    if (event.key == "codeProvince") {
      this._presenter.resetListDistricts();
      const codes: string[] = event.value.split("-");
      this._presenter.loadDistrict(codes[0], codes[1]);
    }
  }

  private _isScreenMobile() {
    return this._screen.isMatched("(max-width: 767px)")
  }

  private _init() {

    let state = this.registerPersonalDataState;
    if (state.state == true) {
       this._presenter.loadProvince(state.codeDepartment);
       this._presenter.loadDistrict(state.codeDepartment, state.codeProvince);

      const _data = {
        ...state
      }
      this.data = _data;
    }

  }

  @HostListener("window:resize", ["$event"])
  getScreenSize(event) {
    this.isMobile = this._isScreenMobile();
  }

}
