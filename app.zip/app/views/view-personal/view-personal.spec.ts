/* tslint:disable:no-unused-variable */

import { ViewPersonalPresenter } from './view-personal.presenter';
import { StatePresenter } from '@src/app/states/state.presenter';
import { BreakpointObserver } from '@angular/cdk/layout';
import { ViewPersonal } from './view-personal';
import { TestBed } from '@angular/core/testing';
import { StateManagerModule } from '@src/app/states/state-manager.module';


xdescribe('@ViewPersonal', () => {
  let component: ViewPersonal;
  const StubViewPersonalPresenter = jasmine.createSpyObj(ViewPersonalPresenter, ["redirectToBackPage", "redirectToNextPage", "departments$", "provinces$", "districts$", "professions$", "occupations$", "saveData", "initialize", "loadProvince", "loadDistrict", "resetListProvinces", "resetListDistricts"]);
  const StubStatePresenter = jasmine.createSpyObj(StatePresenter, ["updateStatePerson", "updateStateDetail"])
  const StubBreakpointObserver = jasmine.createSpyObj(BreakpointObserver, ["isMatched"]);

  beforeEach(() => {

    TestBed.configureTestingModule({
      imports:[StateManagerModule]
    }).compileComponents();

    component = new ViewPersonal(StubViewPersonalPresenter, StubStatePresenter, StubBreakpointObserver);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe("When call the method onNext", () => {

    // it("should save the data",()=>{
    //   StubViewPersonalPresenter.saveData.and.returnValue(Promise.resolve({}));
    //   StubStatePresenter.updateStatePerson.and.callFake(()=>{})
    //   StubStatePresenter.updateStateDetail.and.callFake(()=>{})

    //   component.onNext({});

    //   expect(StubViewPersonalPresenter.saveData).toHaveBeenCalled()
    // })

    // it("should save in state detail",()=>{
    //   StubViewPersonalPresenter.saveData.and.returnValue(Promise.resolve({}));
    //   StubStatePresenter.updateStatePerson.and.callFake(()=>{})
    //   StubStatePresenter.updateStateDetail.and.callFake(()=>{})

    //   component.onNext({email:""});

    //   expect(StubStatePresenter.updateStateDetail).toHaveBeenCalled()
    // })


    // it("should save in state person", () => {
    //   // StubViewPersonalPresenter.saveData.and.returnValue(Promise.resolve({}));
    //   (<jasmine.Spy>StubViewPersonalPresenter.saveData).and.returnValue(Promise.resolve({}));
    //   (<jasmine.Spy>StubStatePresenter.updateStatePerson).and.callThrough();
    //   (<jasmine.Spy>StubStatePresenter.updateStateDetail).and.callThrough();


    //   component.onNext({});

    //   expect(<jasmine.Spy>StubStatePresenter.updateStatePerson).toHaveBeenCalled()
    // })


    // it("should redirect to next page",()=>{
    //   StubViewPersonalPresenter.saveData.and.returnValue(Promise.resolve({}));
    //   StubViewPersonalPresenter.redirectToNextPage.and.returnValue({})

    //   component.onNext({});

    //   expect(StubViewPersonalPresenter.redirectToNextPage).toHaveBeenCalled()
    // })
  })

  describe("when call method onBack", () => {
    it("shuld redirect to back page", () => {
      StubViewPersonalPresenter.redirectToBackPage.and.callThrough()

      component.onBack({});

      expect(StubViewPersonalPresenter.redirectToBackPage).toHaveBeenCalled()
    })
  })

  describe("when call method onChangeSelect", () => {
    it("should reset list province if deparment change", () => {
      StubViewPersonalPresenter.resetListProvinces.and.callThrough()
      StubViewPersonalPresenter.resetListDistricts.and.callThrough()
      StubViewPersonalPresenter.loadProvince.and.callThrough()

      component.onChangeSelect({ key: "codeDepartment", value: "01" })

      expect(StubViewPersonalPresenter.resetListProvinces).toHaveBeenCalled()
    })

    it("should reset list district if deparment change", () => {
      StubViewPersonalPresenter.resetListProvinces.and.callThrough()
      StubViewPersonalPresenter.resetListDistricts.and.callThrough()
      StubViewPersonalPresenter.loadProvince.and.callThrough()

      component.onChangeSelect({ key: "codeDepartment", value: "01" })

      expect(StubViewPersonalPresenter.resetListDistricts).toHaveBeenCalled()
    })

    it("should load list province if deparment change", () => {
      StubViewPersonalPresenter.resetListProvinces.and.callThrough()
      StubViewPersonalPresenter.resetListDistricts.and.callThrough()
      StubViewPersonalPresenter.loadProvince.and.callThrough()

      component.onChangeSelect({ key: "codeDepartment", value: "01" })

      expect(StubViewPersonalPresenter.loadProvince).toHaveBeenCalled()
    })

    it("should reset list district if deparment change", () => {
      StubViewPersonalPresenter.resetListProvinces.and.callThrough()
      StubViewPersonalPresenter.resetListDistricts.and.callThrough()
      StubViewPersonalPresenter.loadProvince.and.callThrough()

      component.onChangeSelect({ key: "codeProvince", value: "01-01" })

      expect(StubViewPersonalPresenter.resetListDistricts).toHaveBeenCalled()
    })
  })


  describe("when call the method init", () => {
    it("should load tha data from state", async() => {
      component.registerPersonalDataState = { state: true, codeDepartment: "01", codeProvince: "01" };
      StubViewPersonalPresenter.loadProvince.and.callFake(() => Promise.resolve({}))
      StubViewPersonalPresenter.loadDistrict.and.callFake(() => Promise.resolve({}))
      StubViewPersonalPresenter.initialize.and.callFake(() => Promise.resolve({}))

      component.ngOnInit();

      expect(component.data).toEqual({ state: true, codeDepartment: "01", codeProvince: "01" })
    })
  })

});
