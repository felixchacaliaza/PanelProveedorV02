import { ViewPersonalPresenter } from "./view-personal.presenter";
import { CatalogHttp } from '@src/app/core/http/catalog.http';
import { GeolocationHttp } from '@src/app/core/http/geolocation.http';
import { CurrentAccountsHttp } from '@src/app/core/http/current-accounts.http';
import { Router } from '@angular/router';
import { of } from 'rxjs';


describe("@ViewPersonalPresenter", () => {
    let presenter: ViewPersonalPresenter;
    const StubCatalogHttp = jasmine.createSpyObj(CatalogHttp, ["getListProfesion", "getListOccupations"]);
    const StubGeolocationHttp = jasmine.createSpyObj(GeolocationHttp, ["getListDepartment", "getListProvince", "getListDistrict"]);
    const StubCurrentHttp = jasmine.createSpyObj(CurrentAccountsHttp, ["initialData"]);
    const StubRouter = jasmine.createSpyObj(Router, ["navigateByUrl"]);

    beforeEach(() => {
        presenter = new ViewPersonalPresenter(StubCatalogHttp, StubGeolocationHttp, StubCurrentHttp, StubRouter);
    })

    describe('when call to initialize', () => {
        it('should load the departments', async () => {
            StubGeolocationHttp.getListDepartment.and.returnValue(of([{ code: "", description: "" }]));
            StubCatalogHttp.getListProfesion.and.returnValue(of([{ code: "", name: "" }]));
            StubCatalogHttp.getListOccupations.and.returnValue(of([{ code: "", name: "" }]));

            let result;
            presenter.departments$.subscribe(data => result = data);

            await presenter.initialize();

            expect(result).toEqual([{ code: "", description: "" }])
        })

        it('should load the profesions', async () => {
            StubGeolocationHttp.getListDepartment.and.returnValue(of([{ code: "", description: "" }]));
            StubCatalogHttp.getListProfesion.and.returnValue(of([{ code: "", name: "" }]));
            StubCatalogHttp.getListOccupations.and.returnValue(of([{ code: "", name: "" }]));

            let result;
            presenter.professions$.subscribe(data => result = data);

            await presenter.initialize();

            expect(result).toEqual([{ code: "", name: "" }])
        })

        it('should load the occupationss', async () => {
            StubGeolocationHttp.getListDepartment.and.returnValue(of([{ code: "", description: "" }]));
            StubCatalogHttp.getListProfesion.and.returnValue(of([{ code: "", name: "" }]));
            StubCatalogHttp.getListOccupations.and.returnValue(of([{ code: "", name: "" }]));

            let result;
            presenter.occupations$.subscribe(data => result = data);

            await presenter.initialize();

            expect(result).toEqual([{ code: "", name: "" }])
        })
    })

    describe("When call method loadProvince", () => {
        it("should load provinces", async () => {
            StubGeolocationHttp.getListProvince.and.returnValue(of([{ code: "", description: "" }]));
            let result;
            presenter.provinces$.subscribe(data => result = data);

            await presenter.loadProvince("01");

            expect(result).toEqual([{ code: "", description: "" }])
        })
    })

    describe("When call method loadDistrict", () => {
        it("should load districts", async () => {
            StubGeolocationHttp.getListDistrict.and.returnValue(of([{ code: "", description: "" }]));
            let result;
            presenter.districts$.subscribe(data => result = data);

            await presenter.loadDistrict("01", "01");

            expect(result).toEqual([{ code: "", description: "" }])
        })
    })

    describe("When call method resetListDepartments", () => {
        it("should clear the list deparments", () => {
            let result: any;
            presenter.departments$.subscribe(data => result = data);
            
            presenter.resetListDepartments();

            expect(result).toEqual([])
        })
    })

    describe("When call method resetListProvinces", () => {
        it("should clear the list provinces", () => {
            let result: any;
            presenter.provinces$.subscribe(data => result = data);
            
            presenter.resetListProvinces();

            expect(result).toEqual([])
        })
    })

    describe("When call method resetListDistricts", () => {
        it("should clear the list districts", () => {
            let result: any;
            presenter.districts$.subscribe(data => result = data);
            
            presenter.resetListDistricts();

            expect(result).toEqual([])
        })
    })

    describe("When call method redirectToNextPage", () => {
        it("should redirect to next page data business", () => {
            StubRouter.navigateByUrl.and.callThrough();
            
            presenter.redirectToNextPage();

            expect(StubRouter.navigateByUrl).toHaveBeenCalledWith("cta-cte/datos-negocio")
        })
    })

    describe("When call method redirectToBackPage", () => {
        it("should redirect to back page personaliza", () => {
            StubRouter.navigateByUrl.and.callThrough();
            
            presenter.redirectToBackPage();

            expect(StubRouter.navigateByUrl).toHaveBeenCalledWith("cta-cte/personaliza")
        })
    })

    describe("when call method handleError",()=>{
        it("should redirect to error",()=>{
            presenter.handleError({});
        })
    })

    describe("when call method saveData",()=>{
        it("should save the data of the person",async()=>{
            StubCurrentHttp.initialData.and.callFake(()=>of({}))
            
            await presenter.saveData({
                email:"text",
                phone:"",
                laborType:"text",
                profession:"text",
                laborCenter:"text",
                department:"geo",
                codeDepartment:"01",
                province:"geo",
                codeProvince:"01",
                district:"geo",
                codeDistrict:"01",
                address:"text"
            });

            expect(StubCurrentHttp.initialData).toHaveBeenCalled()
        })
    })

})