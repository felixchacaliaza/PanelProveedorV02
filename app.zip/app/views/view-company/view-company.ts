import { TypeCompanyModel } from './../../core/models/type-company.model';
import { Component, OnInit, HostListener } from "@angular/core";
import { BreakpointObserver } from '@angular/cdk/layout';
import { GeolocationModel } from '@src/app/core/models/geolocation.model';
import { RegisterCompanyDataStateModel } from '@src/app/states/register-company-data.state';
import { ModalService } from '@src/app/shared/services/modal-service';
import { ViewCompanyPresenter } from './view-company.presenter';
import { StatePresenter } from '@src/app/states/state.presenter';
import { Observable } from 'rxjs';

@Component({
  selector: "view-company",
  templateUrl: "./view-company.html",
  styleUrls: ["./view-company.scss"],
  providers: [ViewCompanyPresenter]
})
export class ViewCompany implements OnInit {

  public registerCompanyDataState: RegisterCompanyDataStateModel;

  public isScreenMobile: boolean = false;
  public currentModal: string = "";

  public showLoader: boolean;
  public departments$: Observable<GeolocationModel[]> = this._presenter.departments$;
  public provinces$: Observable<GeolocationModel[]> = this._presenter.provinces$;
  public districts$: Observable<GeolocationModel[]> = this._presenter.districts$;
  public typeCompanies$: Observable<TypeCompanyModel[]> = this._presenter.typeCompanies$;
  public data: any;
  public loader$: Observable<boolean> = this._presenter.loader$;


  constructor(
    private _presenter: ViewCompanyPresenter,
    private _statePresenter: StatePresenter,
    private _breakPointObserver: BreakpointObserver,
    private _modalSrv: ModalService
  ) {
    this.isScreenMobile = this.isMobile();

    this._statePresenter.selectStateRegisterCompany().subscribe(registerCompanyDataState => {
      this.registerCompanyDataState = registerCompanyDataState
    });
  }

  async ngOnInit(): Promise<void> {
    this._presenter.initialize();
    this._stateAll();
  }


  isMobile(): boolean {
    let result = this._breakPointObserver.isMatched("(max-width: 767px)");
    return result;
  }

  public onBack(event): void {
    this._presenter.redirectToBackPage();
  }

  public onNext(data: any) {
    this._presenter.saveData(data)
      .then(() => {
        return this._presenter.uploadFile(data.file);
      })
      .then(() => {
        this._statePresenter.updateStateCompany({ state: true, ...data });
        this._presenter.redirectToNextPage();
      })
  }

  public onSelect(event: any) {
    if (event.key == "codeDepartment") {
      this._presenter.resetListProvinces();
      this._presenter.resetListDistricts();
      this._presenter.loadProvinces(event.value);
    }

    if (event.key == "codeProvince") {
      this._presenter.resetListDistricts();
      const codes: string[] = event.value.split("-");
      this._presenter.loadDistricts(codes[0], codes[1]);
    }
  }

  public onModal(modalName: string): void {
    this.currentModal = modalName;
    this._modalSrv.openModal(modalName);
  }

  public closeModal(modalName: string): void {
    this.currentModal = "";
    this._modalSrv.closeModal(modalName);
  }

  public ctrlCloseModalCapitalSocial($event): void {
    this.currentModal = "";
  }


  private _stateAll(): void {
    let state = this.registerCompanyDataState;
    if (state.state === true) {
      this._presenter.loadProvinces(state.codeDepartment);
      this._presenter.loadDistricts(state.codeDepartment, state.codeProvince)
      const data = {
        ...state
      }
      this.data = data;
    }
  }


  @HostListener('window:resize', ['$event'])
  getScreenSize(event?) {
    setTimeout(() => {
      this.isScreenMobile = this.isMobile();
    }, 0);
  }
}
