import { Injectable } from "@angular/core";
import { FormBuilder, FormGroup } from '@angular/forms';
import { CompanyFormModel } from '../models/company-form.model';
import { BehaviorSubject, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { CurrentAccountsHttp } from '@src/app/core/http/current-accounts.http';
import { ppelValidators } from '@src/app/shared/validators/validators';
import { BcpValidators } from '@bcp/ng-core-v3/forms';

@Injectable()
export class CompanyFormPresenter {

    private _department = new BehaviorSubject<string>("");
    private _province = new BehaviorSubject<string>("");
    private _district = new BehaviorSubject<string>("");
    private _notifySelect = new BehaviorSubject<any>({});
    private _file = new BehaviorSubject<string>("");

    form!: FormGroup;

    destroy$ = new Subject();

    constructor(
        private _formBuilder: FormBuilder,
        private _currentHttp: CurrentAccountsHttp
    ) {
        const { getErrorMessage, ...rest } = new CompanyFormModel();
        this.form = this._formBuilder.group({
            ...rest
        })

        this.form.getError = (control: string) => getErrorMessage(control, this.form)
    }

    initialize() {
        this._watchDepartment();
        this._watchProvince();
        this._watchDistrict();
    }

    setForm(data: any): void {
        if (data && Object.entries(data).length > 0) {
            this.form.patchValue(data);
        }
    }

    get notifySelect$() {
        return this._notifySelect.asObservable();
    }

    get department$() {
        return this._department.asObservable();
    }

    get province$() {
        return this._province.asObservable();
    }

    get district$() {
        return this._district.asObservable();
    }

    updateFile(file: string) {
        this.form.get("file").setValue(file)
    }

    updateValidatorBusiness(action: string) {
        if (action == "remove") {
            const validators = []
            this.form.get("businessName").clearAsyncValidators();
            this.form.get("businessName").updateValueAndValidity();
        } else {
            
            const validators = [ppelValidators.customBusinessNameUseCreateCurrentAccount(this._currentHttp)]
            this.form.get("businessName").setAsyncValidators(validators);
            this.form.get("businessName").updateValueAndValidity();
        }

    }

    private _watchDepartment(): void {
        this.form.get("codeDepartment").valueChanges
            .pipe(takeUntil(this.destroy$))
            .subscribe(data => {
                if (data) {
                    this._department.next(data);
                    this.form.get("codeProvince").reset();
                    this.form.get("codeDistrict").reset();
                    this.form.get("address").reset();
                    this._notifySelect.next({ key: "codeDepartment", value: data });
                }
            })
    }

    private _watchProvince(): void {
        this.form.get("codeProvince").valueChanges
            .pipe(takeUntil(this.destroy$))
            .subscribe(data => {
                if (data) {
                    this._province.next(data);
                    this.form.get("codeDistrict").reset();
                    this.form.get("address").reset();
                    this._notifySelect.next({ key: "codeProvince", value: `${this.form.get("codeDepartment").value}-${data}` });
                }
            })
    }

    private _watchDistrict(): void {
        this.form.get("codeDistrict").valueChanges
            .pipe(takeUntil(this.destroy$))
            .subscribe(data => {
                if (data) {
                    this._district.next(data);
                    this.form.get("address").reset();
                    this._notifySelect.next({ key: "codeDistrict", value: data });
                }
            })
    }
}