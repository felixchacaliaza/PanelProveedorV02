import { CompanyFormPresenter } from "./company-form.presenter";
import { TestBed } from '@angular/core/testing';
import { ReactiveFormsModule, FormControl, AbstractControl } from '@angular/forms';
import { CompanyFormModel } from '../models/company-form.model';
import { CurrentAccountsHttp } from '@src/app/core/http/current-accounts.http';
import { BcpNetworkingModule } from '@bcp/ng-core-v3/networking';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ppelValidators } from '@src/app/shared/validators/validators';

describe("@CompanyFormPresenter", () => {
    let presenter: CompanyFormPresenter;
    let spyError: any;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [ReactiveFormsModule, BcpNetworkingModule, HttpClientTestingModule],
            providers: [CompanyFormPresenter, CurrentAccountsHttp]
        }).compileComponents();

        spyError = spyOn(CompanyFormModel.prototype, "getErrorMessage").and.returnValue({});

        presenter = TestBed.inject(CompanyFormPresenter);
        presenter.initialize();
    })

    describe("when call the method getError", () => {
        it("should be call getErrorMEssage", () => {
            presenter.form.getError("businessName");
            expect(spyError).toHaveBeenCalled();
        })
    })

    describe("When deparment change value", () => {

        it("Shoul call reset method of province form control", () => {
            const department = presenter.form.get("codeDepartment") as FormControl;
            const province = presenter.form.get("codeProvince") as FormControl;
            const spyProvinceReset = spyOn(province, "reset").and.callThrough();

            department.patchValue("");

            expect(spyProvinceReset).not.toHaveBeenCalled()

        })

        it("Shoul call reset method of province form control", () => {
            const department = presenter.form.get("codeDepartment") as FormControl;
            const province = presenter.form.get("codeProvince") as FormControl;
            const spyProvinceReset = spyOn(province, "reset").and.callThrough();

            department.patchValue("01");

            expect(spyProvinceReset).toHaveBeenCalled()

        })

        it("Shoul call reset method of district form control", () => {
            const department = presenter.form.get("codeDepartment") as FormControl;
            const district = presenter.form.get("codeDistrict") as FormControl;
            const spyDistrictReset = spyOn(district, "reset").and.callThrough();

            department.patchValue("01");

            expect(spyDistrictReset).toHaveBeenCalled()

        })

        it("Shoul call reset method of address form control", () => {
            const department = presenter.form.get("codeDepartment") as FormControl;
            const address = presenter.form.get("address") as FormControl;
            const spyAddressReset = spyOn(address, "reset").and.callThrough();

            department.patchValue("01");

            expect(spyAddressReset).toHaveBeenCalled()

        })

        it("Shoul call emit event notifySelect", () => {
            const department = presenter.form.get("codeDepartment") as FormControl;
            let result: any;
            presenter.notifySelect$.subscribe(value => result = value);

            department.patchValue("01");

            expect(result).toEqual({ key: "codeDepartment", value: "01" })

        })
    })

    describe("When province change value", () => {

        it("Shoul call reset method of district form control", () => {
            const province = presenter.form.get("codeProvince") as FormControl;
            const district = presenter.form.get("codeDistrict") as FormControl;
            const spyDistrictReset = spyOn(district, "reset").and.callThrough();

            province.patchValue("01");

            expect(spyDistrictReset).toHaveBeenCalled()

        })

        it("Shoul call reset method of address form control", () => {
            const province = presenter.form.get("codeProvince");
            const address = presenter.form.get("address");
            const spyAddressReset = spyOn(address, "reset").and.callThrough();

            province.patchValue("01");

            expect(spyAddressReset).toHaveBeenCalled()

        })

        it("Shoul call emit event notifySelect", () => {
            const department = presenter.form.get("codeDepartment") as FormControl;
            const province = presenter.form.get("codeProvince") as FormControl;

            let result: any;
            presenter.notifySelect$.subscribe(value => result = value);
            department.patchValue("02")
            province.patchValue("01");

            expect(result).toEqual({ key: "codeProvince", value: "02-01" })

        })
    })

    describe("When district change value", () => {


        it("Shoul call reset method of address form control", () => {
            const district = presenter.form.get("codeDistrict");
            const address = presenter.form.get("address");
            const spyAddressReset = spyOn(address, "reset").and.callThrough();

            district.patchValue("01");

            expect(spyAddressReset).toHaveBeenCalled()

        })

        it("Shoul call emit event notifySelect", () => {

            const district = presenter.form.get("codeDistrict") as FormControl;
            let result: any;
            presenter.notifySelect$.subscribe(value => result = value);

            district.patchValue("01");

            expect(result).toEqual({ key: "codeDistrict", value: "01" })

        })
    })

    describe("#updateFile",()=>{
        it("should set value in the field file",()=>{
            const value = "abc";

            presenter.updateFile(value);

            expect(presenter.form.get("file").value).toBe(value)
        })
    })

    describe("#setForm",()=>{
        it("should set value in the form",()=>{
            const value = { businessName: "abc", codetypeCompany:"abc",socialCapital:"abc",codeDepartment:"abc",codeProvince:"abc", codeDistrict: "abc", address:"abc", file:"abc"};

            presenter.setForm(value);

            expect(presenter.form.value).toEqual(value)
        })
    })

    describe("When call the method updateValidatorBusiness",()=>{
        it("if param is 'remove'  should delete validator async",()=>{
            const service = TestBed.inject(CurrentAccountsHttp);
            const asyncValidators = [ppelValidators.customBusinessNameUseCreateCurrentAccount(service)];
            const businessName = presenter.form.get("businessName") as AbstractControl;
            businessName.setAsyncValidators(asyncValidators);

            presenter.updateValidatorBusiness("remove");
            
        })

        it("if param is different to 'remove'  should add validator async",()=>{                    

            presenter.updateValidatorBusiness("add");
            
        })
    })
})