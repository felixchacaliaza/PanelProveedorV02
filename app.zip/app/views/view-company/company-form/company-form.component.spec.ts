import { CompanyFormComponent } from "./company-form.component";
import { CompanyFormPresenter } from './company-form.presenter';
import { FormGroup, FormControl } from '@angular/forms';
import { of } from 'rxjs';

describe("@CompanyFormComponent",()=>{
    let component: CompanyFormComponent;
    const StubCompanyFormPresenter = jasmine.createSpyObj(CompanyFormPresenter,["initialize","notifySelect$","destroy$","updateValidatorBusiness","updateFile"])

    beforeEach(()=>{
        component = new CompanyFormComponent(StubCompanyFormPresenter);
    })

    describe("#btnNext",()=>{
        it("Should emit a value of form",()=>{
            const spyNext = spyOn(component.onNext,"emit").and.callThrough();
            component.fileData = "abc";
            component.fileItem = "abc"; 
            component.departments =[{ code: "01", description: "Lima"}];
            component.provinces =[{ code: "01", description: "Lima"}];
            component.districts =[{ code: "01", description: "Lima"}];
            component.typeCompanies =[{ code: "01", name: "EIRL"}];
            component.form = new FormGroup({
                businessName: new FormControl("abc"),
                codetypeCompany:new FormControl("01"),
                socialCapital:new FormControl("abc"),
                codeDepartment:new FormControl("01"),
                codeProvince:new FormControl("01"),
                codeDistrict:new FormControl("01"),
                address:new FormControl("abc")
            })           

            component.btnNext();

            expect(spyNext).toHaveBeenCalled()

        })
    })

    describe("#ngOnDestroy",()=>{
        it("should remove subscription of form",()=>{
            const spyNext = jasmine.createSpy();
            StubCompanyFormPresenter.destroy$ = {
                next: spyNext,
                complete: jasmine.createSpy()
            }

            component.ngOnDestroy();

            expect(spyNext).toHaveBeenCalled()
        })

        it("should remove subscription of form",()=>{
            const spyComplete = jasmine.createSpy();
            StubCompanyFormPresenter.destroy$ = {
                next:jasmine.createSpy(),
                complete:  spyComplete
            }

            component.ngOnDestroy();

            expect(spyComplete).toHaveBeenCalled()
        })
    })

    describe("#btnBack",()=>{
        it("should emit event about return back page",()=>{
            const spyBack = spyOn(component.onBack,"emit").and.callThrough();

            component.btnBack();

            expect(spyBack).toHaveBeenCalled();
        })
    })

    describe("#btnModal",()=>{
        it("should emit event about open modal",()=>{
            const spyModal = spyOn(component.onModal,"emit").and.callThrough();

            component.btnModal("idmodal");

            expect(spyModal).toHaveBeenCalled()
        })
    })

    describe("#ctrlBlurBusiness",()=>{
        it("should add a valitador async",()=>{
            StubCompanyFormPresenter.updateValidatorBusiness.and.callThrough();

            component.ctrlBlurBusiness({});

            expect(StubCompanyFormPresenter.updateValidatorBusiness).toHaveBeenCalled()
        })
    })

    describe("#ctrlInputBusiness",()=>{
        it("should remove a validator async",()=>{
            StubCompanyFormPresenter.updateValidatorBusiness.and.callThrough();

            component.ctrlInputBusiness({});

            expect(StubCompanyFormPresenter.updateValidatorBusiness).toHaveBeenCalled()
        })
    })

    // describe("#eventCtrlFileOptionClick",()=>{
        // it("should delete the value of file if optio 'delete' is clicked",()=>{
        //     StubCompanyFormPresenter.updateFile.and.callThrough();

        //     component.eventCtrlFileOptionClick(<CustomEvent>{ detail: { option: {message:"Eliminar"}}})

        //     expect(StubCompanyFormPresenter.updateFile).toHaveBeenCalled()
        // })

        // it("don't should delete the value of file if option is different to 'delete'",()=>{
        //     StubCompanyFormPresenter.updateFile.and.callThrough();

        //     component.eventCtrlFileOptionClick(<CustomEvent>{ detail: { option: {message:"abc"}}})

        //     expect(StubCompanyFormPresenter.updateFile).not.toHaveBeenCalled()
        // })
    // })

    // describe("when call the method ngOnInit",()=>{
    //     it("should initialize listengn change",()=>{
    //         StubCompanyFormPresenter.initialize.and.callThrough();
    //         StubCompanyFormPresenter.notifySelect$ = of()
            
    //         component.ngOnInit();

    //         expect(StubCompanyFormPresenter.initialize).toHaveBeenCalled()
    //     })
       
    // })

})