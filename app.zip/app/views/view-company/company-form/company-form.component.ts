import { Component, OnInit, OnDestroy, Input, Output, EventEmitter, ChangeDetectionStrategy } from "@angular/core";
import { CompanyFormPresenter } from './company-form.presenter';
import { GeolocationModel } from '@src/app/core/models/geolocation.model';
import { TypeCompanyModel } from '@src/app/core/models/type-company.model';
import { takeUntil } from 'rxjs/operators';
import { EXTENSIONS, FILE_OPTIONS, RESOURCE_INFO, MAX_FILE_SIZE, MAX_FILE_LIMIT } from '@src/app/constants/file';


@Component({
    selector: "ppel-company-form",
    templateUrl: "./company-form.component.html",
    styleUrls: ["./company-form.component.scss"],
    providers: [CompanyFormPresenter]
})
export class CompanyFormComponent implements OnInit, OnDestroy {

    @Input()
    typeCompanies: TypeCompanyModel[] = [];

    @Input()
    departments: GeolocationModel[] = [];

    @Input()
    provinces: GeolocationModel[] = [];

    @Input()
    districts: GeolocationModel[] = [];

    @Input()
    set data(value: any) {
        this._presenter.setForm(value);
    }

    @Output()
    onSelect = new EventEmitter<any>();

    @Output()
    onModal = new EventEmitter<string>();

    @Output()
    onNext = new EventEmitter<any>();

    @Output()
    onBack = new EventEmitter<any>();

    form = this._presenter.form;

    public fileItem: any;
    public fileData: any;
    public fileReader: any;
    public isValidBusinessName: boolean = false;
    public fileExtensions = EXTENSIONS;
    public fileOptions = FILE_OPTIONS;
    public resourcesInfo = RESOURCE_INFO;
    public maxFileSize = MAX_FILE_SIZE;
    public fileLimit = MAX_FILE_LIMIT;

    constructor(
        private _presenter: CompanyFormPresenter
    ) {

    }

    ngOnInit() {
        this._presenter.initialize();
        this._presenter.notifySelect$
            .pipe(takeUntil(this._presenter.destroy$))
            .subscribe(select => this.onSelect.emit(select))
    }

    ngOnDestroy() {
        this._presenter.destroy$.next();
        this._presenter.destroy$.complete();
    }

    btnNext(): void {
        this.onNext.emit(this._buildData())
    }

    btnBack(): void {
        this.onBack.emit();
    }

    btnModal(nameModal: string): void {
        this.onModal.emit(nameModal);
    }

    ctrlBlurBusiness(event) {
        this._presenter.updateValidatorBusiness("add");       
    }

    ctrlInputBusiness(event){
        this._presenter.updateValidatorBusiness("remove")
    }

    eventCtrlFileSizeExceeded(event: CustomEvent) {
    }

    eventCtrlFileOptionClick(event: CustomEvent) {
        let option = event.detail.option.message;
        if (option == "Eliminar") {
            this._presenter.updateFile("");
        }
    }

    eventCtrlFileToUpload(event: CustomEvent) {
        const { fileData, fileItem } = event.detail;
        this.fileData = fileData;
        this.fileItem = fileItem;
        this.uploadFile(fileData, fileItem);
    }

    eventCtrlFileDone(event: CustomEvent) {

        const reader = new FileReader();
        reader.onload = ((reader: any) => {
            return () => {
                const result: string = reader.result;
                this.fileReader = result.split(";base64,")[1];
                this._presenter.updateFile(this.fileReader)

            }
        })(reader)
        reader.readAsDataURL(this.fileData);
    }

    private _buildData() {
        return {
            ...this.form.value,         
            fileData: this.fileData,
            fileItem: this.fileItem,
            department: this.departments.find(dp => dp.code == this.form.get("codeDepartment").value).description,
            province: this.provinces.find(pv => pv.code == this.form.get("codeProvince").value).description,
            district: this.districts.find(di => di.code == this.form.get("codeDistrict").value).description,
            codetypeCompanyName: this.typeCompanies.find(tc => tc.code == this.form.get("codetypeCompany").value).name
        }
    }

    private uploadFile(fileData: any, fileItem: any) {

        const reader = new FileReader();
        reader.readAsDataURL(fileData);

        reader.onprogress = (data) => {
            if (data.lengthComputable) {
                var progress = ((data.loaded / data.total) * 100);
                this.updateUploadProgress(fileItem, progress);
            }
        }
    }

    private updateUploadProgress(fileItem: any, progress: number) {
        let element: any = document.getElementById("cardAddFile1");
        if (element) element["updateProgress"](fileItem, progress);
    }


}