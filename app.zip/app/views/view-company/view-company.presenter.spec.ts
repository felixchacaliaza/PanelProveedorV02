import { ViewCompanyPresenter } from "./view-company.presenter";
import { GeolocationHttp } from '@src/app/core/http/geolocation.http';
import { CatalogHttp } from '@src/app/core/http/catalog.http';
import { DatosHttp } from '@src/app/core/http/datos.http';
import { DocumentHttp } from '@src/app/core/http/document.http';
import { Router } from '@angular/router';
import { of } from 'rxjs';

describe("@ViewCompanyPresenter", () => {
    let service: ViewCompanyPresenter;
    const StubGeolocationHttp = jasmine.createSpyObj(GeolocationHttp, ["getListDepartment", "getListProvince", "getListDistrict"]);
    const StubCatalogHttp = jasmine.createSpyObj(CatalogHttp, ["getListTypeCompany"]);
    const StubDatosHttp = jasmine.createSpyObj(DatosHttp, ["initialData"]);
    const StubDocumentHttp = jasmine.createSpyObj(DocumentHttp, ["uploadDocument"]);
    const StubRouter = jasmine.createSpyObj(Router, ["navigateByUrl"]);

    beforeEach(() => {
        service = new ViewCompanyPresenter(StubGeolocationHttp, StubCatalogHttp, StubDatosHttp, StubDocumentHttp, StubRouter);
    })

    describe("When call the method initialize", () => {
        it("should load list departments", async () => {
            StubGeolocationHttp.getListDepartment.and.callFake(() => of([]));
            StubCatalogHttp.getListTypeCompany.and.callFake(() => of([]));

            await service.initialize();

            expect(StubGeolocationHttp.getListDepartment).toHaveBeenCalled()
        })

        it("should load list type companies", async () => {
            StubGeolocationHttp.getListDepartment.and.callFake(() => of([]));
            StubCatalogHttp.getListTypeCompany.and.callFake(() => of([]));

            await service.initialize();

            expect(StubCatalogHttp.getListTypeCompany).toHaveBeenCalled()
        })
    })

    describe("when call the method loadProvinces", () => {
        it("should load the list provinces", async () => {
            StubGeolocationHttp.getListProvince.and.callFake(() => of([]));

            await service.loadProvinces("01")

            expect(StubGeolocationHttp.getListProvince).toHaveBeenCalled()
        })
    })

    describe("when call the method loadDistrict", () => {
        it("should load the list districts", async () => {
            StubGeolocationHttp.getListDistrict.and.callFake(() => of([]));

            await service.loadDistricts("01", "01")

            expect(StubGeolocationHttp.getListDistrict).toHaveBeenCalled()
        })
    })

    describe("when call the mthod resetListDepartment", () => {
        it("should reset list of departments", () => {
            let result: any;
            service.departments$.subscribe(data => result = data);

            service.resetListDepartments();

            expect(result).toEqual([])
        })
    })

    describe("when call the mthod resetListProvinces", () => {
        it("should reset list of provinces", () => {
            let result: any;
            service.provinces$.subscribe(data => result = data);

            service.resetListProvinces();

            expect(result).toEqual([])
        })
    })

    describe("when call the mthod resetListDistrict", () => {
        it("should reset list of districts", () => {
            let result: any;
            service.districts$.subscribe(data => result = data);

            service.resetListDistricts();

            expect(result).toEqual([])
        })
    })

    describe("when call the method redirectToBackPage", () => {
        it("should go to the page before", () => {
            StubRouter.navigateByUrl.and.callThrough();

            service.redirectToBackPage();

            expect(StubRouter.navigateByUrl).toHaveBeenCalledWith("cta-cte/datos-personales")
        })
    })

    describe("when call the method redirectToNextPage", () => {
        it("should go to the page before", () => {
            StubRouter.navigateByUrl.and.callThrough();

            service.redirectToNextPage();

            expect(StubRouter.navigateByUrl).toHaveBeenCalledWith("cta-cte/detalle")
        })
    })

    describe("when call the method uploadFile", () => {
        it("should upload the file", () => {
            StubDocumentHttp.uploadDocument.and.callFake(() => of({}));

            service.uploadFile("abc");

            expect(StubDocumentHttp.uploadDocument).toHaveBeenCalled()
        })
    })

    describe("When call the method saveData",()=>{
        it("shuld save the company data",()=>{
            StubDatosHttp.initialData.and.callFake(()=>of());

            service.saveData({businessName:"",codetypeCompany:"",socialCapital:"",department:"",codeDepartment:"",province:"",codeProvince:"",district:"",codeDistrict:"",address:""});

            expect(StubDatosHttp.initialData).toHaveBeenCalled();
        })
    })
})