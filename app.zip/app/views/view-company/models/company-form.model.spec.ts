import { Component } from "@angular/core";
import { FormGroup, FormBuilder, ReactiveFormsModule, AbstractControl, ValidationErrors } from '@angular/forms';
import { CompanyFormModel } from './company-form.model';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

@Component({
    template: ""
})
class SanboxComponent {
    form: FormGroup;
    constructor(private _formBuilder: FormBuilder) {
        const { getErrorMessage, ...rest } = new CompanyFormModel();
        this.form = this._formBuilder.group({
            ...rest
        })
        this.form.getError = (control: string) => getErrorMessage(control, this.form);
    }
}

describe("@CompanyFormModel", () => {
    let component: SanboxComponent;
    let fixture: ComponentFixture<SanboxComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            imports: [ReactiveFormsModule],
            declarations: [SanboxComponent]
        }).compileComponents()

        fixture = TestBed.createComponent(SanboxComponent);
        component = fixture.componentInstance;
    }))

    describe("when form initalize", () => {
        it("should be default value buinessName equal to ''", () => {
            const businessName = component.form.get("businessName") as AbstractControl;

            expect(businessName.value).toBe("")
        })

        it("should")
    })

    describe("when businessName change value", () => {
        it("should be invalid when empty value", () => {
            const businessName = component.form.get("businessName") as AbstractControl;

            businessName.patchValue("");

            expect(businessName.valid).toBeFalsy()
        })
    })

    describe("when call method getErrorMessage", () => {
        it("should be return message when touched  and dirty control", () => {
            const control = {
                touched: true,
                dirty: true,
                errors: { required: "Debes completar esta información" } as ValidationErrors
            } as AbstractControl

            spyOn(component.form,"get").and.returnValue(control)

            const message = component.form.getError("");

            expect(message).toEqual({ state: "error", error: "Debes completar esta información"})
        })

        it("should be return empty when no touched  and no dirty control", () => {
            const control = {
                touched: false,
                dirty: false
            } as AbstractControl

            spyOn(component.form,"get").and.returnValue(control)

            const message = component.form.getError("");

            expect(message).toEqual({ state: "", error: ""})
        })
    })
})