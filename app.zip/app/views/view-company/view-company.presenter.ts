import { Injectable } from "@angular/core";
import { BehaviorSubject, forkJoin } from 'rxjs';
import { TypeCompanyModel } from '@src/app/core/models/type-company.model';
import { GeolocationModel } from '@src/app/core/models/geolocation.model';
import { GeolocationHttp } from '@src/app/core/http/geolocation.http';
import { CatalogHttp } from '@src/app/core/http/catalog.http';
import { map } from 'rxjs/operators';
import { Router } from '@angular/router';
import { IInititalDataHttpRequest } from '@src/app/core/models/initial-data.model';
import { DatosHttp } from '@src/app/core/http/datos.http';
import { DocumentHttp } from '@src/app/core/http/document.http';

@Injectable()
export class ViewCompanyPresenter {

    private _typeCompanies = new BehaviorSubject<TypeCompanyModel[]>([]);
    private _departments = new BehaviorSubject<GeolocationModel[]>([]);
    private _provinces = new BehaviorSubject<GeolocationModel[]>([]);
    private _districts = new BehaviorSubject<GeolocationModel[]>([]);
    private _loader = new BehaviorSubject<boolean>(false);

    constructor(
        private _geolocationHttp: GeolocationHttp,
        private _catalogHttp: CatalogHttp,
        private _datosHttp: DatosHttp,
        private _documentHttp: DocumentHttp,
        private _router: Router
    ) { }

    get typeCompanies$() {
        return this._typeCompanies.asObservable();
    }

    get departments$() {
        return this._departments.asObservable();
    }

    get provinces$() {
        return this._provinces.asObservable();
    }

    get districts$() {
        return this._districts.asObservable();
    }

    get loader$() {
        return this._loader.asObservable();
    }

    async initialize() {
        this._loader.next(true);
        const _callDepartments = this._geolocationHttp.getListDepartment();
        const _callTypeCompanies = this._catalogHttp.getListTypeCompany();

        const { resDepartments, resTypeCompanies } = await forkJoin({
            resDepartments: _callDepartments.pipe(map(data => data)),
            resTypeCompanies: _callTypeCompanies.pipe(map(data => data))
        }).toPromise()

        this._typeCompanies.next(resTypeCompanies);
        this._departments.next(resDepartments);
        this._loader.next(false);
    }

    async loadProvinces(codeDepartment: string) {
        this._loader.next(true);
        const _callProvinces = this._geolocationHttp.getListProvince(codeDepartment);
        const { resProvinces } = await forkJoin({
            resProvinces: _callProvinces.pipe(map(data => data))
        }).toPromise()

        this._provinces.next(resProvinces);
        this._loader.next(false);
    }

    async loadDistricts(codeDepartment: string, codeProvince: string) {
        this._loader.next(true);
        const _callDistricts = this._geolocationHttp.getListDistrict(codeDepartment, codeProvince);
        const { resDistricts } = await forkJoin({
            resDistricts: _callDistricts.pipe(map(data => data))
        }).toPromise();

        this._districts.next(resDistricts);
        this._loader.next(false);
    }

    resetListDepartments(): void {
        this._departments.next([]);
    }

    resetListProvinces(): void {
        this._provinces.next([]);
    }

    resetListDistricts(): void {
        this._districts.next([]);
    }

    redirectToNextPage(): void {
        this._router.navigateByUrl("cta-cte/detalle")
    }

    redirectToBackPage(): void {
        this._router.navigateByUrl("cta-cte/datos-personales")
    }

    async saveData(data: any) {
        this._loader.next(true);
        const request = this._buildRequest(data);
        this._datosHttp.initialData(request).toPromise()
            .then(res => {
                this._loader.next(false);
                return res;
            })
    }

    uploadFile(file: string) {
        this._loader.next(true);
        return this._documentHttp.uploadDocument(file).toPromise()
            .then(res => {
                this._loader.next(false);
                return res;
            })
    }

    private _buildRequest(data: any): IInititalDataHttpRequest {
        return <IInititalDataHttpRequest>{
            company: {
                businessName: data.businessName,
                businessType: data.codetypeCompany,
                socialCapital: data.socialCapital,
                address: {
                    department: {
                        description: data.department,
                        code: data.codeDepartment
                    },
                    province: {
                        description: data.province,
                        code: data.codeProvince
                    },
                    district: {
                        description: data.district,
                        code: data.codeDistrict
                    },
                    address: data.address
                }
            },

            configuration: {
                step: 'COMPANY_STEP'
            }
        }
    }
}