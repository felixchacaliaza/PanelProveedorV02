/* tslint:disable:no-unused-variable */

import { ViewCompany } from './view-company';
import { ModalService } from '@src/app/shared/services/modal-service';
import { ViewCompanyPresenter } from './view-company.presenter';
import { StatePresenter } from '@src/app/states/state.presenter';
import { BreakpointObserver } from '@angular/cdk/layout';
import { of } from 'rxjs';

describe('@ViewCompany', () => {
  let component: ViewCompany;
  const StubStatePresenter = jasmine.createSpyObj(StatePresenter,["updateStateCompany","selectStateRegisterCompany"])
  const StubViewCompanyPresenter= jasmine.createSpyObj(ViewCompanyPresenter,["initialize","redirectToBackPage","redirectToNextPage","saveData","uploadFile","resetListProvinces","resetListDistricts","loadProvinces","loadDistricts"]);
  const StubBreakpointObserver = jasmine.createSpyObj(BreakpointObserver,["isMatched"]);
  const StubModalService = jasmine.createSpyObj(ModalService,["openModal","closeModal"]);


  beforeEach(() => {
    StubStatePresenter.selectStateRegisterCompany.and.returnValue(of('some value'));
    component = new ViewCompany(StubViewCompanyPresenter,StubStatePresenter,StubBreakpointObserver,StubModalService);
  });

  it("Should create app",()=>{
    expect(component).toBeTruthy()
  })

  describe("#onBack",()=>{
    it("should go to before page",()=>{
      StubViewCompanyPresenter.redirectToBackPage.and.callThrough();

      component.onBack({});

      expect(StubViewCompanyPresenter.redirectToBackPage).toHaveBeenCalled()
    })
  })

  describe("When call the method onSelect",()=>{
    it("should reset list provinces if department change",()=>{
      StubViewCompanyPresenter.resetListProvinces.and.callThrough();
      StubViewCompanyPresenter.resetListDistricts.and.callThrough();
      StubViewCompanyPresenter.loadProvinces.and.callThrough();

      component.onSelect({key: "codeDepartment",value:"01"});

      expect(StubViewCompanyPresenter.resetListProvinces).toHaveBeenCalled()
    })

    it("should reset list district if department change",()=>{
      StubViewCompanyPresenter.resetListProvinces.and.callThrough();
      StubViewCompanyPresenter.resetListDistricts.and.callThrough();
      StubViewCompanyPresenter.loadProvinces.and.callThrough();

      component.onSelect({key: "codeDepartment",value:"01"});

      expect(StubViewCompanyPresenter.resetListDistricts).toHaveBeenCalled()
    })

    it("should load list provinces if department change",()=>{
      StubViewCompanyPresenter.resetListProvinces.and.callThrough();
      StubViewCompanyPresenter.resetListDistricts.and.callThrough();
      StubViewCompanyPresenter.loadProvinces.and.callThrough();

      component.onSelect({key: "codeDepartment",value:"01"});

      expect(StubViewCompanyPresenter.loadProvinces).toHaveBeenCalled()
    })

    it("should reset list district if province change",()=>{
      StubViewCompanyPresenter.resetListProvinces.and.callThrough();
      StubViewCompanyPresenter.resetListDistricts.and.callThrough();
      StubViewCompanyPresenter.loadProvinces.and.callThrough();

      component.onSelect({key: "codeProvince",value:"01"});

      expect(StubViewCompanyPresenter.resetListDistricts).toHaveBeenCalled()
    })
  })

  describe("#onModal",()=>{
    it("should open the modal with id name",()=>{
      StubModalService.openModal.and.callThrough();

      component.onModal("idmodal");

      expect(StubModalService.openModal).toHaveBeenCalled()
    })
  })

  describe("#closeModal",()=>{
    it("should close the modal",()=>{
      StubModalService.closeModal.and.callThrough();

      component.closeModal("idmodal");

      expect(StubModalService.closeModal).toHaveBeenCalled();
    })
  })

  describe("when call the method ctrlCloseModalCapitalSocia",()=>{
    it("should reset var currenModall",()=>{
      component.currentModal = "idmodal";

      component.ctrlCloseModalCapitalSocial({});

      expect(component.currentModal).toBe("")
    })
  })

  describe("When init the component",()=>{
    it("should initialize list of department and catalog",()=>{
      StubViewCompanyPresenter.initialize.and.callThrough();
      StubViewCompanyPresenter.loadProvinces.and.callThrough();
      StubViewCompanyPresenter.loadDistricts.and.callThrough();
      component.registerCompanyDataState = { state: true, codeDepartment: "01", codeProvince: "01"}

      component.ngOnInit();

      expect(StubViewCompanyPresenter.initialize).toHaveBeenCalled();
    })

    it("should get data from state",()=>{
      StubViewCompanyPresenter.initialize.and.callThrough();
      StubViewCompanyPresenter.loadProvinces.and.callThrough();
      StubViewCompanyPresenter.loadDistricts.and.callThrough();
      component.registerCompanyDataState = { state: true, codeDepartment: "01", codeProvince: "01"}

      component.ngOnInit();

      expect(component.data).toEqual({ state: true, codeDepartment: "01", codeProvince: "01"})
    })

    it("don't should get data from state",()=>{
      StubViewCompanyPresenter.initialize.and.callThrough();
      StubViewCompanyPresenter.loadProvinces.and.callThrough();
      StubViewCompanyPresenter.loadDistricts.and.callThrough();
      component.registerCompanyDataState = { state: false}

      component.ngOnInit();

      expect(component.data).toEqual(undefined)
    })
  })

});
