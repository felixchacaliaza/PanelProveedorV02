import { BreakpointObserver } from '@angular/cdk/layout';
import { ChangeDetectorRef, Component, ElementRef, ViewChild, AfterViewInit, HostListener } from '@angular/core';
import { BcpMicroFrontendRouter } from '@bcp/ng-micro-frontends-v3/router';

@Component({
  selector: 'view-error',
  templateUrl: './view-error.html',
  styleUrls: ['./view-error.scss'],
})
export class ViewError implements AfterViewInit {

  @ViewChild('lMainCenterContent')
  lMainCenterContent: ElementRef;

  @ViewChild('lMainCenter')
  lMainCenter: ElementRef;
  screenHeight;
  screenWidth;
  styleMinHeightlMainCenterContent = '';
  styleMinHeightlMainCenter = '';
  showLoader: boolean;
  currentModal: string = "";
  isScreenMobile: boolean = false;


  constructor(
    private _microfrontendRouter: BcpMicroFrontendRouter,
    private _breakPointObserver: BreakpointObserver,
    private changeDetectorRef: ChangeDetectorRef,

  ) {
    window.addEventListener('resize', () => {
      this.changeDetectorRef.detectChanges();
      this.isScreenMobile = this.isMobile();
      this.changeDetectorRef.detectChanges();
      this.getChangeHeightMainCenterContent();
      this.changeDetectorRef.detectChanges();

    });

  }


  ngAfterViewInit(): void {
    this.changeDetectorRef.detectChanges();
    this.getChangeHeightMainCenterContent();
    this.changeDetectorRef.detectChanges();
  }

  getChangeHeightMainCenterContent() {
    this.changeDetectorRef.detectChanges();
    this.getScreenSize();

    if (this.screenWidth < 188) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 348px)`;
    } else if (this.screenWidth < 264) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 328px)`;
    } else if (this.screenWidth < 279) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 293px)`;
    } else if (this.screenWidth < 314) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 287px)`;
    } else if (this.screenWidth < 528) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 285px)`;
    } else if (this.screenWidth < 576) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 255px)`;
    } else if (this.screenWidth < 768) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 255px)`;
    } else if (this.screenWidth < 992) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 179px)`;
    } else if (this.screenWidth < 1199) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 160px)`;
    } else {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 160px)`;
    }

  }
  @HostListener('window:resize', ['$event'])
  getScreenSize(event?) {
    this.changeDetectorRef.detectChanges();
    this.screenHeight = window.innerHeight;
    this.screenWidth = window.innerWidth;
  }


  isMobile(): boolean {
    let result = this._breakPointObserver.isMatched("(max-width: 767px)");
    return result;
  }

  btnModalAgency(): void {
    window.open("https://www.viabcp.com/canales-presenciales");
  }

  btnModalCloseFile(): void {
    this._microfrontendRouter.navigateByUrl("producto/lista", "catalogo")
  }



}
