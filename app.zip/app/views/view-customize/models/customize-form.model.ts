import { BcpValidators } from '@bcp/ng-core-v3/forms';
import { FormGroup, AbstractControl } from '@angular/forms';
import { ErrorMessage } from './customize-form-constants';

export class CustomizeFormModel{
    money = ["",[BcpValidators.required]];
    department = ["",[BcpValidators.required]];
    district = ["",[BcpValidators.required]];

    getErrorMessage(control:string, form: FormGroup):Object{
        const { touched, dirty, errors} = form.get(control) as AbstractControl;
        const message = { state: "", error: ""};

        if((!touched && !dirty) || !errors){
            return message;
        }

        for(const error of Object.entries(errors)){
            const [typeError] = error;
            message.state = "error";
            message.error = ErrorMessage[String(typeError)];
        }

        return message;
    }
}