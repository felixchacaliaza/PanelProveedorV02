import { Component } from "@angular/core";
import { FormGroup, FormBuilder, ReactiveFormsModule, AbstractControl, ValidationErrors } from '@angular/forms';

import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { CustomizeFormModel } from './customize-form.model';

@Component({
    template: ""
})
class SanboxComponent {
    form: FormGroup;
    constructor(private _formBuilder: FormBuilder) {
        const { getErrorMessage, ...rest } = new CustomizeFormModel();
        this.form = this._formBuilder.group({
            ...rest
        })
        this.form.getError = (control: string) => getErrorMessage(control, this.form);
    }
}

describe("@CustomizeFormModel", () => {
    let component: SanboxComponent;
    let fixture: ComponentFixture<SanboxComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            imports: [ReactiveFormsModule],
            declarations: [SanboxComponent]
        }).compileComponents()

        fixture = TestBed.createComponent(SanboxComponent);
        component = fixture.componentInstance;
    }))

    describe("when form initalize", () => {
        it("should be default value money equal to ''", () => {
            const money = component.form.get("money") as AbstractControl;

            expect(money.value).toBe("")
        })

        it("should")
    })

    describe("when money change value", () => {
        it("should be invalid when empty value", () => {
            const money = component.form.get("money") as AbstractControl;

            money.patchValue("");

            expect(money.valid).toBeFalsy()
        })
    })

    describe("when call method getErrorMessage", () => {
        it("should be return message when touched  and dirty control", () => {
            const control = {
                touched: true,
                dirty: true,
                errors: { required: "Debes completar esta información" } as ValidationErrors
            } as AbstractControl

            spyOn(component.form,"get").and.returnValue(control)

            const message = component.form.getError("");

            expect(message).toEqual({ state: "error", error: "Debes completar esta información"})
        })

        it("should be return empty when no touched  and no dirty control", () => {
            const control = {
                touched: false,
                dirty: false
            } as AbstractControl

            spyOn(component.form,"get").and.returnValue(control)

            const message = component.form.getError("");

            expect(message).toEqual({ state: "", error: ""})
        })
    })
})