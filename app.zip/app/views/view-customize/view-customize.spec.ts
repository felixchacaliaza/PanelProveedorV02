/* tslint:disable:no-unused-variable */
import { ViewCustomize } from './view-customize';
import { ViewCustomizePresenter } from './view-customize.presenter';
import { StatePresenter } from '@src/app/states/state.presenter';
import { TestBed } from '@angular/core/testing';
import { StateManagerModule } from '@src/app/states/state-manager.module';
import { of } from 'rxjs';


xdescribe('@ViewCustomize', () => {
  let component: ViewCustomize;
  const StubViewCustomizePresenter = jasmine.createSpyObj(ViewCustomizePresenter,["initialize","saveData","redirectToNextPage","redirectToBackPage","loadListDitricts"])
  const StubStatePresenter = jasmine.createSpyObj(StatePresenter,["updateStateCustomize","updateStateDetail","selectStateStep","selectStateCustomizeAccount"]);


  beforeEach(() => {
    TestBed.configureTestingModule({
      imports:[StateManagerModule]
    }).compileComponents();
    StubStatePresenter.selectStateStep.and.returnValue(of('some value'));
    StubStatePresenter.selectStateCustomizeAccount.and.returnValue(of('some value'));
    component = new ViewCustomize(StubViewCustomizePresenter,StubStatePresenter);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe("#btnNext", () => {
    it("SHOULD go to next page WHEN 'next' button is clicked", () => {
      StubViewCustomizePresenter.redirectToNextPage.and.callThrough();
      StubViewCustomizePresenter.saveData.and.callFake(()=>Promise.resolve({}));
      StubStatePresenter.updateStateCustomize.and.callFake(()=>{});
      StubStatePresenter.updateStateDetail.and.callFake(()=>{});

      component.onNext({placeFrequentUse:"",accountNumber:"",typeAccount: "",moneyDescription:""});

      expect(StubViewCustomizePresenter.saveData).toHaveBeenCalled()

    })
  })

  describe("#onBack", () => {
    it("SHOULD go to back page", () => {
      StubViewCustomizePresenter.redirectToBackPage.and.callThrough();

      component.onBack({})

      expect(StubViewCustomizePresenter.redirectToBackPage).toHaveBeenCalled()
    })

  })

  describe("#onSelect", () => {
    it("SHOULD load lista of district if department change", () => {
      StubViewCustomizePresenter.loadListDitricts.and.callThrough();

      component.onSelect({ key:"department", value:"ab"})

      expect(StubViewCustomizePresenter.loadListDitricts).toHaveBeenCalled();
    })

  })

  describe("#ngOnInit", () => {
    it("SHOULD initialize load list", () => {
      StubViewCustomizePresenter.initialize.and.callThrough();

      component.ngOnInit()

      expect(StubViewCustomizePresenter.initialize).toHaveBeenCalled()
    })

  })

});
