import { Component, OnInit } from "@angular/core";
import { Emittable, Emitter } from "@ngxs-labs/emitter";
import { BranchOfficeModel } from "@src/app/core/models/branch-office.model";
import { combineLatest, Observable } from 'rxjs';
import { StepState, StepStateModel } from '@src/app/states/step.state';
import { CustomizeAccountStateModel } from '@src/app/states/customize-account.state';
import { DetailsAccountStateModel } from '@src/app/states/details-account.state';
import { ViewCustomizePresenter } from './view-customize.presenter';
import { StatePresenter } from '@src/app/states/state.presenter';

@Component({
  selector: "view-customize",
  templateUrl: "./view-customize.html",
  styleUrls: ["./view-customize.scss"],
  providers: [ViewCustomizePresenter]
})
export class ViewCustomize implements OnInit {

  @Emitter(StepState.register)
  stepRegister: Emittable<StepStateModel>;
  public stepState: StepStateModel;
  public detailsAccountState: DetailsAccountStateModel;

  public customizeAccountState: CustomizeAccountStateModel;

  public districts$: Observable<any[]> = this._presenter.districts$;
  public departments$: Observable<BranchOfficeModel[]> = this._presenter.branchsOffices$;
  public loader$ = this._presenter.loader$;
  public data: any;

  constructor(
    private _presenter: ViewCustomizePresenter,
    private _statePresenter: StatePresenter
  ) {

  }

  ngOnInit(): void {

    this._presenter.initialize()
    // this._init();
    this._statePresenter.selectStateStep().subscribe(stepState => {
      this.stepState = stepState
    });
    this._statePresenter.selectStateCustomizeAccount().subscribe(customizeAccountState => {
      this.customizeAccountState = customizeAccountState
      if (this.customizeAccountState.state == true) {
        this._presenter.loadListDitricts(this.customizeAccountState.department);

        const _data = {
          money: this.customizeAccountState.money,
          department: this.customizeAccountState.department,
          district: this.customizeAccountState.district
        }
        this.data = _data;
      }
    });

  }

  onNext(data: any): void {
    this._presenter.saveData(data)
      .then(() => {
        this._statePresenter.updateStateCustomize({ state: true, ...data });
        this._statePresenter.updateStateDetail({ placeFrequentUse: data.placeFrequentUse, accountNumber: data.accountNumber, typeAccount: data.typeAccount, moneyDescription: data.moneyDescription });
        this._presenter.redirectToNextPage();
      })
  }

  onBack(event): void {
    this.stepRegister.emit({
      onlyStep: 6
    });
    this._presenter.redirectToBackPage();
  }

  onSelect(event) {
    if (event.key == "department") {
      this._presenter.loadListDitricts(event.value);
    }
  }

  // private async _init(): Promise<void> {

  //     combineLatest([this._statePresenter.selectStateStep(), this._statePresenter.selectStateCustomizeAccount()]).
  //     subscribe(([stepState, customizeAccountState]) => {

  //       this.stepState = stepState;
  //       this.customizeAccountState = customizeAccountState;

  //       if (this.customizeAccountState.state == true) {
  //         this._presenter.loadListDitricts(this.customizeAccountState.department);

  //         const _data = {
  //           money: this.customizeAccountState.money,
  //           department: this.customizeAccountState.department,
  //           district: this.customizeAccountState.district
  //         }
  //         this.data = _data;
  //       }

  //     });
  // }


}
