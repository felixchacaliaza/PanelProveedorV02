import { CustomizeFormPresenter } from "./customize-form.presenter";
import { TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { CustomizeFormModel } from '../models/customize-form.model';

describe("@CustomizeFormPresenter", () => {
    let presenter: CustomizeFormPresenter;
    let spyError: any;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [ReactiveFormsModule],
            providers: [CustomizeFormPresenter]
        }).compileComponents()

        spyError = spyOn(CustomizeFormModel.prototype, "getErrorMessage").and.returnValue({});
        presenter = TestBed.inject(CustomizeFormPresenter);
    })

    describe("#setForm", () => {
        it("should set value inf form", () => {
            const value = { money: "USD", department: "Lima", district: "123" };

            presenter.setForm(value);

            expect(presenter.form.value).toEqual(value)
        })
    })

    describe("#getDepartmentName", () => {
        it("should return the name of department", () => {
            const list = [{ region: "Lima" }];

            const result = presenter.getDepartmentName("Lima", list);

            expect(result).toBe("Lima")
        })
    })

    describe("#getDistrictName", () => {
        it("should return name of branch district", () => {
            const list = [{ region: "Lima", district: [{ branchOfficeId: "123", description: "Isidro" }] }];

            const result = presenter.getDistrictName("123", "Lima", list);

            expect(result).toBe("Isidro")
        })
    })

    describe("#initialize", () => {
        it("should init the listeng to change", () => {
            let result: any;
            presenter.department$.subscribe(data=>result=data);

            presenter.initialize();
            presenter.form.get("department").setValue("01");

            expect(result).toBe("01")

        })
    })
})