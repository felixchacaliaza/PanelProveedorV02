import { Component, OnInit, Input, Output, EventEmitter, ChangeDetectionStrategy } from "@angular/core";
import { CustomizeFormPresenter } from './customize-form.presenter';
import { BranchOfficeModel } from '@src/app/core/models/branch-office.model';
import { takeUntil } from 'rxjs/operators';

@Component({
    selector: "ppel-customize-form",
    templateUrl: "./customize-form.component.html",
    styleUrls: ["./customize-form.component.scss"],
    providers: [CustomizeFormPresenter],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class CustomizeFormComponent implements OnInit {

    @Input()
    departments: BranchOfficeModel[] = [];

    @Input()
    districts: any[] = [];

     @Input()
     set data(value:any){
         this._presenter.setForm(value)
     }

    @Output()
    onSelect = new EventEmitter<any>();

    @Output()
    onNext = new EventEmitter<any>();

    @Output()
    onBack = new EventEmitter<any>();

    form = this._presenter.form;

    constructor(
        private _presenter: CustomizeFormPresenter
    ) { }

    ngOnInit() {
        this._presenter.initialize();
        this._presenter.notifySelect$
            .pipe(takeUntil(this._presenter.destroy$))
            .subscribe(notify => {
                this.onSelect.emit(notify);
            })
    }

    btnNext(): void {
        this.onNext.emit(this._builddata());
    }

    btnBack(): void {
        this.onBack.emit();
    }

    private _builddata() {
        return {
            ...this.form.value,
            typeAccount: "Cuenta Corriente",
            moneyDescription: this.form.get("money").value == "PEN" ? "Soles" : "Dólares",
            placeFrequentUse: `${this._getDistrict()}, ${this._getDepartment()}`
        }
    }

    private _getDepartment() {
        return this._presenter.getDepartmentName(this.form.get("department").value, this.departments);
    }

    private _getDistrict() {
        return this._presenter.getDistrictName(this.form.get("district").value,this.form.get("department").value, this.departments);
    }
}