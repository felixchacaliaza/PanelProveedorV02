import { CustomizeFormComponent } from "./customize-form.component";
import { CustomizeFormPresenter } from './customize-form.presenter';
import { of, Subject } from 'rxjs';
import { FormGroup, FormControl } from '@angular/forms';

describe("@CustomizeFormComponent",()=>{
    let component: CustomizeFormComponent;
    const StubCustomizeFormPresenter = jasmine.createSpyObj(CustomizeFormPresenter,["initialize","notifySelect$","getDepartmentName","getDistrictName"])

    beforeEach(()=>{
        component = new CustomizeFormComponent(StubCustomizeFormPresenter);
    })

    describe("#ngOnInit",()=>{
        it("should initialize load desplegable",()=>{
            StubCustomizeFormPresenter.initialize.and.callThrough();
            StubCustomizeFormPresenter.destroy$ = new Subject()
            StubCustomizeFormPresenter.notifySelect$ = of({})

            component.ngOnInit();

            expect(StubCustomizeFormPresenter.initialize).toHaveBeenCalled()
        })
    })

    describe("#btnNext",()=>{
        it("should launch event",()=>{
            const spyNext = spyOn(component.onNext,"emit").and.callThrough();
            StubCustomizeFormPresenter.getDepartmentName.and.returnValue("Lima");
            StubCustomizeFormPresenter.getDistrictName.and.returnValue("Lima");
            component.form = new FormGroup({
                department: new FormControl("01"),
                district: new FormControl("01"),
                money: new FormControl("PEN")
            })

            component.btnNext();

            expect(spyNext).toHaveBeenCalled()
        })
    })

    describe("#btnBack",()=>{
        it("shoudl launch event for back page",()=>{
            const spyBack = spyOn(component.onBack,"emit").and.callThrough();

            component.btnBack();

            expect(spyBack).toHaveBeenCalled()
        })
    })
})