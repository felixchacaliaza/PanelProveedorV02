import { Injectable } from "@angular/core";
import { FormBuilder, FormGroup } from '@angular/forms';
import { CustomizeFormModel } from '../models/customize-form.model';
import { BehaviorSubject, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Injectable()
export class CustomizeFormPresenter {

    private _notifySelect = new BehaviorSubject<any>({});
    private _department = new BehaviorSubject<string>("");

    form: FormGroup;

    destroy$ = new Subject();

    get department$(){
        return this._department.asObservable()
    }

    constructor(
        private _formBuilder: FormBuilder
    ) {
        const { getErrorMessage, ...rest } = new CustomizeFormModel();
        this.form = this._formBuilder.group({
            ...rest
        });
        this.form.getError = (control: string) => getErrorMessage(control, this.form);
    }

    get notifySelect$() {
        return this._notifySelect.asObservable();
    }

    setForm(data:any){
        this.form.patchValue(data);
    }

    initialize() {
        this._watchDepartment();
    }

    getDepartmentName(value:string, list:any[]):string{
        const department = list.find(dep=>dep.region == value);
        return department.region;       
    }

    getDistrictName(value:string,region:string,list:any[]):string{
        const districts:any[] = list.find(dep=>dep.region == region).district;
        const district = districts.find(d=>d.branchOfficeId == value);
        return district.description;
    }

    private _watchDepartment() {
        this.form.get("department").valueChanges
            .pipe(takeUntil(this.destroy$))
            .subscribe(dep => {
                if (dep) {
                    this._department.next(dep);
                    this.form.get("district").reset();
                    this._notifySelect.next({ key: "department", value: dep })
                }
            })
    }

}