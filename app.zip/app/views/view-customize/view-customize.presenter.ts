import { Injectable } from "@angular/core";
import { Router } from '@angular/router';
import { CatalogHttp } from '@src/app/core/http/catalog.http';
import { DatosHttp } from '@src/app/core/http/datos.http';
import { BehaviorSubject, forkJoin } from 'rxjs';
import { BranchOfficeModel } from '@src/app/core/models/branch-office.model';
import { map } from 'rxjs/operators';
import { IInititalDataHttpRequest } from '@src/app/core/models/initial-data.model';

@Injectable()
export class ViewCustomizePresenter {

    private _branchsOffices = new BehaviorSubject<BranchOfficeModel[]>([]);
    private _districts = new BehaviorSubject<any[]>([]);
    private _loader = new BehaviorSubject<boolean>(false);

    get branchsOffices$() {
        return this._branchsOffices.asObservable();
    }

    get districts$() {
        return this._districts.asObservable();
    }

    get loader$(){
        return this._loader.asObservable();
    }

    constructor(
        private _router: Router,
        private _catalogHttp: CatalogHttp,
        private _datosHttp: DatosHttp
    ) { }

    async initialize() {
        this._loader.next(true);
        const _callBranchs = this._catalogHttp.getListBranchOffice();
        const { resBranchs } = await forkJoin({
            resBranchs: _callBranchs.pipe(map(response => response))
        }).toPromise()
        this._loader.next(false);
        this._branchsOffices.next(resBranchs);
    }

    loadListDitricts(branch: string) {
        this.branchsOffices$.subscribe(lista => {
            if (lista && lista.length > 0) {
                const dep = lista.find(br => br.region == branch);
                const subList = dep.district;
                this._districts.next(subList);
            }
        })

    }

    saveData(data: any) {
        this._loader.next(true);
        const request = this._buildRequest(data);
        return this._datosHttp.initialData(request).toPromise().then(res=>{
            this._loader.next(false);
            return res;
        })
    }

    redirectToNextPage() {
        this._router.navigateByUrl("cta-cte/datos-personales");
    }

    redirectToBackPage() {
        this._router.navigateByUrl("cta-cte/fatca-pep");
    }

    private _buildRequest(data: any): IInititalDataHttpRequest {

        let request: IInititalDataHttpRequest;

        let subLista: any[] = [];
        this.branchsOffices$.subscribe(lista => {
            subLista = lista.find(br => br.region == data.department).district;
        })

        request = {
            currency: {
                code: data.money
            },
            branchOffice: {
                id: data.district,
                department: data.department,
                district: subLista.find(b => b.branchOfficeId === data.district).description
            },
            configuration: {
                step: 'ACCOUNT_STEP'
            }
        }

        return request;
    }


}