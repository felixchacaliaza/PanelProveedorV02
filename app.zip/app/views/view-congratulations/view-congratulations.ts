import { Component, OnInit } from "@angular/core";
import { QualificationHttp } from '@src/app/core/http/qualification.http';
import { IQualificationRequest } from '@src/app/core/models/qualification.model';
import { ClearStorageService } from '@src/app/shared/services/clear-storage-service';
import { DetailsAccountStateModel } from '@src/app/states/details-account.state';
import { BcpMicroFrontendRouter } from '@bcp/ng-micro-frontends-v3/router';
import { AuthService, IUser } from '@src/app/core/services/auth.service';
import { StatePresenter } from "@src/app/states/state.presenter";


@Component({
  selector: "view-congratulations",
  templateUrl: "./view-congratulations.html",
  styleUrls: ["./view-congratulations.scss"]
})
export class ViewCongratulations implements OnInit{

  public detailsAccountState: DetailsAccountStateModel;
  public qualificationNumber: number = 0;
  public comment: string = "";
  public isRatingSubmitted: boolean = false;
  public user: IUser;
  constructor(
    private _microRouter: BcpMicroFrontendRouter,
    private _qualificationHttp: QualificationHttp,
    private _clearStorageService: ClearStorageService,
    private _authSrv: AuthService,
    private _statePresenter : StatePresenter
  ) {
    this.user = this._authSrv.getUser();
    this._statePresenter.selectStateDetailAccount().subscribe(detailsAccountState => {
      this.detailsAccountState = detailsAccountState
    });
  }

  ngOnInit(){

    history.pushState(null,null,location.href);
    window.onpopstate = function(){
      history.go(1)
    }
  }

  public btnQualify(number: number): void {
    this.qualificationNumber = number;
  }

  public btnSendQualification(): void {
    const request: IQualificationRequest = this._buildRequest();
    this._qualificationHttp.submitRating(request)
      .subscribe(
        response => {
          this.isRatingSubmitted = true;
        },
        error => {
          console.error(error);
        }
      )
  }

  public btnGoCatalog(): void {
    this._microRouter.navigateByUrl("/producto/lista");
    this._clearStorageService.clearSesionStorage();
  }

  private _buildRequest(): IQualificationRequest {
    return { rating: this.qualificationNumber, comment: this.comment };
  }

}
