/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ViewCongratulations } from './view-congratulations';
import { RouterTestingModule } from '@angular/router/testing';
import { BcpNetworkingModule } from '@bcp/ng-core-v3/networking';
import { QualificationHttp } from '@src/app/core/http/qualification.http';
import { of } from 'rxjs';
import { Router } from '@angular/router';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BcpFormmodule } from '@bcp/ng-core-v3/forms';
import { BcpCommonsModule, BcpSessionStorage } from '@bcp/ng-core-v3';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { StateManagerModule } from '@src/app/states/state-manager.module';
import { ClearStorageService } from '@src/app/shared/services/clear-storage-service';
import { BcpMicroFrontendRouter } from '@bcp/ng-micro-frontends-v3/router';
import { AuthService } from '@src/app/core/services/auth.service';
import { BcpAssetsManagerModule } from '@bcp/ng-micro-frontends-v3/assets-manager';
import { environment } from '@src/environments/environment.test';
import { StatePresenter } from '@src/app/states/state.presenter';

describe('@ViewCongratulations', () => {
  let component: ViewCongratulations;
  // let fixture: ComponentFixture<ViewCongratulations>;
const StubMicroRouter = jasmine.createSpyObj(BcpMicroFrontendRouter,["navigateByUrl"]);
const StubQualificationHttp = jasmine.createSpyObj(QualificationHttp,["submitRating"]);
const StubClearStorage = jasmine.createSpyObj(ClearStorageService,["clearSesionStorage"]);
const StubAuthService = jasmine.createSpyObj(AuthService,["getUser"]);
const StubStatePresenter = jasmine.createSpyObj(StatePresenter,["updateStateCustomize","updateStateDetail","selectStateDetailAccount"]);
  // beforeEach(async(() => {
  //   TestBed.configureTestingModule({
  //     imports: [
  //       RouterTestingModule.withRoutes([
  //         { path: "producto/lista", component: ViewCongratulations }
  //       ]),
  //       BcpFormmodule,
  //       BcpCommonsModule,
  //       ReactiveFormsModule,
  //       FormsModule,
  //       BcpNetworkingModule,
  //       HttpClientTestingModule,
  //       StateManagerModule,
  //       BcpAssetsManagerModule.forRoot({
  //         basePath: `${environment.TARGET_ASSETS}/assets/`
  //       })
  //     ],
  //     declarations: [ViewCongratulations],
  //     providers: [
  //       QualificationHttp,
  //       ClearStorageService,
  //       AuthService,
  //       BcpMicroFrontendRouter,
  //     ],
  //     schemas: [CUSTOM_ELEMENTS_SCHEMA]
  //   }).compileComponents();
  // }));

  beforeEach(() => {
    StubAuthService.getUser.and.returnValue({names:"",personType:""});
    StubStatePresenter.selectStateDetailAccount.and.returnValue(of('some value'));
    component = new ViewCongratulations(StubMicroRouter,StubQualificationHttp,StubClearStorage,StubAuthService,StubStatePresenter);


    // fixture = TestBed.createComponent(ViewCongratulations);
    // component = fixture.componentInstance;
    // let storage = TestBed.inject(BcpSessionStorage);
    // storage.set("R2D2", "Bearer flow4-flow4-flow4-flow4-flow4");
    // storage.set("BB8", "znak-znak-znak-znak-znak");
    // storage.set("AK", "flow4-flow4-flow4-flow4-flow4");
    // storage.set("RTK", "flow4-flow4-flow4-flow4-flow4");
    // storage.set("channelOrigin", "1");
    // storage.set("productOrigin", "PPEL-PRCTACTE");
    // fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe("#btnQualify", () => {
    it("SHOULD save 1 WHEN 1 star is marked", () => {
      component.qualificationNumber = 0;

      component.btnQualify(1);

      expect(component.qualificationNumber).toBe(1)
    })

  })


  describe("#btnSendQualification", () => {
    it("SHOULD send the rating and comment WHEN the 'submit' button is clicked", () => {
      component.qualificationNumber = 4;
      component.comment = "mi comentario";
      StubQualificationHttp.submitRating.and.callFake(()=>of({}))

      component.btnSendQualification();

      expect(component.isRatingSubmitted).toBeTrue()
    })


  })

  describe("#btnGoCatalog", () => {
    it("SHOULD redirect to the product catalog WHEN the 'back to catalog' button is cliecked", () => {
      StubMicroRouter.navigateByUrl.and.callThrough()
      //Act
      component.btnGoCatalog();
      //Assert
      expect(StubMicroRouter.navigateByUrl).toHaveBeenCalledWith("/producto/lista")
    })
  })

  describe("#ngOnInit",()=>{
    it("should config for denied back ti page",()=>{
      component.ngOnInit()
    })
  })

});
