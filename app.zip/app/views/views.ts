import { ViewError } from './view-error/view-error';
import { ViewEvaluation } from './view-evaluation/view-evaluation';
import { ViewCustomize } from './view-customize/view-customize';
import { ViewPersonal } from './view-personal/view-personal';
import { ViewCompany } from './view-company/view-company';
import { ViewDetail } from './view-detail/view-detail';
import { ViewCongratulations } from './view-congratulations/view-congratulations';
import { ViewFatcaAndPEP } from './view-fatca-pep/view-fatca-pep.view';
import { ViewInfo } from './view-info/view-info';
import { PersonalFormComponent } from './view-personal/personal-form/personal-form.component';
import { CompanyFormComponent } from './view-company/company-form/company-form.component';
import { CustomizeFormComponent } from './view-customize/customize-form/customize-form.component';
import { DetailFormComponent } from './view-detail/detail-form/detail-form.component';


export const viewList = [
    ViewEvaluation,
    ViewInfo,
    ViewError,
    ViewFatcaAndPEP,
    ViewCustomize,
    ViewPersonal,
    ViewCompany,
    ViewDetail,
    ViewCongratulations,

    CustomizeFormComponent,
    PersonalFormComponent,
    CompanyFormComponent,
    DetailFormComponent
]
