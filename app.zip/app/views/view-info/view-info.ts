import { BreakpointObserver } from '@angular/cdk/layout';
import { ChangeDetectorRef, Component, ElementRef, ViewChild, AfterViewInit, HostListener } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { BcpValidators } from '@bcp/ng-core-v3/forms';
import { Emitter, Emittable } from '@ngxs-labs/emitter';
import { HttpErrorResponse } from '@angular/common/http';
import { IUser } from '@src/app/core/services/auth.service';
import { BcpSessionStorage } from '@bcp/ng-core-v3';
import { StepState, StepStateModel } from '@src/app/states/step.state';
import { Observable, UnsubscriptionError } from 'rxjs';
import { ModalService } from '@src/app/shared/services/modal-service';
import { ViewInfoPresenter } from './view-info.presenter';

@Component({
  selector: 'view-info',
  templateUrl: './view-info.html',
  styleUrls: ['./view-info.scss'],
  providers: [ViewInfoPresenter]
})
export class ViewInfo implements AfterViewInit {

  @ViewChild('lMainCenterContent')
  lMainCenterContent: ElementRef;

  @ViewChild('lMainCenter')
  lMainCenter: ElementRef;

  @Emitter(StepState.register)
  stepRegister: Emittable<StepStateModel>;
  screenHeight;
  screenWidth;
  styleMinHeightlMainCenterContent = '';
  styleMinHeightlMainCenter = '';
  showLoader: boolean;
  currentModal: string = "";
  isScreenMobile: boolean = false;
  formInfo: FormGroup;
  stepState: StepStateModel;
  tab = '';
  public user$: Observable<IUser> = this._presenter.user$;

  constructor(
    private _presenter: ViewInfoPresenter,
    private _modalSrv: ModalService,
    private _breakPointObserver: BreakpointObserver,
    private _formBuilder: FormBuilder,
    private changeDetectorRef: ChangeDetectorRef,
    protected bcpSessionStorage: BcpSessionStorage
  ) {
    this._presenter.initialize();
    window.addEventListener('resize', () => {
      this.changeDetectorRef.detectChanges();
      this.isScreenMobile = this.isMobile();
      this.changeDetectorRef.detectChanges();
      this.getChangeHeightMainCenterContent();
      this.changeDetectorRef.detectChanges();

    });
    this._buildform();

  }

  onTabSelected(event) {

    this.tab = event.detail;
    this.getChangeHeightMainCenterContent();
  }
  ngAfterViewInit(): void {
    this.changeDetectorRef.detectChanges();
    this.getChangeHeightMainCenterContent();
    this.changeDetectorRef.detectChanges();
  }

  getChangeHeightMainCenterContent() {
    this.changeDetectorRef.detectChanges();
    this.getScreenSize();

    if (this.screenWidth < 188) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 348px)`;
    } else if (this.screenWidth < 264) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 328px)`;
    } else if (this.screenWidth < 279) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 293px)`;
    } else if (this.screenWidth < 314) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 287px)`;
    } else if (this.screenWidth < 528) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 285px)`;
    } else if (this.screenWidth < 576) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 255px)`;
    } else if (this.screenWidth < 768) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 255px)`;
    } else if (this.screenWidth < 992) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 179px)`;
    } else if (this.screenWidth < 1199) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 160px)`;
    } else {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 160px)`;
    }

  }
  @HostListener('window:resize', ['$event'])
  getScreenSize(event?) {
    this.changeDetectorRef.detectChanges();
    this.screenHeight = window.innerHeight;
    this.screenWidth = window.innerWidth;
  }
  public openModal(modalName: string) {
    this.currentModal = modalName;
    this._modalSrv.openModal(modalName);
  }

  public closeModal(modalName: string) {
    this.currentModal = "";
    this._modalSrv.closeModal(modalName);
  }

  isMobile(): boolean {
    let result = this._breakPointObserver.isMatched("(max-width: 767px)");
    return result;
  }

  public btnNext() {
    this.stepRegister.emit({
      onlyStep: 1,
      infoCtaCte: {
        simpleUseStatement: true,
        state: true
      }
    });
    this._startValidationToCtaCte();
  }

  public btnBackToCatalog(): void {
    this._presenter.redirectToCatalog();
  }


  btnModalAgency(): void {
    this.currentModal = "";
    this._modalSrv.closeModal("modalFileNegative")
    this._presenter.redirectToAgencies()
  }

  btnModalCloseFile(): void {
    this.currentModal = "";
    this._modalSrv.closeModal("modalFileNegative")
    this._presenter.redirectToCatalog();
  }

  private _startValidationToCtaCte(): void {
    this.showLoader = true

    this._presenter.validateTypeClient(this._presenter.getIDC())
      .toPromise()
      .then((response1) => {
        return this._presenter.validateNegativeFile().toPromise();
      })
      .then((response2) => {

        if (response2 && response2.status == "next") {
          return this._presenter.validateCodeRequest().toPromise();
        } else {
          return { status: "denied" }
        }

      })
      .then((response3: any) => {

        this.showLoader = false;
        if (response3.status) {
          this._modalSrv.openModal("modalFileNegative")
        } else {
          this._presenter.redirectToNextPage();
        }

      })
      .catch((error: HttpErrorResponse) => {
        this.showLoader = false;
        console.error(error)
      })
  }

  private _buildform() {

    this.formInfo = this._formBuilder.group({
      acceptTerms: ["", BcpValidators.required]
    });

  }


}
