/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { ViewInfo } from './view-info';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { BcpNetworkingModule } from '@bcp/ng-core-v3/networking';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { BcpCommonsModule, BcpSessionStorage } from '@bcp/ng-core-v3';
import { BcpFormmodule } from '@bcp/ng-core-v3/forms';
import { BcpMicroFrontendRouter } from '@bcp/ng-micro-frontends-v3/router';
import { ValidationHttp } from '@src/app/core/http/validation.http';
import { AuthService } from '@src/app/core/services/auth.service';
import { of } from 'rxjs';
import { StateManagerModule } from '@src/app/states/state-manager.module';
import { ModalService } from '@src/app/shared/services/modal-service';
import { BcpAssetsManagerModule } from '@bcp/ng-micro-frontends-v3/assets-manager';
import { environment } from '@src/environments/environment.test';
import { ViewInfoPresenter } from './view-info.presenter';
import { ViewPersonalPresenter } from '../view-personal/view-personal.presenter';

describe('ViewInfo', () => {
  let component: ViewInfo;
  let fixture: ComponentFixture<ViewInfo>;
  let microrouterSpy = { navigateByUrl: jasmine.createSpy("navigateByUrl")}

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports:[
        ReactiveFormsModule,
        FormsModule,
        BcpCommonsModule,
        BcpFormmodule,
        RouterTestingModule,
        HttpClientTestingModule,
        BcpNetworkingModule,
        StateManagerModule,
        BcpAssetsManagerModule.forRoot({
          basePath: `${environment.TARGET_ASSETS}/assets/`
        }),
      ],
      declarations: [ ViewInfo ],
      providers:[
        ModalService,
        BcpMicroFrontendRouter,
        ValidationHttp, 
        AuthService,
        { provide: BcpMicroFrontendRouter, useValue: microrouterSpy }
      ],
      schemas:[CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewInfo);
    component = fixture.componentInstance;

    let storage = TestBed.inject(BcpSessionStorage)
    storage.set("BB8","test")
    storage.set("R2D2","test")
    storage.set("AK","test")
    storage.set("productOrigin","test")
    storage.set("channelOrigin","test")
    // fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe("#openModal",()=>{
    it("SHOULD open the modal WHEN 'conocer más' is clicked",()=>{
      //Arragen
      spyOn(ModalService.prototype,"openModal").and.callFake(()=>{});
      //Act
      component.openModal("idmodal");
      //assert
      expect(ModalService.prototype.openModal).toHaveBeenCalled()
    })
  })

  describe("#closeModal",()=>{
    it("SHOULD close the modal WHEN 'x' is clicked",()=>{
      //Arragen
      spyOn(ModalService.prototype,"closeModal").and.callFake(()=>{});
      //Act
      component.closeModal("idmodal");
      //assert
      expect(ModalService.prototype.closeModal).toHaveBeenCalled()
    })
  })


  // describe("#btnNext",()=>{
  //   it("SHOULD redirect to next page WHEN 'continue' button is clicked",()=>{
      
  //     // spyOn(ViewPersonalPresenter.prototype,"validateTypeClient").and.callFake((param)=>of({}))
  //     // spyOn(ViewPersonalPresenter.prototype,"validateNegativeFile").and.callFake(()=>of({status: "next"}))
  //     // spyOn(ViewPersonalPresenter.prototype,"validateCodeRequest").and.callFake(()=>of({}))
  //     component.user = { personId: "987654321000", names: "elmo",customerType:"",personType:"N",ruc:"",isInConsist:true, documentType:"1"}
      
  //     component.btnNext()
     
  //   })
  // })

  describe("#btnBackToCatalog", () => {
    it("SHOULD indicate error WHEN no value is selected", () => {
      spyOn(ViewInfoPresenter.prototype,"redirectToCatalog").and.callThrough();

      component.btnBackToCatalog()

      expect(ViewInfoPresenter.prototype.redirectToCatalog).toHaveBeenCalled()
    })
    
  })

  describe("#btnModalCloseFile",()=>{
    it("should close the modal negative file",()=>{
      spyOn(ViewInfoPresenter.prototype,"redirectToCatalog").and.callThrough();
      spyOn(ModalService.prototype,"closeModal").and.callFake(()=>{});

      component.btnModalCloseFile();

      expect(ModalService.prototype.closeModal).toHaveBeenCalled()
    })
  })

  describe("#btnModalAgency",()=>{
    it("should close modal negative file and redirect agency",()=>{
      spyOn(ViewInfoPresenter.prototype,"redirectToAgencies").and.callFake(()=>{});
      spyOn(ModalService.prototype,"closeModal").and.callFake(()=>{});

      component.btnModalAgency();

      expect(ViewInfoPresenter.prototype.redirectToAgencies).toHaveBeenCalled()
    })
  })

});
