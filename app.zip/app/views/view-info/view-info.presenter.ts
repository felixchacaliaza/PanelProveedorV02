import { Injectable } from "@angular/core";
import { BcpMicroFrontendRouter } from '@bcp/ng-micro-frontends-v3/router';
import { ValidationHttp } from '@src/app/core/http/validation.http';
import { ValidationNegativeFileModel } from '@src/app/core/models/validation-negative-file.model';
import { Router } from '@angular/router';
import { AuthService, IUser } from '@src/app/core/services/auth.service';
import { BehaviorSubject } from 'rxjs';

@Injectable()
export class ViewInfoPresenter {

    private _user = new BehaviorSubject<IUser>({ names: "", personId: "", personType: "", ruc: "", isInConsist: false, documentType: "", customerType: "" });

    get user$(){
        return this._user.asObservable();
    }

    constructor(
        private _router: Router,
        private _microfrontendRouter: BcpMicroFrontendRouter,
        private _validationHttp: ValidationHttp,
        private _authSrv: AuthService
    ) {

    }

    initialize(){
        const user = this._authSrv.getUser();
        this._user.next(user);
    }

    redirectToAgencies(): void {
        window.open("https://www.viabcp.com/canales-presenciales");
    }

    redirectToCatalog(): void {
        this._microfrontendRouter.navigateByUrl("producto/lista", "catalogo")
    }

    redirectToNextPage(): void {
        this._router.navigate(["cta-cte/fatca-pep"])
    }

    validateTypeClient(idc) {
        return this._validationHttp.validateTypeClient({ idc });
    }

    validateNegativeFile() {

        return this._validationHttp.validateNegativeFile()
    }

    validateCodeRequest() {
        return this._validationHttp.codeRequest();
    }

    getIDC(){
        let user: IUser = this._authSrv.getUser()
        return user.personId.substr(0, 9);
    }
}