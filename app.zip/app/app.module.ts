import { FatcaPepGuard } from './core/guards/fatca-pep.guard';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA, Injector, APP_INITIALIZER, ComponentFactoryResolver } from '@angular/core';
import { createCustomElement } from '@angular/elements';
import { AppRoutingModule } from './app-routing.module';
import { BcpMicroFrontendsRouterModule } from '@bcp/ng-micro-frontends-v3/router';
import { AppComponent } from './app.component';
import { LayoutRoot } from './layouts/layout-root/layout-root';
import { CommonModule } from '@angular/common';
import { HttpCtaCteModule } from './core/http/http.module';
import { BcpCommonsModule } from '@bcp/ng-core-v3';
import { StartService } from './shared/services/start.service';
import { SharedModule } from './shared/shared.module';
import { ReactiveFormsModule,FormsModule } from '@angular/forms';
import { BcpFormmodule } from '@bcp/ng-core-v3/forms';
import { LayoutStepper } from './layouts/layout-stepper/layout-stepper';
import { LayoutCard } from './layouts/layout-card/layout-card';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { BcpAssetsManagerModule } from '@bcp/ng-micro-frontends-v3/assets-manager';
import { environment } from '@src/environments/environment';
import { AuthService } from './core/services/auth.service';
import { StateManagerModule } from './states/state-manager.module';
import { componentList } from './components/components';
import { viewList } from './views/views';



export function startFactory(startService: StartService) {
  return () => startService.load();
}


@NgModule({
  imports: [
    BrowserModule,
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    BcpFormmodule,
    HttpCtaCteModule,
    BcpCommonsModule,
    AppRoutingModule,
    SharedModule,
    StateManagerModule,
    PdfViewerModule,

    BcpAssetsManagerModule.forRoot({
      basePath: `${environment.TARGET_ASSETS}/assets/`
    }),
    // BcpErrorHandlerModule.forRoot({
    //   codeResponse: 'code',
    //   production: false,
    //   exceptions: [
    //     {
    //       nameCode: ['500'],
    //       exception: Http500Exception,
    //     }
    //   ]
    // }),
    BcpMicroFrontendsRouterModule.setup({ eventNameToNavigate: 'mf-cta-cte' }),
  ],
  declarations: [
    AppComponent,
    ...componentList,
    ...viewList,
    //Layouts
    LayoutRoot,
    LayoutStepper,
    LayoutCard

  ],
  providers: [
    AuthService,
    FatcaPepGuard,
    {
      provide: APP_INITIALIZER,
      deps: [StartService],
      multi: true,
      useFactory: startFactory
    },
    // Http500Exception
  ],
  entryComponents: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class AppModule {
  constructor(private injector: Injector) { }

  /* eslint-disable @angular-eslint/use-lifecycle-interface */
  ngDoBootstrap(): void {
    const ele = createCustomElement(AppComponent, { injector: this.injector });
    customElements.define('mfe-cta-cte', ele);
  }
}
