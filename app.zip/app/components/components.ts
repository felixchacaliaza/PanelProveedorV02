
import { CCompanyProcessConstitution } from './questions-fatca-pep/c-company-process-constitution/c-company-process-constitution';
import { CCompanyPartEconomicGroup } from './questions-fatca-pep/c-company-part-economic-group/c-company-part-economic-group';
import { CLegalRepresentative } from './questions-fatca-pep/c-legal-representative/c-legal-representative';
import { CPoliticallyExposedPerson } from './questions-fatca-pep/c-politically-exposed-person/c-politically-exposed-person';
import { CSubsidiaryTransnationalCorporation } from './questions-fatca-pep/c-subsidiary-transnational-corporation/c-subsidiary-transnational-corporation';
import { CTypeEconomicActivityCompany } from './questions-fatca-pep/c-type-economic-activity-company/c-type-economic-activity-company';
import { CTypeEconomicActivityCompanyDenied } from './questions-fatca-pep/c-type-economic-activity-company-denied/c-type-economic-activity-company-denied';
import { CPreviewdocuments } from './c-preview-documents/c-preview-documents';

export const componentList = [
    CCompanyProcessConstitution,
    CCompanyPartEconomicGroup,
    CLegalRepresentative,
    CPoliticallyExposedPerson,
    CSubsidiaryTransnationalCorporation,
    CTypeEconomicActivityCompany,
    CTypeEconomicActivityCompanyDenied,
    CPreviewdocuments
]
