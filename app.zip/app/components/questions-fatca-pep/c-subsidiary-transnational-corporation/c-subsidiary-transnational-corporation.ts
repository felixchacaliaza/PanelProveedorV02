import { BreakpointObserver } from '@angular/cdk/layout';
import { HttpErrorResponse } from '@angular/common/http';
import { AfterViewInit, ChangeDetectorRef, Component, ElementRef, HostListener, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Emitter, Emittable } from '@ngxs-labs/emitter';
import { ValidationHttp } from '@src/app/core/http/validation.http';
import { IValidateComplianceFiltersHttpRequest } from '@src/app/core/models/validate-compliance-filters.model';
import { StepState, StepStateModel } from '@src/app/states/step.state';
import { ModalService } from '@src/app/shared/services/modal-service';
import { ClearStorageService } from '@src/app/shared/services/clear-storage-service';
import { BcpMicroFrontendRouter } from '@bcp/ng-micro-frontends-v3/router';
import { StatePresenter } from '@src/app/states/state.presenter';

@Component({
  selector: 'c-subsidiary-transnational-corporation',
  templateUrl: './c-subsidiary-transnational-corporation.html',
  styleUrls: ['./c-subsidiary-transnational-corporation.scss']
})
export class CSubsidiaryTransnationalCorporation implements OnInit, AfterViewInit {

  @ViewChild('lMainCenterContent')
  lMainCenterContent: ElementRef;

  @ViewChild('lMainCenter')
  lMainCenter: ElementRef;

  @Emitter(StepState.register)
  stepRegister: Emittable<StepStateModel>;
  styleMinHeightlMainCenterContent = '';
  styleMinHeightlMainCenter = '';
  currentModal: string = "";
  isScreenMobile: boolean = false;
  screenHeight;
  screenWidth;
  stepState: StepStateModel;
  showLoader: boolean;
  formQuestion: FormGroup;
  questionResponse: Boolean;

  constructor(
    private _modalSrv: ModalService,
    private _breakPointObserver: BreakpointObserver,
    private _formBuilder: FormBuilder,
    private _router: Router,
    private changeDetectorRef: ChangeDetectorRef,
    private _validationHttp: ValidationHttp,
    private _statePresenter : StatePresenter
  ) {

    this.isScreenMobile = this.isMobile();

    window.addEventListener('resize', () => {
      setTimeout(() => {
        this.changeDetectorRef.detectChanges();
        this.getChangeHeightMainCenterContent();
        this.changeDetectorRef.detectChanges();
      }, 0);
    });

    this._statePresenter.selectStateStep().subscribe(stepState => {
      this.stepState = stepState
    });

    this.buildForm();
  }

  ngAfterViewInit(): void {
    this.changeDetectorRef.detectChanges();
    this.getChangeHeightMainCenterContent();
    this.changeDetectorRef.detectChanges();
  }

  ngOnInit() {

  }

  isMobile(): boolean {
    let result = this._breakPointObserver.isMatched("(max-width: 767px)");
    return result;
  }

  openModal(modalName: string) {
    this.currentModal = modalName;
    this._modalSrv.openModal(modalName);
  }

  closeModal(modalName: string) {
    this.currentModal = "";
    this._modalSrv.closeModal(modalName);
  }

  ctrlCloseModalTransnationalSubsidiary($event): void {
    this.currentModal = "";
  }

  closeRequest() {
    this._validateComplianceFilters();
  }

  ctrlChangeQuestion(event: any): void {

    this.questionResponse = event.detail === 'true' ? false : true;
    if (event.detail === 'false') {
      this.stepRegister.emit({
        onlyStep: 8,
        subsidiaryTransnationalCorporation: {
          state: true,
          question: JSON.parse(event.detail)
        }
      });
      this._validateComplianceFilters();
    }

  }

  btnBack() {
    this.stepRegister.emit({
      onlyStep: 6
    });
  }

  btnNext() {
    this.stepRegister.emit({
      onlyStep: 8
    });
    this._router.navigate(["cta-cte/personaliza"]);
  }

  getChangeHeightMainCenterContent() {
    this.changeDetectorRef.detectChanges();
    this.getScreenSize();

    if (this.screenWidth < 188) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 348px)`;
    }else if (this.screenWidth < 264) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 328px)`;
    }else if (this.screenWidth < 279) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 293px)`;
    }else if (this.screenWidth < 314) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 287px)`;
    } else if (this.screenWidth < 528) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 285px)`;
    } else if (this.screenWidth < 576) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 255px)`;
    }else if (this.screenWidth < 768) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 255px)`;
    } else if (this.screenWidth < 992) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 179px)`;
    } else if (this.screenWidth < 1199) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 160px)`;
    } else {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 160px)`;
    }

  }

  private buildForm(): void {
    this.formQuestion = this._formBuilder.group({
      question: [(this.stepState.subsidiaryTransnationalCorporation.question === null ? null : this.stepState.subsidiaryTransnationalCorporation.question.toString()), Validators.required]
    })
  }

  get question() { return this.formQuestion.get("question"); }

  private _validateComplianceFilters(): void {

    this.showLoader = true;

    let request = this._createRequestValidateComplianceFilters();

    this._validationHttp.validateComplianceFilters(request)
      .toPromise()
      .then((response) => {
          this._router.navigate(["cta-cte/personaliza"]);
      })
      .catch((error: HttpErrorResponse) => {
        this.showLoader = false;
        console.error(error)
      })
  }

  private _createRequestValidateComplianceFilters(): IValidateComplianceFiltersHttpRequest {

    let request: IValidateComplianceFiltersHttpRequest;

    request = {
      filterQuestions: `Emp. Proceso Constitucion: ${this.stepState.companyProcessConstitution.question === true ? 'SI' : 'NO'} | Rep. Legal a sola firma: ${this.stepState.legalRepresentative.question === true ? 'SI' : 'NO'} | Emp. Parte Grupo Econoc: ${this.stepState.companyPartEconomic.question === true ? 'SI' : 'NO'} | Emp. Trans o Sub.: ${this.stepState.subsidiaryTransnationalCorporation.question === true ? 'SI' : 'NO'}`,
      pep: `PEP: ${this.stepState.politicallyExposedPerson.question === true ? 'SI' : 'NO'} | Puesto Cargo: ${this.stepState.politicallyExposedPerson.question === true ? this.stepState.politicallyExposedPerson.position : ''} | Centro Laboral: ${this.stepState.politicallyExposedPerson.question === true ? this.stepState.politicallyExposedPerson.laborCenter : ''}`,
      singleUseStatement: this.stepState.infoCtaCte.simpleUseStatement,
      groupEconomic: `${this.stepState.companyPartEconomic.question === true ? this.stepState.companyPartEconomic.groupEconomic : ''}`,
      activityEconomic: this.stepState.typeEconomicActivityCompany.activityEconomic
    }

    return request;
  }

  @HostListener('window:resize', ['$event'])
  getScreenSize(event?) {
    this.changeDetectorRef.detectChanges();
    this.screenHeight = window.innerHeight;
    this.screenWidth = window.innerWidth;
  }

}
