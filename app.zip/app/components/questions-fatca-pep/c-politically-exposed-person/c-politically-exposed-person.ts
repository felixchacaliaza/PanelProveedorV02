import { BreakpointObserver } from '@angular/cdk/layout';
import { ChangeDetectorRef, Component, ElementRef, HostListener, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Emitter, Emittable } from '@ngxs-labs/emitter';
import { StepState, StepStateModel } from '@src/app/states/step.state';
import { ModalService } from '@src/app/shared/services/modal-service';
import { StatePresenter } from '@src/app/states/state.presenter';

@Component({
  selector: 'c-politically-exposed-person',
  templateUrl: './c-politically-exposed-person.html',
  styleUrls: ['./c-politically-exposed-person.scss']
})
export class CPoliticallyExposedPerson implements OnInit, AfterViewInit {

  @ViewChild('lMainCenterContent')
  lMainCenterContent: ElementRef;

  @ViewChild('lMainCenter')
  lMainCenter: ElementRef;

  @Emitter(StepState.register)
  stepRegister: Emittable<StepStateModel>;

  styleMinHeightlMainCenterContent = '';
  styleMinHeightlMainCenter = '';
  currentModal: string = "";
  isScreenMobile: boolean = false;
  screenHeight;
  screenWidth;
  stepState: StepStateModel;
  formQuestion: FormGroup;
  questionResponse: Boolean;

  constructor(
    private modalSrv: ModalService,
    private breakPointObserver: BreakpointObserver,
    private formBuilder: FormBuilder,
    private changeDetectorRef: ChangeDetectorRef,
    private _statePresenter : StatePresenter
  ) {

    this._statePresenter.selectStateStep().subscribe(stepState => {
      this.stepState = stepState
    });
    this.isScreenMobile = this.isMobile();

    window.addEventListener('resize', () => {
      setTimeout(() => {
        this.isScreenMobile = this.isMobile();
        this.changeDetectorRef.detectChanges();
        this.getChangeHeightMainCenterContent();
        this.changeDetectorRef.detectChanges();
      }, 0);
    });

    this.buildForm();
  }

  ngOnInit() {
    this.question.setValue(this.stepState.politicallyExposedPerson.question === null ? null : this.stepState.politicallyExposedPerson.question.toString());
    this.position.setValue(this.stepState.politicallyExposedPerson.position);
    this.laborCenter.setValue(this.stepState.politicallyExposedPerson.laborCenter);
  }

  ngAfterViewInit(): void {
    this.changeDetectorRef.detectChanges();
    this.getChangeHeightMainCenterContent();
    this.changeDetectorRef.detectChanges();
  }

  isMobile(): boolean {
    let result = this.breakPointObserver.isMatched("(max-width: 767px)");
    return result;
  }

  openModal(modalName: string) {
    this.currentModal = modalName;
    this.modalSrv.openModal(modalName);
  }

  closeModal(modalName: string) {
    this.currentModal = "";
    this.modalSrv.closeModal(modalName);
  }

  ctrlCloseModalPep($event): void {
    this.currentModal = "";
  }

  ctrlChangeQuestion(event: any): void {
    this.questionResponse = event.detail === 'true' ? false : true;
    this.changeDetectorRef.detectChanges();
    this.getChangeHeightMainCenterContent();
    if (event.detail === 'true') {

      this.stepRegister.emit({
        politicallyExposedPerson: {
          position: this.position.value,
          laborCenter: this.laborCenter.value,
          state: true,
          question: JSON.parse(this.question.value),
        },
      });

    } else if (event.detail === 'false') {
      this.stepRegister.emit({
        politicallyExposedPerson: {
          position: this.position.value,
          laborCenter: this.laborCenter.value,
          state: true,
          question: JSON.parse(this.question.value),
        },
        onlyStep: 5
      });
    }
  }

  btnBack() {
    this.stepRegister.emit({
      onlyStep: 3
    });
  }

  btnNext() {
    this.stepRegister.emit({
      politicallyExposedPerson: {
        position: this.position.value,
        laborCenter: this.laborCenter.value,
        state: true,
        question: JSON.parse(this.question.value),
      },
      onlyStep: 5
    });
  }

  btnSaveNext() {

    if (this.formQuestion.invalid === false && this.question.value === 'true') {
      this.stepRegister.emit({
        politicallyExposedPerson: {
          position: this.position.value,
          laborCenter: this.laborCenter.value,
          state: true,
          question: true
        },
        onlyStep: 5
      });
    }

  }

  getChangeHeightMainCenterContent() {
    this.changeDetectorRef.detectChanges();
    this.getScreenSize();

    if (this.screenWidth < 188) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 348px)`;
    }else if (this.screenWidth < 264) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 328px)`;
    }else if (this.screenWidth < 279) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 293px)`;
    }else if (this.screenWidth < 314) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 287px)`;
    } else if (this.screenWidth < 528) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 285px)`;
    } else if (this.screenWidth < 576) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 255px)`;
    }else if (this.screenWidth < 768) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 255px)`;
    } else if (this.screenWidth < 992) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 179px)`;
    } else if (this.screenWidth < 1199) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 160px)`;
    } else {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 160px)`;
    }


  }

  private buildForm(): void {
    this.formQuestion = this.formBuilder.group({
      question: [null, Validators.required],
      position: ["", Validators.required],
      laborCenter: ["", Validators.required]
    })
  }

  get question() { return this.formQuestion.get("question"); }
  get position() { return this.formQuestion.get("position"); }
  get laborCenter() { return this.formQuestion.get("laborCenter"); }

  @HostListener('window:resize', ['$event'])
  getScreenSize(event?) {
    this.changeDetectorRef.detectChanges();
    this.screenHeight = window.innerHeight;
    this.screenWidth = window.innerWidth;
  }

}
