/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { CCompanyProcessConstitution } from './c-company-process-constitution';
import { BcpFormmodule } from '@bcp/ng-core-v3/forms';
import { BcpCommonsModule, BcpSessionStorage } from '@bcp/ng-core-v3';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { ValidationHttp } from '@src/app/core/http/validation.http';
import { BcpNetworkingModule } from '@bcp/ng-core-v3/networking';
import { BcpAssetsManagerModule } from '@bcp/ng-micro-frontends-v3/assets-manager';
import { environment } from '@src/environments/environment.test';
import { StateManagerModule } from '@src/app/states/state-manager.module';
import { ClearStorageService } from '@src/app/shared/services/clear-storage-service';
import { BcpMicroFrontendRouter } from '@bcp/ng-micro-frontends-v3/router';

describe('CCompanyProcessConstitution', () => {
  let component: CCompanyProcessConstitution;
  let fixture: ComponentFixture<CCompanyProcessConstitution>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports:[
        BcpFormmodule,
        BcpCommonsModule,
        ReactiveFormsModule,
        FormsModule,
        BcpNetworkingModule,
        RouterTestingModule.withRoutes([
          { path: "cta-cte/informacion", component: CCompanyProcessConstitution}
        ]),
        BcpAssetsManagerModule.forRoot({
          basePath: `${environment.TARGET_ASSETS}/assets/`
        }),
        StateManagerModule
      ],
      declarations: [ CCompanyProcessConstitution ],
      providers:[
        ClearStorageService,
        ValidationHttp,
        BcpMicroFrontendRouter
      ],
      schemas:[CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CCompanyProcessConstitution);
    component = fixture.componentInstance;
    let storage = TestBed.inject(BcpSessionStorage);
    storage.set("R2D2","Bearer flow4-flow4-flow4-flow4-flow4");
    storage.set("BB8","znak-znak-znak-znak-znak");
    storage.set("AK","flow4-flow4-flow4-flow4-flow4");
    storage.set("RTK","flow4-flow4-flow4-flow4-flow4");
    storage.set("channelOrigin","1");
    storage.set("productOrigin","PPEL-PRCTACTE");
    // fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe("#ctrlchangeQuestions",()=>{
    it("SHOULD update height WHEN change question's value",()=>{
      //Arrange

      component.question.setValue("true")
      //Act
      component.ctrlChangeQuestion({ detail: "true"});
    })
    it("SHOULD update height WHEN change question's value",()=>{
      //Arrange     
      component.question.setValue("false")
      //Act
      component.ctrlChangeQuestion({ detail: "false"});
    })
  })

  describe("#btnBack",()=>{
    it("SHOULD save step and return step WHEN '<-' is clicked",()=>{
      //Arrange
      //Act
      component.btnBack();
    })
  })


  describe("#getChangeHeightMainCenterContent",()=>{
    it("SHOULD update height WHEN change question's value",()=>{
      //Arrange
     
      //Act
      component.getChangeHeightMainCenterContent();
    })
  })

  describe("#btnNext",()=>{
    it("SHOULD save step and go to next step WHEN '->' is clicked",()=>{
      //Arrange
      //Act
      component.btnNext();
    })
  })


});
