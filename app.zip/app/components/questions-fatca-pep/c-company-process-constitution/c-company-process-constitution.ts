import { BreakpointObserver } from '@angular/cdk/layout';
import { HttpErrorResponse } from '@angular/common/http';
import { AfterViewInit, ChangeDetectorRef, HostListener } from '@angular/core';

import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Emittable, Emitter } from '@ngxs-labs/emitter';
import { ValidationHttp } from '@src/app/core/http/validation.http';
import { IValidateComplianceFiltersHttpRequest } from '@src/app/core/models/validate-compliance-filters.model';
import { StepState, StepStateModel } from '@src/app/states/step.state';
import { ClearStorageService } from '@src/app/shared/services/clear-storage-service';
import { BcpMicroFrontendRouter } from '@bcp/ng-micro-frontends-v3/router';
import { StatePresenter } from '@src/app/states/state.presenter';

@Component({
  selector: 'c-company-process-constitution',
  templateUrl: './c-company-process-constitution.html',
  styleUrls: ['./c-company-process-constitution.scss'],
})
export class CCompanyProcessConstitution implements AfterViewInit {

  @ViewChild('lMainCenterContent', { read: ElementRef, static: false })
  lMainCenterContent: ElementRef;

  @ViewChild('lMainCenter', { read: ElementRef, static: false })
  lMainCenter: ElementRef;

  @Emitter(StepState.register)
  stepRegister: Emittable<StepStateModel>;
  isScreenMobile: boolean = false;
  screenHeight;
  screenWidth;
  styleMinHeightlMainCenterContent = '';
  styleMinHeightlMainCenter = '';
  stepState: StepStateModel;
  formQuestion: FormGroup;
  questionResponse: Boolean;
  showLoader: boolean;

  constructor(
    private formBuilder: FormBuilder,
    private _router: Router,
    private breakPointObserver: BreakpointObserver,
    private changeDetectorRef: ChangeDetectorRef,
    private _validationHttp: ValidationHttp,
    private _clearStorageService: ClearStorageService,
    private _microRouter: BcpMicroFrontendRouter,
    private _statePresenter : StatePresenter
  ) {
    this._statePresenter.selectStateStep().subscribe(stepState => {
      this.stepState = stepState
    });

    this.buildForm();

    window.addEventListener('resize', () => {
      setTimeout(() => {
        this.isScreenMobile = this.isMobile();
        this.changeDetectorRef.detectChanges();
        this.getChangeHeightMainCenterContent();
        this.changeDetectorRef.detectChanges();
      }, 0);
    });


  }

  ngAfterViewInit(): void {
    this.changeDetectorRef.detectChanges();
    this.getChangeHeightMainCenterContent();
    this.changeDetectorRef.detectChanges();
  }

  isMobile(): boolean {
    let result = this.breakPointObserver.isMatched('(max-width: 767px)');
    return result;
  }



  ctrlChangeQuestion(event: any): void {

    this.questionResponse = event.detail === 'false' ? false : true;
    this.getChangeHeightMainCenterContent();
    if (event.detail) {
      this.stepRegister.emit({
        companyProcessConstitution: {
          state: JSON.parse(event.detail),
          question: JSON.parse(event.detail),
        },
      });
      if (event.detail === 'true') {
        this.stepRegister.emit({
          onlyStep: 2,
        });
      }
    }
  }

  btnNext() {
    this.stepRegister.emit({
      onlyStep: 2,
    });
  }

  closeRequest() {
    this._validateComplianceFilters();
  }

  btnBack() {
    this.stepRegister.emit({
      onlyStep: 0,
    });
    this._router.navigate(['cta-cte/informacion']);
  }

  getChangeHeightMainCenterContent() {
    this.changeDetectorRef.detectChanges();
    this.getScreenSize();

    if (this.screenWidth < 188) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 348px)`;
    }else if (this.screenWidth < 264) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 328px)`;
    }else if (this.screenWidth < 279) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 293px)`;
    }else if (this.screenWidth < 314) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 287px)`;
    } else if (this.screenWidth < 528) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 285px)`;
    } else if (this.screenWidth < 576) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 255px)`;
    }else if (this.screenWidth < 768) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 255px)`;
    } else if (this.screenWidth < 992) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 179px)`;
    } else if (this.screenWidth < 1199) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 160px)`;
    } else {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 160px)`;
    }


  }


  private buildForm(): void {
    this.formQuestion = this.formBuilder.group({
      question: [
        this.stepState.companyProcessConstitution.question === null
          ? null
          : this.stepState.companyProcessConstitution.question.toString(),
        Validators.required,
      ],
    });
  }

  get question() {
    return this.formQuestion.get('question');
  }

  private _validateComplianceFilters(): void {

    this.showLoader = true;
    let request = this._createRequestValidateComplianceFilters();

    this._validationHttp.validateComplianceFilters(request)
      .toPromise()
      .then((response) => {
        this._clearStorageService.clearSesionStorage();
        this._microRouter.navigateByUrl("/producto/lista","catalogo");
      })
      .catch((error: HttpErrorResponse) => {
        this.showLoader = false;
        console.error(error)
      })
  }

  private _createRequestValidateComplianceFilters(): IValidateComplianceFiltersHttpRequest {

    let request: IValidateComplianceFiltersHttpRequest;

    request = {
      filterQuestions: `Emp. Proceso Constitucion: ${this.stepState.companyProcessConstitution.question === true ? 'SI' : 'NO'}`,
      singleUseStatement: this.stepState.infoCtaCte.simpleUseStatement
    }

    return request;
  }

  @HostListener('window:resize', ['$event'])
  getScreenSize(event?) {
    this.changeDetectorRef.detectChanges();
    this.screenHeight = window.innerHeight;
    this.screenWidth = window.innerWidth;
  }
}
