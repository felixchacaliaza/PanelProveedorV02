import { AfterViewInit, ChangeDetectorRef, ElementRef, HostListener, ViewChild } from '@angular/core';
import { BreakpointObserver } from '@angular/cdk/layout';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Emitter, Emittable } from '@ngxs-labs/emitter';
import { StepState, StepStateModel } from '@src/app/states/step.state';
import { ModalService } from '@src/app/shared/services/modal-service';
import { StatePresenter } from '@src/app/states/state.presenter';

@Component({
  selector: 'c-company-part-economic-group',
  templateUrl: './c-company-part-economic-group.html',
  styleUrls: ['./c-company-part-economic-group.scss']
})
export class CCompanyPartEconomicGroup implements OnInit, AfterViewInit {

  @ViewChild('lMainCenterContent')
  lMainCenterContent: ElementRef;
  @ViewChild('lMainCenter')
  lMainCenter: ElementRef;
  @Emitter(StepState.register)
  stepRegister: Emittable<StepStateModel>;
  showLoader: boolean;
  styleMinHeightlMainCenterContent = '';
  styleMinHeightlMainCenter = '';
  currentModal: string = "";
  isScreenMobile: boolean = false;
  screenHeight;
  screenWidth;
  stepState: StepStateModel;
  formQuestion: FormGroup;
  questionResponse: Boolean;

  constructor(
    private modalSrv: ModalService,
    private breakPointObserver: BreakpointObserver,
    private formBuilder: FormBuilder,
    private changeDetectorRef: ChangeDetectorRef,
    private _statePresenter: StatePresenter
  ) {

    this._statePresenter.selectStateStep().subscribe(stepState => {
      this.stepState = stepState
    });

    this.isScreenMobile = this.isMobile();

    window.addEventListener('resize', () => {
      setTimeout(() => {
        this.isScreenMobile = this.isMobile();
        this.changeDetectorRef.detectChanges();
        this.getChangeHeightMainCenterContent();
        this.changeDetectorRef.detectChanges();
      }, 0);
    });
    this.buildForm();

  }

  ngAfterViewInit(): void {
    this.changeDetectorRef.detectChanges();
    this.getChangeHeightMainCenterContent();
    this.changeDetectorRef.detectChanges();
  }

  ngOnInit() {
    this.question.setValue(this.stepState.companyPartEconomic.question === null ? null : this.stepState.companyPartEconomic.question.toString())
    this.groupEconomic.setValue(this.stepState.companyPartEconomic.groupEconomic)
  }

  openModal(modalName: string) {
    this.currentModal = modalName;
    this.modalSrv.openModal(modalName);
  }

  closeModal(modalName: string) {
    this.currentModal = "";
    this.modalSrv.closeModal(modalName);
  }

  ctrlCloseModalGrupoEconomico($event): void {
    this.currentModal = "";
  }

  isMobile(): boolean {
    let result = this.breakPointObserver.isMatched("(max-width: 767px)");
    return result;
  }

  ctrlChangeQuestion(event: any): void {
    this.questionResponse = event.detail === 'true' ? false : true;
    this.changeDetectorRef.detectChanges();
    this.getChangeHeightMainCenterContent();
    const groupEconomic = this.stepState.companyPartEconomic.groupEconomic;
    const state = this.stepState.companyPartEconomic.state;
    if (event.detail === 'true') {

      this.stepRegister.emit({
        companyPartEconomic: {
          question: JSON.parse(event.detail),
          groupEconomic: groupEconomic,
          state: state
        },

      });

    } else if (event.detail === 'false') {
      this.stepRegister.emit({
        onlyStep: 4,
        companyPartEconomic: {
          question: JSON.parse(event.detail),
          groupEconomic: groupEconomic,
          state: true
        },
      });
    }
  }

  btnBack() {
    this.stepRegister.emit({
      onlyStep: 2
    });
  }

  btnNext() {
    this.stepRegister.emit({
      companyPartEconomic: {
        groupEconomic: this.groupEconomic.value,
        state: true,
        question: true
      },
      onlyStep: 4
    });
  }

  btnSaveNext() {

    if (this.formQuestion.invalid === false && this.question.value === 'true') {
      this.stepRegister.emit({
        companyPartEconomic: {
          groupEconomic: this.groupEconomic.value,
          state: true,
          question: true
        },
        onlyStep: 4
      });
    }

  }

  getChangeHeightMainCenterContent() {
    this.changeDetectorRef.detectChanges();
    this.getScreenSize();

    if (this.screenWidth < 188) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 348px)`;
    } else if (this.screenWidth < 264) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 328px)`;
    } else if (this.screenWidth < 279) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 293px)`;
    } else if (this.screenWidth < 314) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 287px)`;
    } else if (this.screenWidth < 528) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 285px)`;
    } else if (this.screenWidth < 576) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 255px)`;
    } else if (this.screenWidth < 768) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 255px)`;
    } else if (this.screenWidth < 992) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 179px)`;
    } else if (this.screenWidth < 1199) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 160px)`;
    } else {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 160px)`;
    }
  }


  private buildForm(): void {
    this.formQuestion = this.formBuilder.group({
      question: [null, Validators.required],
      groupEconomic: ["", Validators.required]
    })
  }

  get question() { return this.formQuestion.get("question"); }
  get groupEconomic() { return this.formQuestion.get("groupEconomic"); }


  @HostListener('window:resize', ['$event'])
  getScreenSize(event?) {
    this.changeDetectorRef.detectChanges();
    this.screenHeight = window.innerHeight;
    this.screenWidth = window.innerWidth;
  }
}
