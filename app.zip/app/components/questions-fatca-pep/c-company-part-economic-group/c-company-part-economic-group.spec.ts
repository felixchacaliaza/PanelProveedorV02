/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { CCompanyPartEconomicGroup } from './c-company-part-economic-group';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { BcpFormmodule } from '@bcp/ng-core-v3/forms';
import { BcpCommonsModule, BcpSessionStorage } from '@bcp/ng-core-v3';
import { ValidationHttp } from '@src/app/core/http/validation.http';
import { BcpNetworkingModule } from '@bcp/ng-core-v3/networking';
import { RouterTestingModule } from '@angular/router/testing';
import { StateManagerModule } from '@src/app/states/state-manager.module';
import { ModalService } from '@src/app/shared/services/modal-service';
import { BcpAssetsManagerModule } from '@bcp/ng-micro-frontends-v3/assets-manager';
import { environment } from '@src/environments/environment.test';
import { BcpMicroFrontendRouter } from '@bcp/ng-micro-frontends-v3/router';
import { BreakpointObserver } from '@angular/cdk/layout';

describe('CCompanyPartEconomicGroup', () => {
  let component: CCompanyPartEconomicGroup;
  let fixture: ComponentFixture<CCompanyPartEconomicGroup>;  

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule,
        FormsModule,
        BcpFormmodule,
        BcpCommonsModule,
        BcpNetworkingModule,
        RouterTestingModule,
        StateManagerModule,
        BcpAssetsManagerModule.forRoot({
          basePath: `${environment.TARGET_ASSETS}/assets/`
        }),
      ],
      declarations: [CCompanyPartEconomicGroup],
      providers: [
        ModalService,
        ValidationHttp,
        BcpMicroFrontendRouter
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CCompanyPartEconomicGroup);
    component = fixture.componentInstance;
    let storage = TestBed.inject(BcpSessionStorage);
    storage.set("R2D2","Bearer flow4-flow4-flow4-flow4-flow4");
    storage.set("BB8","znak-znak-znak-znak-znak");
    storage.set("AK","flow4-flow4-flow4-flow4-flow4");
    storage.set("RTK","flow4-flow4-flow4-flow4-flow4");
    storage.set("channelOrigin","1");
    storage.set("productOrigin","PPEL-PRCTACTE");
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe("#closeModal", () => {
    it("SHOULD close the modal WHEN 'x' is clicked", () => {
      //Arrange
      spyOn(ModalService.prototype, "closeModal").and.callFake(() => { })
      //Act
      component.closeModal("idmodal");
      //Assert
      expect(ModalService.prototype.closeModal).toHaveBeenCalled()
    })
  })

  describe("#openModal", () => {
    it("SHOULD open the modal WHEN 'conocer más' is clicked", () => {
      //Arrange
      spyOn(ModalService.prototype, "openModal").and.callFake(() => { })
      //Act
      component.openModal("idmodal");
      //Assert
      expect(ModalService.prototype.openModal).toHaveBeenCalled()
    })
  })

  describe("#btnBack",()=>{
    it("SHOULD save step and return step WHEN '<-' is clicked",()=>{
      //Arrange
      //Act
      component.btnBack();
    })
  })

  describe("#btnNext",()=>{
    it("SHOULD save step and go to next step WHEN '->' is clicked",()=>{
      //Arrange
      //Act
      component.btnNext();
    })
  })

  describe("#btnSaveNext",()=>{
    it("SHOULD save step and go to next step WHEN '->' is clicked",()=>{
      //Arrange
      component.groupEconomic.setValue("data");
      component.question.setValue("true")
      //Act
      component.btnSaveNext();
    })
  })

  describe("#ctrlChangeQuestion",()=>{

    it("SHOULD update height WHEN change question's value",()=>{
      //Arrange
      component.groupEconomic.setValue("data");
      component.question.setValue("true")
      //Act
      component.ctrlChangeQuestion({ detail: "true"});
    })

    it("SHOULD update height WHEN change question's value",()=>{
      //Arrange
      component.groupEconomic.setValue("data");
      component.question.setValue("false")
      //Act
      component.ctrlChangeQuestion({ detail: "false"});
    })
    
  })

  describe("#getChangeHeightMainCenterContent",()=>{
    it("SHOULD update height WHEN change question's value",()=>{
      //Arrange
     
      //Act
      component.getChangeHeightMainCenterContent();
    })
  })



});
