import { AfterViewInit, ChangeDetectorRef, HostListener, OnDestroy } from '@angular/core';
import { BreakpointObserver } from '@angular/cdk/layout';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Emittable, Emitter } from '@ngxs-labs/emitter';
import { ValidationHttp } from '@src/app/core/http/validation.http';
import { IValidateComplianceFiltersHttpRequest } from '@src/app/core/models/validate-compliance-filters.model';
import { HttpErrorResponse } from '@angular/common/http';
import { StepState, StepStateModel } from '@src/app/states/step.state';
import { ClearStorageService } from '@src/app/shared/services/clear-storage-service';
import { BcpMicroFrontendRouter } from '@bcp/ng-micro-frontends-v3/router';
import { StatePresenter } from '@src/app/states/state.presenter';


@Component({
  selector: 'c-legal-representative',
  templateUrl: './c-legal-representative.html',
  styleUrls: ['./c-legal-representative.scss']
})
export class CLegalRepresentative implements OnInit, AfterViewInit, OnDestroy {


  @ViewChild('lMainCenterContent', { read: ElementRef, static: false })
  lMainCenterContent: ElementRef;

  @ViewChild('lMainCenter', { read: ElementRef, static: false })
  lMainCenter: ElementRef;

  @Emitter(StepState.register)
  stepRegister: Emittable<StepStateModel>;

  isScreenMobile: boolean = false;
  showLoader: boolean;
  screenHeight;
  screenWidth;
  styleMinHeightlMainCenterContent = '';
  styleMinHeightlMainCenter = '';
  stepState: StepStateModel;
  formQuestion: FormGroup;
  questionResponse: Boolean;

  constructor(
    private formBuilder: FormBuilder,
    private breakPointObserver: BreakpointObserver,
    private changeDetectorRef: ChangeDetectorRef,
    private _validationHttp: ValidationHttp,
    private _microRouter: BcpMicroFrontendRouter,
    private _clearStorageService: ClearStorageService,
    private _statePresenter : StatePresenter
  ) {

    this._statePresenter.selectStateStep().subscribe(stepState => {
      this.stepState = stepState
    });
    window.addEventListener('resize', () => {
      this.changeDetectorRef.detectChanges();
      this.isScreenMobile = this.isMobile();
      this.changeDetectorRef.detectChanges();
      this.getChangeHeightMainCenterContent();
      this.changeDetectorRef.detectChanges();

    });
    this.buildForm();
  }

  ngOnDestroy(): void {
    window.removeEventListener("resize", () => { });
  }

  ngOnInit() {
  }

  ngAfterViewInit(): void {
    this.changeDetectorRef.detectChanges();
    this.getChangeHeightMainCenterContent();
    this.changeDetectorRef.detectChanges();
  }

  isMobile(): boolean {
    let result = this.breakPointObserver.isMatched('(max-width: 767px)');
    return result;
  }

  ctrlChangeQuestion(event: any): void {
    this.questionResponse = event.detail === 'false' ? false : true;
    this.changeDetectorRef.detectChanges();
    this.getChangeHeightMainCenterContent();
    if (event.detail) {
      this.stepRegister.emit({
        legalRepresentative: {
          state: JSON.parse(event.detail),
          question: JSON.parse(event.detail)
        }
      });
      if (event.detail === 'true') {
        this.stepRegister.emit({
          onlyStep: 3
        });
      }
    }

  }

  btnBack() {
    this.stepRegister.emit({
      onlyStep: 1
    });
  }

  closeRequest() {
    this._validateComplianceFilters();
  }



  btnNext() {
    this.stepRegister.emit({
      onlyStep: 3
    });
  }

  getChangeHeightMainCenterContent() {
    this.changeDetectorRef.detectChanges();
    this.getScreenSize();

    if (this.screenWidth < 188) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 348px)`;
    }else if (this.screenWidth < 264) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 328px)`;
    }else if (this.screenWidth < 279) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 293px)`;
    }else if (this.screenWidth < 314) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 287px)`;
    } else if (this.screenWidth < 528) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 285px)`;
    } else if (this.screenWidth < 576) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 255px)`;
    }else if (this.screenWidth < 768) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 255px)`;
    } else if (this.screenWidth < 992) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 179px)`;
    } else if (this.screenWidth < 1199) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 160px)`;
    } else {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 160px)`;
    }
  }

  @HostListener('window:resize', ['$event'])
  getScreenSize(event?) {
    this.changeDetectorRef.detectChanges();
    this.screenHeight = window.innerHeight;
    this.screenWidth = window.innerWidth;
  }

  private buildForm(): void {
    this.formQuestion = this.formBuilder.group({
      question: [(this.stepState.legalRepresentative.question === null ? null : this.stepState.legalRepresentative.question.toString()), Validators.required]
    })
  }

  get question() { return this.formQuestion.get("question"); }

  private _createRequestValidateComplianceFilters(): IValidateComplianceFiltersHttpRequest {

    let request: IValidateComplianceFiltersHttpRequest;

    request = {
      filterQuestions: `Emp. Proceso Constitucion: ${this.stepState.companyProcessConstitution.question === true ? 'SI' : 'NO'} | Rep. Legal a sola firma: ${this.stepState.legalRepresentative.question === true ? 'SI' : 'NO'}`,
      singleUseStatement: this.stepState.infoCtaCte.simpleUseStatement
    }

    return request;
  }

  private _validateComplianceFilters(): void {

    this.showLoader = true;

    let request = this._createRequestValidateComplianceFilters();

    this._validationHttp.validateComplianceFilters(request)
      .toPromise()
      .then((response) => {
        this._clearStorageService.clearSesionStorage();
        this._microRouter.navigateByUrl("/producto/lista","catalogo")

      })
      .catch((error: HttpErrorResponse) => {
        this.showLoader = false;
        console.error(error)
      })
  }

}
