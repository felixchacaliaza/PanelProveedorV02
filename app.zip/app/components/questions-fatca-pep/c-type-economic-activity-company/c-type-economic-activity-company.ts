import { CatalogHttp } from '@src/app/core/http/catalog.http';
import { ChangeDetectorRef, Component, ElementRef, OnInit, ViewChild, AfterViewInit, HostListener } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { EconomicActivityModel } from '@src/app/core/models/economic-activity.model';
import { Emitter, Emittable } from '@ngxs-labs/emitter';
import { StepState, StepStateModel } from '@src/app/states/step.state';
import { ppelValidators } from '@src/app/shared/validators/validators';
import { StatePresenter } from '@src/app/states/state.presenter';

@Component({
  selector: 'c-type-economic-activity-company',
  templateUrl: './c-type-economic-activity-company.html',
  styleUrls: ['./c-type-economic-activity-company.scss']
})
export class CTypeEconomicActivityCompany implements OnInit, AfterViewInit {

  @ViewChild('lMainCenterContent')
  lMainCenterContent: ElementRef;

  @ViewChild('lMainCenter')
  lMainCenter: ElementRef;

  @Emitter(StepState.register)
  stepRegister: Emittable<StepStateModel>;
  styleMinHeightlMainCenterContent = '';
  styleMinHeightlMainCenter = '';
  currentModal: string = "";
  isScreenMobile: boolean = false;
  showLoader: boolean = false;
  screenHeight;
  screenWidth;
  stepState: StepStateModel;
  public listaActividadEconomica: EconomicActivityModel[];
  public requiereInformacionAdicional: Boolean;
  formQuestion: FormGroup;

  constructor(
    private _catalogHttp: CatalogHttp,
    private formBuilder: FormBuilder,
    private changeDetectorRef: ChangeDetectorRef,
    private _statePresenter : StatePresenter
  ) {
    this.requiereInformacionAdicional = false;

    this._statePresenter.selectStateStep().subscribe(stepState => {
      this.stepState = stepState
    });

    this.buildForm();
    this.loadServices();
    window.addEventListener('resize', () => {
      setTimeout(() => {
        this.changeDetectorRef.detectChanges();
        this.getChangeHeightMainCenterContent();
        this.changeDetectorRef.detectChanges();
      }, 0);
    });

  }


  ngAfterViewInit(): void {
    this.changeDetectorRef.detectChanges();
    this.getChangeHeightMainCenterContent();
    this.changeDetectorRef.detectChanges();
  }

  ngOnInit() {

  }

  public ctrlChangeEconomicActivity($event): void {

  }

  public verifyAdditionalInformation(value: string): boolean {
    for (let element of this.listaActividadEconomica)

      if (element.value === value) {
        return element.status;
      }

  }

  public getEconomicActivityDisplay(value: string): string {
    let display = '';
    for (let element of this.listaActividadEconomica)

      if (element.value === value) {
        display = element.display;
        return display;
      }
  }

  btnBack() {
    this.stepRegister.emit({
      onlyStep: 5
    });
  }

  btnSaveNext() {
    if (this.formQuestion.invalid === false) {
      this.stepRegister.emit({
        typeEconomicActivityCompany: {
          state: true,
          activityEconomic: this.economicActivity.value.value
        },
        onlyStep: 7
      });
    }
  }

  btnNext() {
    if (this.formQuestion.invalid === false && this.requiereInformacionAdicional === false) {
      this.stepRegister.emit({
        typeEconomicActivityCompany: {
          state: true,
          activityEconomic: this.economicActivity.value.value
        },
        onlyStep: 7
      });
    } else {
      this.stepRegister.emit({
        typeEconomicActivityCompany: {
          state: true,
          activityEconomic: this.economicActivity.value.value
        },
        onlyStep: 5
      });
    }
  }

  getChangeHeightMainCenterContent() {
    this.changeDetectorRef.detectChanges();
    this.getScreenSize();

    if (this.screenWidth < 188) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 348px)`;
    } else if (this.screenWidth < 264) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 328px)`;
    } else if (this.screenWidth < 279) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 293px)`;
    } else if (this.screenWidth < 314) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 287px)`;
    } else if (this.screenWidth < 528) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 285px)`;
    } else if (this.screenWidth < 576) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 255px)`;
    } else if (this.screenWidth < 768) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 255px)`;
    } else if (this.screenWidth < 992) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 179px)`;
    } else if (this.screenWidth < 1199) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 160px)`;
    } else {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 160px)`;
    }
  }

  private buildForm(): void {
    this.formQuestion = this.formBuilder.group({
      economicActivity: ["", [ppelValidators.customSelectAutoComplete]]
    })
  }
  get economicActivity() { return this.formQuestion.get("economicActivity"); }

  private loadServices(): void {
    this.showLoader = true;
    this._catalogHttp.getListEconomicActivityAutoComplete()
      .subscribe(
        (response) => {
          this.listaActividadEconomica = response;
          this.showLoader = false;
        },
        (error) => {
          this.showLoader = false;
        },
        () => {
          this.showLoader = false;
          this.economicActivity.setValue({ 'value': this.stepState.typeEconomicActivityCompany.activityEconomic, 'display': this.getEconomicActivityDisplay(this.stepState.typeEconomicActivityCompany.activityEconomic) })
        }
      );
  }

  @HostListener('window:resize', ['$event'])
  getScreenSize(event?) {
    this.changeDetectorRef.detectChanges();
    this.screenHeight = window.innerHeight;
    this.screenWidth = window.innerWidth;
  }

}
