/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { CTypeEconomicActivityCompany } from './c-type-economic-activity-company';
import { BcpCommonsModule, BcpSessionStorage } from '@bcp/ng-core-v3';
import { BcpFormmodule } from '@bcp/ng-core-v3/forms';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CatalogHttp } from '@src/app/core/http/catalog.http';
import { ValidationHttp } from '@src/app/core/http/validation.http';
import { RouterTestingModule } from '@angular/router/testing';
import { StateManagerModule } from '@src/app/states/state-manager.module';
import { ClearStorageService } from '@src/app/shared/services/clear-storage-service';
import { BcpAssetsManagerModule } from '@bcp/ng-micro-frontends-v3/assets-manager';
import { environment } from '@src/environments/environment.test';

describe('CTypeEconomicActivityCompany', () => {
  let component: CTypeEconomicActivityCompany;
  let fixture: ComponentFixture<CTypeEconomicActivityCompany>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        BcpCommonsModule,
        BcpFormmodule,
        ReactiveFormsModule,
        HttpClientTestingModule,
        RouterTestingModule,
        FormsModule,
        StateManagerModule,
        BcpAssetsManagerModule.forRoot({
          basePath: `${environment.TARGET_ASSETS}/assets/`
        }),
      ],
      declarations: [CTypeEconomicActivityCompany],
      providers: [
        CatalogHttp,
        ValidationHttp,
        ClearStorageService
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CTypeEconomicActivityCompany);
    component = fixture.componentInstance;
    let storage = TestBed.inject(BcpSessionStorage);
    storage.set("R2D2","Bearer flow4-flow4-flow4-flow4-flow4");
    storage.set("BB8","znak-znak-znak-znak-znak");
    storage.set("AK","flow4-flow4-flow4-flow4-flow4");
    storage.set("RTK","flow4-flow4-flow4-flow4-flow4");
    storage.set("channelOrigin","1");
    storage.set("productOrigin","PPEL-PRCTACTE");
    // fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe("#btnBack", () => {
    it("SHOULD save step and return step WHEN '<-' is clicked", () => {
      //Arrange
      //Act
      component.btnBack();
    })
  })

  describe("#btnNext", () => {
    it("SHOULD save step and go to next step WHEN '->' is clicked", () => {
      //Arrange
      component.requiereInformacionAdicional = false;
      component.economicActivity.setValue({display:"data",value:"data"})
      //Act
      component.btnNext();
    })
  })

  describe("#btnSaveNext", () => {
    it("SHOULD save step and go to next step WHEN '->' is clicked", () => {
      //Arrange
      component.requiereInformacionAdicional = false;
      component.economicActivity.setValue({display:"data",value:"data"})
      //Act
      component.btnSaveNext();
    })
  })

  describe("#getChangeHeightMainCenterContent", () => {
    it("SHOULD update height WHEN change question's value", () => {
      //Arrange

      //Act
      component.getChangeHeightMainCenterContent();
    })
  })

  describe("#getEconomicActivityDisplay",()=>{
    it("SHOULD get the display of economic activity WHEN the method is called",()=>{
      //Arrange
      component.listaActividadEconomica = [{display: "dato", value: "datovalue"}];
      //Act
      expect(component.getEconomicActivityDisplay("datovalue")).toBe("dato")
    })
  })

  describe("#verifyAdditionalInformation",()=>{
    it("SHOULD get the display of economic activity WHEN the method is called",()=>{
      //Arrange
      component.listaActividadEconomica = [{display: "dato", value: "datovalue",status: true}];
      //Act
      expect(component.verifyAdditionalInformation("datovalue")).toBe(true)
    })
  })
  describe("#ctrlChangeEconomicActivity",()=>{
    it("SHOULD update height view WHEN the method is called",()=>{
      //Arrange
      component.listaActividadEconomica = [{display: "dato", value: "datovalue",status: true}];
      component.economicActivity.setValue({display: "dato", value: "datovalue",status: true})
      //Act
      component.ctrlChangeEconomicActivity({})
    })
  })

});
