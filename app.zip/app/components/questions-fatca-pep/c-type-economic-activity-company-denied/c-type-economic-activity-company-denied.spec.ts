/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { CTypeEconomicActivityCompanyDenied } from './c-type-economic-activity-company-denied';
import { BcpCommonsModule, BcpSessionStorage } from '@bcp/ng-core-v3';
import { BcpFormmodule } from '@bcp/ng-core-v3/forms';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CatalogHttp } from '@src/app/core/http/catalog.http';
import { BcpNetworkingModule } from '@bcp/ng-core-v3/networking';
import { ValidationHttp } from '@src/app/core/http/validation.http';
import { RouterTestingModule } from '@angular/router/testing';
import { StateManagerModule } from '@src/app/states/state-manager.module';
import { ModalService } from '@src/app/shared/services/modal-service';
import { ClearStorageService } from '@src/app/shared/services/clear-storage-service';
import { BcpAssetsManagerModule } from '@bcp/ng-micro-frontends-v3/assets-manager';
import { environment } from '@src/environments/environment.test';
import { BcpMicroFrontendRouter } from '@bcp/ng-micro-frontends-v3/router';

describe('CTypeEconomicActivityCompanyDenied', () => {
  let component: CTypeEconomicActivityCompanyDenied;
  let fixture: ComponentFixture<CTypeEconomicActivityCompanyDenied>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports:[
        BcpCommonsModule,
        BcpFormmodule,
        ReactiveFormsModule,
        HttpClientTestingModule,
        BcpNetworkingModule,
        FormsModule,
        RouterTestingModule,
        StateManagerModule,
        BcpAssetsManagerModule.forRoot({
          basePath: `${environment.TARGET_ASSETS}/assets/`
        }),
      ],
      declarations: [ CTypeEconomicActivityCompanyDenied ],
      providers:[
        CatalogHttp,
        ModalService,
        ValidationHttp,
        ClearStorageService,
        BcpMicroFrontendRouter
      ],
      schemas:[CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CTypeEconomicActivityCompanyDenied);
    component = fixture.componentInstance;
    let storage = TestBed.inject(BcpSessionStorage);
    storage.set("R2D2","Bearer flow4-flow4-flow4-flow4-flow4");
    storage.set("BB8","znak-znak-znak-znak-znak");
    storage.set("AK","flow4-flow4-flow4-flow4-flow4");
    storage.set("RTK","flow4-flow4-flow4-flow4-flow4");
    storage.set("channelOrigin","1");
    storage.set("productOrigin","PPEL-PRCTACTE");
    // fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe("#btnBack", () => {
    it("SHOULD save step and return step WHEN '<-' is clicked", () => {
      //Arrange
      //Act
      component.btnBack();
    })
  })

  describe("#btnNext", () => {
    it("SHOULD save step and go to next step WHEN '->' is clicked", () => {
      //Arrange
      component.requiereInformacionAdicional = false;
      component.question.setValue("false")
      //Act
      component.btnNext();
    })
  })

  describe("#getChangeHeightMainCenterContent", () => {
    it("SHOULD update height WHEN change question's value", () => {
      //Arrange

      //Act
      component.getChangeHeightMainCenterContent();
    })
  })

  describe("#getEconomicActivityDisplay",()=>{
    it("SHOULD get the display of economic activity WHEN the method is called",()=>{
      //Arrange
      component.listaActividadEconomica = [{display: "dato", value: "datovalue"}];
      //Act
      expect(component.getEconomicActivityDisplay("datovalue")).toBe("dato")
    })
  })

  describe("#verifyAdditionalInformation",()=>{
    it("SHOULD get the display of economic activity WHEN the method is called",()=>{
      //Arrange
      component.listaActividadEconomica = [{display: "dato", value: "datovalue",status: true}];
      //Act
      expect(component.verifyAdditionalInformation("datovalue")).toBe(true)
    })
  })
 

  describe("#closeModal", () => {
    it("SHOULD close the modal WHEN 'x' is clicked", () => {
      //Arrange
      spyOn(ModalService.prototype, "closeModal").and.callFake(() => { })
      //Act
      component.closeModal("idmodal");
      //Assert
      expect(ModalService.prototype.closeModal).toHaveBeenCalled()
    })
  })

  describe("#openModal", () => {
    it("SHOULD open the modal WHEN 'conocer más' is clicked", () => {
      //Arrange
      spyOn(ModalService.prototype, "openModal").and.callFake(() => { })
      //Act
      component.openModal("idmodal");
      //Assert
      expect(ModalService.prototype.openModal).toHaveBeenCalled()
    })
  })

});
