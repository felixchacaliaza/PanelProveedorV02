import { ChangeDetectorRef, Component, ElementRef, OnInit, ViewChild, AfterViewInit, HostListener } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { EconomicActivityModel } from '@src/app/core/models/economic-activity.model';
import { Emitter, Emittable } from '@ngxs-labs/emitter';
import { HttpErrorResponse } from '@angular/common/http';
import { ValidationHttp } from '@src/app/core/http/validation.http';
import { IValidateComplianceFiltersHttpRequest } from '@src/app/core/models/validate-compliance-filters.model';
import { StepState, StepStateModel } from '@src/app/states/step.state';
import { ModalService } from '@src/app/shared/services/modal-service';
import { ClearStorageService } from '@src/app/shared/services/clear-storage-service';
import { BcpMicroFrontendRouter } from '@bcp/ng-micro-frontends-v3/router';
import { StatePresenter } from '@src/app/states/state.presenter';

@Component({
  selector: 'c-type-economic-activity-company-denied',
  templateUrl: './c-type-economic-activity-company-denied.html',
  styleUrls: ['./c-type-economic-activity-company-denied.scss']
})
export class CTypeEconomicActivityCompanyDenied implements OnInit, AfterViewInit {

  @ViewChild('lMainCenterContent', { read: ElementRef, static: false })
  lMainCenterContent: ElementRef;

  @ViewChild('lMainCenter', { read: ElementRef, static: false })
  lMainCenter: ElementRef;

  @Emitter(StepState.register)
  stepRegister: Emittable<StepStateModel>;
  questionResponse: Boolean;
  styleMinHeightlMainCenterContent = '';
  styleMinHeightlMainCenter = '';
  currentModal: string = "";
  isScreenMobile: boolean = false;
  screenHeight;
  screenWidth;
  showLoader: boolean;
  stepState: StepStateModel;
  public listaActividadEconomica: EconomicActivityModel[];
  public requiereInformacionAdicional: Boolean;
  formQuestion: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private changeDetectorRef: ChangeDetectorRef,
    private modalSrv: ModalService,
    private _microRouter: BcpMicroFrontendRouter,
    private _validationHttp: ValidationHttp,
    private _clearStorageService: ClearStorageService,
    private _statePresenter : StatePresenter
  ) {
    this.requiereInformacionAdicional = false;
    this._statePresenter.selectStateStep().subscribe(stepState => {
      this.stepState = stepState
    });
    this.buildForm();
    window.addEventListener('resize', () => {
      setTimeout(() => {
        this.changeDetectorRef.detectChanges();
        this.getChangeHeightMainCenterContent();
        this.changeDetectorRef.detectChanges();
      }, 0);
    });

  }

  ngAfterViewInit(): void {
    this.changeDetectorRef.detectChanges();
    this.getChangeHeightMainCenterContent();
    this.changeDetectorRef.detectChanges();
  }

  ngOnInit() {
    this.question.setValue(this.stepState.typeEconomicActivityCompanyDenied.question === null ? null : this.stepState.typeEconomicActivityCompanyDenied.question.toString());
  }

  public verifyAdditionalInformation(value: string): boolean {
    for (let element of this.listaActividadEconomica)

      if (element.value === value) {
        return element.status;
      }

  }

  public getEconomicActivityDisplay(value: string): string {
    let display = '';
    for (let element of this.listaActividadEconomica)

      if (element.value === value) {
        display = element.display;
        return display;
      }

  }

  openModal(modalName: string) {
    this.currentModal = modalName;
    this.modalSrv.openModal(modalName);
  }

  closeModal(modalName: string) {
    this.currentModal = "";
    this.modalSrv.closeModal(modalName);
  }

  ctrlCloseModalActividadEconomica($event): void {
    this.currentModal = "";
  }

  ctrlChangeQuestion(event: any): void {
    this.questionResponse = event.detail === 'false' ? false : true;
    this.changeDetectorRef.detectChanges();
    this.getChangeHeightMainCenterContent();
    if (event.detail === 'false') {
      this.stepRegister.emit({
        onlyStep: 6,
        typeEconomicActivityCompanyDenied: {
          state: true,
          question: JSON.parse(event.detail)
        }
      });
    }

  }

  btnBack() {
    this.stepRegister.emit({
      onlyStep: 4
    });
  }

  btnNext() {
    this.stepRegister.emit({
      onlyStep: 6,
      typeEconomicActivityCompanyDenied: {
        state: true,
        question: JSON.parse(this.question.value),
      },
    });
  }

  closeRequest() {
    this._validateComplianceFilters();
  }

  getChangeHeightMainCenterContent() {
    this.changeDetectorRef.detectChanges();
    this.getScreenSize();

    if (this.screenWidth < 188) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 348px)`;
    }else if (this.screenWidth < 264) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 328px)`;
    }else if (this.screenWidth < 279) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 293px)`;
    }else if (this.screenWidth < 314) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 287px)`;
    } else if (this.screenWidth < 528) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 285px)`;
    } else if (this.screenWidth < 576) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 255px)`;
    }else if (this.screenWidth < 768) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 255px)`;
    } else if (this.screenWidth < 992) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 179px)`;
    } else if (this.screenWidth < 1199) {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 160px)`;
    } else {
      this.styleMinHeightlMainCenter = `min-height: calc(${this.screenHeight}px - 160px)`;
    }

  }

  private buildForm(): void {
    this.formQuestion = this.formBuilder.group({
      question: ['', Validators.required]
    })
  }

  get question() { return this.formQuestion.get("question"); }

  private _createRequestValidateComplianceFilters(): IValidateComplianceFiltersHttpRequest {

    let request: IValidateComplianceFiltersHttpRequest;

    request = {
      filterQuestions: `Emp. Proceso Constitucion: ${this.stepState.companyProcessConstitution.question === true ? 'SI' : 'NO'} | Rep. Legal a sola firma: ${this.stepState.legalRepresentative.question === true ? 'SI' : 'NO'} | Emp. Parte Grupo Econoc: ${this.stepState.companyPartEconomic.question === true ? 'SI' : 'NO'} | Act Economica Permitida: ${this.stepState.typeEconomicActivityCompanyDenied.question === true ? 'SI' : 'NO'}`,
      pep: `PEP: ${this.stepState.politicallyExposedPerson.question === true ? 'SI' : 'NO'} | Puesto Cargo: ${this.stepState.politicallyExposedPerson.question === true ? this.stepState.politicallyExposedPerson.position : ''} | Centro Laboral: ${this.stepState.politicallyExposedPerson.question === true ? this.stepState.politicallyExposedPerson.laborCenter : ''}`,
      groupEconomic: `${this.stepState.companyPartEconomic.question === true ? this.stepState.companyPartEconomic.groupEconomic : ''}`,
      singleUseStatement: this.stepState.infoCtaCte.simpleUseStatement
    }

    return request;
  }


  private _validateComplianceFilters(): void {

    this.showLoader = true;
    let request = this._createRequestValidateComplianceFilters();

    this._validationHttp.validateComplianceFilters(request)
      .toPromise()
      .then((response) => {
        this._clearStorageService.clearSesionStorage();
        this._microRouter.navigateByUrl("/producto/lista","catalogo");
      })
      .catch((error: HttpErrorResponse) => {
        this.showLoader = false;
        console.error(error)
      })
  }

  @HostListener('window:resize', ['$event'])
  getScreenSize(event?) {
    this.changeDetectorRef.detectChanges();
    this.screenHeight = window.innerHeight;
    this.screenWidth = window.innerWidth;
  }
}
