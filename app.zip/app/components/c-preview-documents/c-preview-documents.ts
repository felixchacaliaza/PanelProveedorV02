import { IPreviewsHttpRequest } from './../../core/models/previews.model';
import { Component, OnInit, Input, OnChanges, SimpleChanges } from "@angular/core";
import { DocumentHttp } from '@src/app/core/http/document.http';
import { DomSanitizer } from '@angular/platform-browser';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CurrentAccountsHttp } from "@src/app/core/http/current-accounts.http";

export const STATE = {
    LOADING: "loading",
    COMPLETE: "complete",
    FAIL: "fail"
}

export const DOCUMENT: any = {
    BOOK: { name: "Cartilla", code: "doccart", data: null, state: STATE.LOADING, numberPage: 1, totalPage: 0 },
    CONSTANCY: { name: "Constancia de apertura", code: "doccons", data: null, state: STATE.LOADING, numberPage: 1, totalPage: 0 }
}

@Component({
    selector: "c-preview-documents",
    templateUrl: "./c-preview-documents.html",
    styleUrls: ["./c-preview-documents.scss"]
})
export class CPreviewdocuments  {

    @Input() init: boolean = false;
    public document: any = DOCUMENT;
    public documentSelected: any;
    public listDocuments: any[] = [];
    public formDocument: FormGroup;
    zoomPdf: number = 1;
    constructor(
        private _documentHttp: DocumentHttp,
        private _domSanitizer: DomSanitizer,
        private _formBuilder: FormBuilder,
        private _currentAccountsHttp: CurrentAccountsHttp
    ) {
        this._buildForm();
        this._loadListDocuments();
    }

    ngOnInit() {
        this._loadDocuments();
        this.formDocument.get("codeDocument").valueChanges.subscribe(docu => this._onChangeDocument(docu))
    }
   

    onReload(documentCode: string) {
        this._onChangeDocument(documentCode)
    }

    get doc() { return this.formDocument.get("codeDocument") }

    private _onChangeDocument(documentCode: string): void {
        if (documentCode) {
            switch (documentCode) {
                case DOCUMENT.BOOK.code:
                    this.documentSelected = this.document.BOOK;
                    if (!this.document.BOOK.data) this._loadBook();
                    break;
                case DOCUMENT.CONSTANCY.code:
                    this.documentSelected = this.document.CONSTANCY;
                    if (!this.document.CONSTANCY.data) this._loadConstancy();
                    break;
                default: break;
            }
        }
    }

    private _buildForm(): void {
        this.formDocument = this._formBuilder.group({
            codeDocument: ["", [Validators.required]]
        })
    }

    private _loadListDocuments(): void {
        let documents: any[] = Object.keys(this.document);
        documents.forEach((key) => {
            this.listDocuments.push({ code: this.document[key].code, name: this.document[key].name })
        });
        this.doc.setValue(DOCUMENT.BOOK.code);
        this.documentSelected = this.document.BOOK;

    }

    private _loadDocuments(): void {
        this._loadBook();
    }

    private _loadConstancy(): void {
        let request: IPreviewsHttpRequest;
        request = {
            isPreview: true,
            requestCode: 1
        }
        this.document.CONSTANCY.state = STATE.LOADING;
        this._currentAccountsHttp.previews(request)
            .subscribe(
                response => {

                    this.document.CONSTANCY.state = STATE.COMPLETE;
                    this.document.CONSTANCY.data = this._buildSrcDocument(response.content);
                    if (this.documentSelected && this.documentSelected.code == this.doc.value) {
                        this.documentSelected = this.document.CONSTANCY;
                    }
                },
                error => {
                    this.document.CONSTANCY.state = STATE.FAIL;
                    if (this.documentSelected && this.documentSelected.code == this.doc.value) {
                        this.documentSelected = this.document.CONSTANCY;
                    }
                }
            )
    }

    private _loadBook(): void {
        let request: IPreviewsHttpRequest;
        request = {
            isPreview: true,
            requestCode: 0
        }
        this._currentAccountsHttp.previews(request)
            .subscribe(
                response => {

                    this.document.BOOK.state = STATE.COMPLETE;
                    this.document.BOOK.data = this._buildSrcDocument(response.content);
                    if (this.documentSelected && this.documentSelected.code == this.doc.value) {
                        this.documentSelected = this.document.BOOK;
                    }
                },
                error => {
                    this.document.BOOK.state = STATE.FAIL;
                    if (this.documentSelected && this.documentSelected.code == this.doc.value) {
                        this.documentSelected = this.document.BOOK;
                    }
                }
            )
    }

    private _buildSrcDocument(contentPDF: any) {
        const pdf: any = this._domSanitizer.bypassSecurityTrustUrl('data:application/pdf;base64,' + contentPDF);
        return pdf.changingThisBreaksApplicationSecurity;
    }
}
