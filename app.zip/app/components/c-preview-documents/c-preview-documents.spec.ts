import { CPreviewdocuments, DOCUMENT } from "./c-preview-documents";
import { ComponentFixture, waitForAsync, TestBed } from '@angular/core/testing';
import { DocumentHttp } from '@src/app/core/http/document.http';
import { BcpFormmodule } from '@bcp/ng-core-v3/forms';
import { BcpCommonsModule } from '@bcp/ng-core-v3';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { BcpNetworkingModule } from '@bcp/ng-core-v3/networking';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { of } from 'rxjs';
import { CurrentAccountsHttp } from '@src/app/core/http/current-accounts.http';


describe("@CPreviewDocument",()=>{
    let app: CPreviewdocuments;
    let fixture: ComponentFixture<CPreviewdocuments>;
    let StubSanitizer = jasmine.createSpyObj(DomSanitizer,["bypassSecurityTrustUrl"]);
    let StubDocumentHttp = jasmine.createSpyObj(DocumentHttp,["loadDocument"]);

    beforeEach(waitForAsync(()=>{
        TestBed.configureTestingModule({
            imports:[
                BcpFormmodule,
                BcpCommonsModule,
                ReactiveFormsModule,
                FormsModule,
                BcpNetworkingModule
            ],
            declarations:[
                CPreviewdocuments
            ],
            providers:[
                DocumentHttp,
                CurrentAccountsHttp
            ],
            schemas:[CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }))

    beforeEach(()=>{
        fixture = TestBed.createComponent(CPreviewdocuments);
        app = fixture.componentInstance;
    })

    it("SHOULD create component",()=>{
        expect(app).toBeTruthy();
    })

    describe("#ngOnInit",()=>{
        it("SHOULD load the documents WHEN finish the load the page",()=>{
            //Arrange
            spyOn(CurrentAccountsHttp.prototype, "previews").and.callFake(()=>of({content: "VYABC",mimetype:"application/pdf",fileName:"documento"}))
            //Act
            app.ngOnInit()
            expect(app.document.BOOK.state).toBe("complete")
        })
    })

    describe("#onReload",()=>{
        it("SHOULD load again the document WHEN 'volver a cargar' is clicked",()=>{
            //Arrange
            StubSanitizer.bypassSecurityTrustUrl.and.returnValue({changingThisBreaksApplicationSecurity: "" });
            app.document = DOCUMENT;
            app.documentSelected = DOCUMENT.BOOK;
            app.doc.setValue(DOCUMENT.BOOK.code)
            spyOn(CurrentAccountsHttp.prototype, "previews").and.callFake(()=>of({content: "VYABC",mimetype:"application/pdf",fileName:"documento"}))
            //ACt
            app.onReload("doccart")
            //Assert
            expect(app.document.BOOK.state).toBe("complete")
        })

       

        it("SHOULD load again the document WHEN 'volver a cargar' is clicked",()=>{
            //Arrange
            StubSanitizer.bypassSecurityTrustUrl.and.returnValue({changingThisBreaksApplicationSecurity: "" });
            app.document = DOCUMENT;
            app.documentSelected = DOCUMENT.CONSTANCY;
            app.doc.setValue(DOCUMENT.CONSTANCY.code)
            spyOn(CurrentAccountsHttp.prototype, "previews").and.callFake(()=>of({content: "VYABC",mimetype:"application/pdf",fileName:"documento"}))
            //ACt
            app.onReload("doccons")
            //Assert
            expect(app.document.CONSTANCY.state).toBe("complete")
        })

        it("SHOULD load again the document WHEN 'volver a cargar' is clicked",()=>{
            //Arrange
            StubSanitizer.bypassSecurityTrustUrl.and.returnValue({changingThisBreaksApplicationSecurity: "" });
            spyOn(CurrentAccountsHttp.prototype, "previews").and.callFake(()=>of({content: "VYABC",mimetype:"application/pdf",fileName:"documento"}))
            //ACt
            app.onReload("doc")
            //Assert
          
        })

        it("SHOULD load again the document WHEN 'volver a cargar' is clicked",()=>{
            //Arrange
            StubSanitizer.bypassSecurityTrustUrl.and.returnValue({changingThisBreaksApplicationSecurity: "" });
            spyOn(CurrentAccountsHttp.prototype, "previews").and.callFake(()=>of({content: "VYABC",mimetype:"application/pdf",fileName:"documento"}))
            //ACt
            app.onReload("")
            //Assert
          
        })
    })

})