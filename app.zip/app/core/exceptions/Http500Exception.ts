import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { DataException, BcpException } from '@bcp/ng-core-v3/error-handler';
 
@Injectable()
export class Http500Exception implements BcpException<object> {
  constructor(
    private routes: Router,
  ) {}
  fire(code, data: DataException<object>) {
    console.error('exption 500', data, code);
     this.routes.navigate(['/login']);
  }
}