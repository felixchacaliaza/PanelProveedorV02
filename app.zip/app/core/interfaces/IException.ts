export interface IExceptionDetail{
    code?:string;
    component?:string;
    description?:string;
}