import { Injectable } from "@angular/core";
import { BcpNetworking, BcpAdapter } from '@bcp/ng-core-v3/networking';
import { Observable } from 'rxjs';
import { environment } from '@src/environments/environment';
import { EmptyModel } from '../models/empty.model';
import { map } from 'rxjs/operators';
import { IQualificationRequest } from '../models/qualification.model';

@Injectable()
export class QualificationHttp extends BcpNetworking {

    /**
     * Registra la calificación y comentario realizado por el usuario.
     * @param request contiene los parámetros 'rating' y  'comment' (calificación y comentario respectivamente)
     */
    @BcpAdapter(EmptyModel, "data")
    submitRating(request: IQualificationRequest): Observable<EmptyModel> {
        const url: string = `${environment.API_BCP_URL}${environment.API_UX_CAS}/surveys`;
        return this.networking.post(url, request)
            .pipe(map(
                (data: EmptyModel) => {
                    return data ? data : {};
                }
            ))
    }
}
