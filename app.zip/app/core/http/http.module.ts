import { CurrentAccountsHttp } from './current-accounts.http';
import { NgModule } from '@angular/core';
import { BcpNetworkingModule } from '@bcp/ng-core-v3/networking';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { ValidationHttp } from './validation.http';
import { CommonModule } from '@angular/common';
import { Http500Exception } from '../exceptions/Http500Exception';
import { HttpCtaCteInterceptor } from './httpCtaCteInterceptor';
import { DocumentHttp } from './document.http';
import { QualificationHttp } from './qualification.http';
import { CatalogHttp } from './catalog.http';
import { GeolocationHttp } from './geolocation.http';
import { DatosHttp } from './datos.http';
import { ExceptionService } from '../services/exception.service';
import { SessionHttp } from './session.http';



@NgModule({
  imports: [
    CommonModule,
    BcpNetworkingModule,
    HttpClientModule
  ],
  providers:[
    { provide: HTTP_INTERCEPTORS, useClass: HttpCtaCteInterceptor ,multi: true},
    ValidationHttp,
    DatosHttp,
    CurrentAccountsHttp,
    DocumentHttp,
    CatalogHttp,
    GeolocationHttp,
    QualificationHttp,
    Http500Exception,
    ExceptionService,
    SessionHttp
  ],
  exports:[
    HttpClientModule,
    BcpNetworkingModule,
  ]
})
export class HttpCtaCteModule { }
