import { Injectable } from "@angular/core";
import { BcpNetworking, BcpAdapter } from '@bcp/ng-core-v3/networking';
import { Observable } from 'rxjs';
import { environment } from '@src/environments/environment';
import { GeolocationModel } from '../models/geolocation.model';

@Injectable()
export class GeolocationHttp extends BcpNetworking{

    /**
     * Obtiene la lista de departamentos
     */
    @BcpAdapter(GeolocationModel,"data")
    getListDepartment():Observable<GeolocationModel[]>{
        const url:string = `${environment.API_BCP_URL}${environment.API_UX_C}/departments`;
        return this.networking.get<GeolocationModel[]>(url);
    }

    /**
     * Obtiene la lista de provincias
     * @param codeDepartment es el código de departamento
     */
    @BcpAdapter(GeolocationModel,"data")
    getListProvince(codeDepartment:string):Observable<GeolocationModel[]>{
        const url:string = `${environment.API_BCP_URL}${environment.API_UX_C}/provinces/${codeDepartment}`;
        return this.networking.get<GeolocationModel[]>(url)
    }

    /**
     * Obtiene la lista de distritos
     * @param codeDepartment es el código de departamento
     * @param codeProvince es el código de provincia
     */
    @BcpAdapter(GeolocationModel,"data")
    getListDistrict(codeDepartment:string, codeProvince:string):Observable<GeolocationModel[]>{
        const url:string = `${environment.API_BCP_URL}${environment.API_UX_C}/districts/${codeDepartment}/${codeProvince}`;
        return this.networking.get<GeolocationModel[]>(url)
    }
}