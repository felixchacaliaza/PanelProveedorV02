import { Injectable } from "@angular/core";
import { BcpNetworking, BcpAdapter } from '@bcp/ng-core-v3/networking';
import { Observable } from 'rxjs';
import { environment } from '@src/environments/environment';
import { ICatalogRequest, CatalogModel, OccupationModel } from '../models/catalog.model';
import { map, take } from 'rxjs/operators';
import { EconomicActivityModel } from "../models/economic-activity.model";
import { TypeCompanyModel } from "../models/type-company.model";
import { BranchOfficeModel } from '../models/branch-office.model';

@Injectable()
export class CatalogHttp extends BcpNetworking {

  @BcpAdapter(CatalogModel, "data")
  getListProfesion(): Observable<CatalogModel[]> {
    let url: string = `${environment.API_BCP_URL}${environment.API_UX_VCAS}/catalogs`;
    return this.networking.post(url, { code: "CPCC-PROF" })
      .pipe(map(
        (data: CatalogModel[]) => {
          return data;
        }
      ), take(1));
  }

  @BcpAdapter(EconomicActivityModel, "data")
  getListEconomicActivityAutoComplete(): Observable<EconomicActivityModel[]> {
    let url: string = `${environment.API_BCP_URL}${environment.API_UX_VCAS}/catalogs`;
    return this.networking.post(url, { code: "CPCC-ACEC", flagFilters: "1" })
      .pipe(map(
        (data: EconomicActivityModel[]) => {
          return data;
        }
      ), take(1));
  }

  @BcpAdapter(TypeCompanyModel, "data")
  getListTypeCompany(): Observable<TypeCompanyModel[]> {
    let url: string = `${environment.API_BCP_URL}${environment.API_UX_VCAS}/catalogs`;
    return this.networking.post(url, { code: "CPCC-TIEMP" })
      .pipe(map(
        (data: TypeCompanyModel[]) => {
          return data;
        }
      ), take(1));
  }

  @BcpAdapter(BranchOfficeModel, "data")
  getListBranchOffice(): Observable<BranchOfficeModel[]> {
    let url: string = `${environment.API_BCP_URL}${environment.API_UX_VCAS}/branch-offices`;
    return this.networking.get(url)
      .pipe(map(
        (data: BranchOfficeModel[]) => {
          return data;
        }
      ), take(1));
  }

  /**
* Obtiene una lista de tipo de ocupaciones.
*/

  @BcpAdapter(OccupationModel, "data")
  getListOccupations(): Observable<OccupationModel[]> {
    const url: string = `${environment.API_BCP_URL}${environment.API_UX_VCAS}/labor-types`;
    return this.networking.get(url)
      .pipe(map(
        (data: OccupationModel[]) => {
          return data;
        }
      ), take(1));
  }

}
