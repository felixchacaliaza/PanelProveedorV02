import { CatalogHttp } from "./catalog.http";
import { HttpClient } from '@angular/common/http';
import { of } from 'rxjs';
import { CatalogModel, OccupationModel } from '../models/catalog.model';
import { TypeCompanyModel } from '../models/type-company.model';
import { EconomicActivityModel } from '../models/economic-activity.model';
import { BranchOfficeModel } from '../models/branch-office.model';

describe("@Catalog", () => {
    let service: CatalogHttp;
    let StubHttpClient = jasmine.createSpyObj(HttpClient, ["get", "post"]);

    beforeEach(() => {
        service = new CatalogHttp(StubHttpClient);
    })

    describe("#getListProfesion", () => {
        it("SHOULD fetch a specific list WHEN this service is called", async () => {
            //Arrange
            const mockApiResponse = of([{ code: "01", name: "catalog-name" }]);
            StubHttpClient.post.and.returnValue(mockApiResponse);
            //Act
            const [response] = await service.getListProfesion().toPromise();
            //Assert
            expect(response).toBeInstanceOf(CatalogModel)
        })
    })

    describe("#getListEconomicActivityAutoComplete", () => {
        it("SHOULD get a list activity  WHEN this service is called", async () => {
            //Arrange
            const mockApiResponse = of([{ code: "01", name: "catalog-name" }]);
            StubHttpClient.post.and.returnValue(mockApiResponse);
            //Act
            const [response] = await service.getListEconomicActivityAutoComplete().toPromise();
            //Assert
            expect(response).toBeInstanceOf(EconomicActivityModel)
        })
    })

    describe("#getListTypeCompany", () => {
        it("SHOULD get a list of occupations WHEN this service is called", async () => {
            //Arrange
            const mockApiResponse = of([{ code: "01", name: "catalog-name" }]);
            StubHttpClient.post.and.returnValue(mockApiResponse);
            //Act
            const [response] = await service.getListTypeCompany().toPromise();
            //Assert
            expect(response).toBeInstanceOf(TypeCompanyModel)
        })
    })

    describe("#getListBranchOffice",()=>{
        it("SHOULD get list branchs offices WHEN 'getListBranchOffice' is called",async()=>{
            //Arrange
            const mockApiResponse = of([{region:"",district:[]}]);
            StubHttpClient.get.and.returnValue(mockApiResponse);
            //Act
            const [response] = await service.getListBranchOffice().toPromise();
            //Arrange
           
            expect(response).toBeInstanceOf(BranchOfficeModel)
        })
    })

    describe("#getListOccupations",()=>{
        it("SHOULD get list occupations WHEN 'getListOccupations' is called",async()=>{
            //Arrange
            const mockApiResponse = of([{laborTypeId:"",description:""}]);
            StubHttpClient.get.and.returnValue(mockApiResponse);
            //Act
            const [response] = await service.getListOccupations().toPromise();
            //Arrange
           
            expect(response).toBeInstanceOf(OccupationModel)
        })
    })
})