import { GeolocationHttp } from "./geolocation.http";
import { HttpClient } from '@angular/common/http';
import { of } from 'rxjs';
import { GeolocationModel } from '../models/geolocation.model';

describe("@GeolocationHttp",()=>{
    let service: GeolocationHttp;
    let StubHttpClient = jasmine.createSpyObj(HttpClient,["get"]);

    beforeEach(()=>{
        service = new GeolocationHttp(StubHttpClient);
    })

    describe("#getListDepartment",()=>{
        it("SHOULD load a document WHEN method getDocument is called",async()=>{
            //Arrange
            const mockApiResponse = of([{code: "", description:""}]);
            StubHttpClient.get.and.returnValue(mockApiResponse);
            //Act
            const [response] =  await service.getListDepartment().toPromise();
            //Assert
            expect(response).toBeInstanceOf(GeolocationModel)

        })
    })

    describe("#getListProvince",()=>{
        it("SHOULD load a document WHEN method getDocument is called",async()=>{
            //Arrange
            const mockApiResponse = of([{code: "", description:""}]);
            StubHttpClient.get.and.returnValue(mockApiResponse);
            //Act
            const [response] =  await service.getListProvince("codepa").toPromise();
            //Assert
            expect(response).toBeInstanceOf(GeolocationModel)

        })
    })

    describe("#getListDistrict",()=>{
        it("SHOULD load a document WHEN method getDocument is called",async()=>{
            //Arrange
            const mockApiResponse = of([{code: "", description:""}]);
            StubHttpClient.get.and.returnValue(mockApiResponse);
            //Act
            const [response] =  await service.getListDistrict("codepa","copro").toPromise();
            //Assert
            expect(response).toBeInstanceOf(GeolocationModel)

        })
    })

})