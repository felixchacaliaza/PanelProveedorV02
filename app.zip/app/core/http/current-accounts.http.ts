import { IPreviewsHttpRequest, PreviewsModel } from './../models/previews.model';
import { Injectable } from "@angular/core";
import { Observable } from 'rxjs';
import { BcpNetworking, BcpAdapter } from '@bcp/ng-core-v3/networking';
import { map, take } from 'rxjs/operators';
import { environment } from '@src/environments/environment';
import { IInititalDataHttpRequest, InititalDataModel } from "../models/initial-data.model";
import { EmptyModel } from "../models/empty.model";
import { IRegisterCurrentAccountHttpRequest, RegisterCurrentAccountModel } from '../models/register-current-account.model';

@Injectable()
export class CurrentAccountsHttp extends BcpNetworking {


  @BcpAdapter(EmptyModel, "data")
  validateBusinessName(businessName: string): Observable<EmptyModel> {
    let url: string = `${environment.API_BCP_URL}${environment.API_UX_CAS}/persons/validate?businessName=${businessName}`;
    return this.networking.post(url,{})
      .pipe(map(
        (data: EmptyModel) => {
          return data ? data : {};
        }
      ), take(1));
  }

  @BcpAdapter(PreviewsModel, "data")
  previews(request: IPreviewsHttpRequest): Observable<PreviewsModel> {
    let url: string = `${environment.API_BCP_URL}${environment.API_UX_CAS}/document-managements/previews`;
    return this.networking.post(url,request)
      .pipe(map(
        (data: PreviewsModel) => {
          return data ? data : {};
        }
      ), take(1));
  }

  @BcpAdapter(EmptyModel, "data")
  registerPersonsCompany(): Observable<EmptyModel> {
    let url: string = `${environment.API_BCP_URL}${environment.API_UX_CAS}/persons/register`;
    return this.networking.post(url,{})
      .pipe(map(
        (data: EmptyModel) => {
          return data ? data : {};
        }
      ), take(1));
  }

  @BcpAdapter(RegisterCurrentAccountModel, "data")
  registerCurrentAccount(request: IRegisterCurrentAccountHttpRequest): Observable<RegisterCurrentAccountModel> {
    let url: string = `${environment.API_BCP_URL}${environment.API_UX_CAS}/`;
    return this.networking.post(url,request)
      .pipe(map(
        (data: RegisterCurrentAccountModel) => {
          return data ? data : {};
        }
      ), take(1));
  }
}
