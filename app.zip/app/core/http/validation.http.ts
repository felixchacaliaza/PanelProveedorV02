import { ValidationNegativeFileModel } from './../models/validation-negative-file.model';
import { Injectable } from "@angular/core";
import { Observable } from 'rxjs';
import { EmptyModel, IEmptyRequest } from '../models/empty.model';
import { BcpNetworking, BcpAdapter } from '@bcp/ng-core-v3/networking';
import { map, take } from 'rxjs/operators';
import { environment } from '@src/environments/environment';
import { IValidateComplianceFiltersHttpRequest, ValidateComplianceFiltersModel } from "../models/validate-compliance-filters.model";
import { BranchOfficeModel } from '../models/branch-office.model';
import { OccupationModel } from '../models/catalog.model';
import { HttpHeaders } from '@angular/common/http';
import { IValidationPersonRequest } from '../models/validation.model';

@Injectable()
export class ValidationHttp extends BcpNetworking {

  /**
   * Valida si se está accediendo en el horario establecido
   */
  @BcpAdapter(EmptyModel, "data")
  validateTheOpeningHours(): Observable<EmptyModel> {
    let url: string = `${environment.API_BCP_URL}${environment.API_UX_L}/validate-parameters`;
    return this.networking.post(url, <IEmptyRequest>{})
      .pipe(map(
        (data: EmptyModel) => {
          return data ? data : {};
        }
      ))
  }

  /**
   * Valida si el usuario tiene el segmento permitido para este flujo
   */
  @BcpAdapter(EmptyModel, "data")
  validateTheAllowedSegment(): Observable<EmptyModel> {
    let url: string = `${environment.API_BCP_URL}${environment.API_UX_L}/validate-segment`;
    return this.networking.post(url, <IEmptyRequest>{})
      .pipe(map(
        (data: EmptyModel) => {
          return data ? data : {};
        }
      ))
  }

  /**
   * Validate el tipo de persona que ha ingresado para guardarlo en cache de redis
   */
  @BcpAdapter(EmptyModel, "data")
  codeRequest(): Observable<EmptyModel> {

    let url: string = `${environment.API_BCP_URL}${environment.API_UX_VCAS}/code-request`;
    return this.networking.post(url,{})
      .pipe(map(
        (data: EmptyModel) => {
          return data ? data : {};
        }
      ), take(1));
  }

  @BcpAdapter(EmptyModel, "data")
  validateTypeClient(request: IValidationPersonRequest): Observable<EmptyModel> {
    let url: string = `${environment.API_BCP_URL}${environment.API_UX_VCAS}/person`;
    return this.networking.post(url,request)
      .pipe(map(
        (data: EmptyModel) => {
          return data ? data : {};
        }
      ), take(1));
  }


  /**
   * Valida si el usuario se encuentra en archivo negativo
   */
  @BcpAdapter(ValidationNegativeFileModel, "data")
  validateNegativeFile(): Observable<ValidationNegativeFileModel> {

    let url: string = `${environment.API_BCP_URL}${environment.API_UX_VCAS}/validate-negative-file`;
    return this.networking.get(url)
      .pipe(map(
        (data: ValidationNegativeFileModel) => {
          return data;
        }
      ), take(1));
  }

  /**
   * Valida el filtro de cumplimiento
   */
  @BcpAdapter(ValidateComplianceFiltersModel, "data")
  validateComplianceFilters(request: IValidateComplianceFiltersHttpRequest): Observable<EmptyModel> {
    let url: string = `${environment.API_BCP_URL}${environment.API_UX_VCAS}/compliance-filters`;
    return this.networking.patch(url, request)
      .pipe(map(
        (data: ValidateComplianceFiltersModel) => {
          return data ? data : {};
        }
      ), take(1));
  }



}
