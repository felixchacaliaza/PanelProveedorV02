import { DatosHttp } from "./datos.http";
import { HttpClient } from '@angular/common/http';
import { of } from 'rxjs';
import { InititalDataModel } from '../models/initial-data.model';


describe("@DatosHttp",()=>{
    let service: DatosHttp;
    let StubHttpClient = jasmine.createSpyObj(HttpClient,["post"]);

    beforeEach(()=>{
        service = new DatosHttp(StubHttpClient);
    })

     describe("#initialData", () => {
        it("SHOULD initial data WHEN this service is called", async () => {
            //Arrange
            const mockApiResponse = of({});
            StubHttpClient.post.and.returnValue(mockApiResponse);
            //Act
            const response = await service.initialData({
                currency: {},branchOffice:{},legalRepresentative:{}
            }).toPromise();
            //Assert
            expect(response).toBeInstanceOf(InititalDataModel)
        })
    })

})