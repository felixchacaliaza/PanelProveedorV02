import { HttpCtaCteInterceptor } from "./httpCtaCteInterceptor";
import { BcpSessionStorage } from '@bcp/ng-core-v3';
import { BcpMicroFrontendRouter } from '@bcp/ng-micro-frontends-v3/router';
import { ExceptionService } from '../services/exception.service';
import { HttpHandler, HttpRequest, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

describe("@HttpCtaCteInterceptor", () => {
    let interceptor: HttpCtaCteInterceptor;
    const StubBcpSessionStorage = jasmine.createSpyObj(BcpSessionStorage, ["get"]);
    const StubMicroFrontendRouter = jasmine.createSpyObj(BcpMicroFrontendRouter, ["navigateByUrl"]);
    const StubExceptionService = jasmine.createSpyObj(ExceptionService, ["checkExceptionDetails", "findCustomException"]);

    beforeEach(() => {
        interceptor = new HttpCtaCteInterceptor(StubBcpSessionStorage, StubMicroFrontendRouter, StubExceptionService);
    })

    describe("#intercept", () => {

        it("not should got to error if is ignore", () => {
            StubBcpSessionStorage.get.and.returnValue("test");
            const next: any = {
                handle: () => {
                    return Observable.create(subscriber => {
                        subscriber.complete()
                    })
                }
            }
            const request = new HttpRequest("GET","/persons/validate")

            interceptor.intercept(request,next)
            .subscribe(()=>{

            })
        })

        it("should got to error if this it has occurred", () => {
            StubBcpSessionStorage.get.and.returnValue("test");
            const next: any = {
                handle: () => {
                    return Observable.create(subscriber => {
                        subscriber.complete()
                    })
                }
            }
            const request = new HttpRequest("GET","/abc")

            interceptor.intercept(request,next)
            .subscribe(()=>{
                
            })
        })
    })
})