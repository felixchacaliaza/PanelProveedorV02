import { Injectable } from "@angular/core";
import { BcpNetworking, BcpAdapter } from '@bcp/ng-core-v3/networking';
import { Observable } from 'rxjs';
import { environment } from '@src/environments/environment';
import { map, take } from 'rxjs/operators';
import { EmptyModel } from '../models/empty.model';

@Injectable()
export class DocumentHttp extends BcpNetworking {


    @BcpAdapter(EmptyModel, "data")
    uploadDocument(base64: string): Observable<EmptyModel> {
        let url: string = `${environment.API_BCP_URL}${environment.API_UX_CAS}/document-managements/uploads`;
        return this.networking.post(url, { base64: base64 })
            .pipe(map(
                (data: EmptyModel) => {
                    return data ? data : {};
                }
            ), take(1));
    }
}