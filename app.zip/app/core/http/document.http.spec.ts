import { DocumentHttp } from "./document.http";
import { HttpClient } from '@angular/common/http';
import { of } from 'rxjs';
import { EmptyModel } from '../models/empty.model';


describe("@DocumentHttp",()=>{
    let service: DocumentHttp;
    let StubHttpClient = jasmine.createSpyObj(HttpClient,["post"]);

    beforeEach(()=>{
        service = new DocumentHttp(StubHttpClient);
    })

      describe("#uploadDocument", () => {
        it("SHOULD sent file WHEN this service is called", async () => {
            //Arrange
            const mockApiResponse = of({});
            StubHttpClient.post.and.returnValue(mockApiResponse);
            //Act
            const response = await service.uploadDocument("name").toPromise();
            //Assert
            expect(response).toBeInstanceOf(EmptyModel)
        })
    })
    
})