import { QualificationHttp } from "./qualification.http";
import { of } from 'rxjs';
import { EmptyModel } from '../models/empty.model';

describe("@Qualification",()=>{
    let service: QualificationHttp;
    let StubHttpClient = jasmine.createSpyObj(QualificationHttp,["post"]);

    beforeEach(()=>{
        service = new QualificationHttp(StubHttpClient);
    })

    describe("#submitRating",()=>{
        it("SHOULD record the rating WHEN  you click submit",async ()=>{
            //Arrange
            const mockApiResponse = of({});
            StubHttpClient.post.and.returnValue(mockApiResponse);
            //Act
            const myResponse = await service.submitRating({rating: 5, comment: "mi comentario"}).toPromise();
            //Assert
            expect(myResponse).toBeInstanceOf(EmptyModel)
        })
    })
})