import { Injectable } from "@angular/core";
import { BcpNetworking, BcpAdapter } from '@bcp/ng-core-v3/networking';
import { EmptyModel } from '../models/empty.model';
import { Observable } from 'rxjs';
import { environment } from '@src/environments/environment';

@Injectable()
export class SessionHttp extends BcpNetworking {

    @BcpAdapter(EmptyModel, "data")
    close(reason: string): Observable<EmptyModel> {
        const url = `${environment.API_BCP_URL}${environment.API_UX_CAS}/logout`;
        return this.networking.post(url, { reason });
    }
}