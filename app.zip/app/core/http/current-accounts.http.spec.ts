import { CurrentAccountsHttp } from "./current-accounts.http";
import { HttpClient } from '@angular/common/http';
import { of } from 'rxjs';
import { EmptyModel } from '../models/empty.model';
import { PreviewsModel } from '../models/previews.model';
import { RegisterCurrentAccountModel } from '../models/register-current-account.model';

describe("@CurrentAccounts", () => {
    let service: CurrentAccountsHttp;
    let StubHttpClient = jasmine.createSpyObj(HttpClient, ["get", "post"]);

    beforeEach(() => {
        service = new CurrentAccountsHttp(StubHttpClient);
    })


    describe("#validateBusinessName", () => {
        it("SHOULD validate business name WHEN this service is called", async () => {
            //Arrange
            const mockApiResponse = of({});
            StubHttpClient.post.and.returnValue(mockApiResponse);
            //Act
            const response = await service.validateBusinessName("name").toPromise();
            //Assert
            expect(response).toBeInstanceOf(EmptyModel)
        })
    })



    describe("#previews", () => {
        it("SHOULD previews WHEN this service is called", async () => {
            //Arrange
            const mockApiResponse = of({documents:[{ content: "",mimetype:"",fileName:""}]});
            StubHttpClient.post.and.returnValue(mockApiResponse);
            //Act
            const response = await service.previews({}).toPromise();
            //Assert
            expect(response).toBeInstanceOf(PreviewsModel)
        })
    })

    describe("#registerPersonsCompany", () => {
        it("SHOULD register persons WHEN this service is called", async () => {
            //Arrange
            const mockApiResponse = of({});
            StubHttpClient.post.and.returnValue(mockApiResponse);
            //Act
            const response = await service.registerPersonsCompany().toPromise();
            //Assert
            expect(response).toBeInstanceOf(EmptyModel)
        })
    })

    describe("#registerCurrentAccount", () => {
        it("SHOULD register current account WHEN this service is called", async () => {
            //Arrange
            const mockApiResponse = of({});
            StubHttpClient.post.and.returnValue(mockApiResponse);
            //Act
            const response = await service.registerCurrentAccount({termConditions: true, dataVeracity: true}).toPromise();
            //Assert
            expect(response).toBeInstanceOf(RegisterCurrentAccountModel)
        })
    })

})
