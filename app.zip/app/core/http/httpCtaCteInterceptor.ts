import { Injectable } from "@angular/core";
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BcpSessionStorage } from '@bcp/ng-core-v3';
import { tap } from 'rxjs/operators';
import { BcpMicroFrontendRouter } from '@bcp/ng-micro-frontends-v3/router';
import { ExceptionService } from '../services/exception.service';


const HEADER = {
    CHANNEL_ORIGIN: "channel-origin",
    PRODUCT_ORIGIN: "product-origin",
    ZNAK: "ZNAK",
    AUTHORIZATION: "Authorization",
    AUTHENTICATION_KEY: "authenticationKey"
}

@Injectable()
export class HttpCtaCteInterceptor implements HttpInterceptor {

    constructor(
        private _bcpSessionStorage: BcpSessionStorage,
        private _microFrontendRouter: BcpMicroFrontendRouter,
        private _exceptionSrv: ExceptionService
    ) {

    }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

        let httpReq = req.clone({
            headers: req.headers
                .set(HEADER.AUTHENTICATION_KEY, this._bcpSessionStorage.get("AK"))
                .set(HEADER.AUTHORIZATION, this._bcpSessionStorage.get("R2D2"))
                .set(HEADER.ZNAK, this._bcpSessionStorage.get("BB8"))
                .set(HEADER.CHANNEL_ORIGIN, this._bcpSessionStorage.get("channelOrigin"))
                .set(HEADER.PRODUCT_ORIGIN, this._bcpSessionStorage.get("productOrigin"))
        })

        if (req.url.match("/persons/validate")) {
            return next.handle(httpReq).pipe(tap(
                response => { },
                error => {
                    throw <HttpErrorResponse>error
                }
            ))
        } else {
            return next.handle(httpReq).pipe(tap(
                response => { },
                error => {
                    this._errorHandler(error)
                }
            ))
        }

    }

    private _errorHandler(httpError: HttpErrorResponse) {

        if (httpError.status == 500) {
            const hasExceptionDetails = this._exceptionSrv.checkExceptionDetails(httpError.error);
            if (hasExceptionDetails) {
                let customException = this._exceptionSrv.findCustomException(httpError.error.exceptionDetails);
                if (customException) {
                    this._redirectToCustomErrorPage(customException.code)
                } else {
                    this._redirectToGenericErrorPage();
                }
            }
        } else {
            this._redirectToGenericErrorPage();
        }

    }

    private _redirectToGenericErrorPage(): void {
        this._microFrontendRouter.navigateByUrl('/error', 'error');
    }

    private _redirectToCustomErrorPage(codeYM: string): void {
        switch (codeYM) {
            case "YM0001":
                this._microFrontendRouter.navigateByUrl('/stop/no-cliente', 'error');
                break;

            case "YM0007":
                this._microFrontendRouter.navigateByUrl('/stop/horario-de-atencion', 'error');
                break;
            default:
                this._redirectToGenericErrorPage();
                break;
        }
    }



}

