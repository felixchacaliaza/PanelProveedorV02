import { ValidationHttp } from "./validation.http";
import { HttpClient } from '@angular/common/http';
import { of } from 'rxjs';
import { EmptyModel } from '../models/empty.model';
import { ValidationNegativeFileModel } from '../models/validation-negative-file.model';
import { ValidateComplianceFiltersModel } from '../models/validate-compliance-filters.model';

describe("@ValidationHttp",()=>{
    let service: ValidationHttp;
    let StubHtppClient = jasmine.createSpyObj(HttpClient,["post","get","patch"]);

    beforeEach(()=>{
        service = new ValidationHttp(StubHtppClient);
    })

    describe("#validateTheOpeningHours",()=>{
        it("SHOULD validate the opening hours WHEN you enter the flow",async()=>{
            //Arrange
            const mockApiResponse = of({});
            StubHtppClient.post.and.returnValue(mockApiResponse);
            //Act
            const myResponse = await service.validateTheOpeningHours().toPromise();
            //Arrange
            expect(myResponse).toBeInstanceOf(EmptyModel)
        })
    })

    describe("#validateComplianceFilters",()=>{
        it("SHOULD validate compliance hours WHEN you enter the flow",async()=>{
            //Arrange
            const mockApiResponse = of({});
            StubHtppClient.patch.and.returnValue(mockApiResponse);
            //Act
            const myResponse = await service.validateComplianceFilters({ filterQuestions: "",pep: "", singleUseStatement: true, groupEconomic: "", activityEconomic: ""}).toPromise();
            //Arrange
            expect(myResponse).toBeInstanceOf(ValidateComplianceFiltersModel)
        })
    })

    describe("#validateTheAllowedSegment",()=>{
        it("SHOULD validate the segment WHEN you enter the flow",async()=>{
            //Arrange
            const mockApiResponse = of({});
            StubHtppClient.post.and.returnValue(mockApiResponse);
            //Act
            const myResponse = await service.validateTheAllowedSegment().toPromise();
            //Arrange
            expect(myResponse).toBeInstanceOf(EmptyModel)
        })
    })

    describe("#validateTypeClient",()=>{
        it("SHOULD validate person type WHEN 'let is start' is clicked",async()=>{
            //Arrange
            const mockApiResponse = of({});
            StubHtppClient.post.and.returnValue(mockApiResponse);
            //Act
            const myResponse = await service.validateTypeClient({idc:"987654321"}).toPromise();
            //Arrange
            expect(myResponse).toBeInstanceOf(EmptyModel)
        })
    })

    describe("#validateTypeClient",()=>{
        it("SHOULD validate negative file WHEN 'let is start' is clicked",async()=>{
            //Arrange
            const mockApiResponse = of({});
            StubHtppClient.get.and.returnValue(mockApiResponse);
            //Act
            const myResponse = await service.validateNegativeFile().toPromise();
            //Arrange
            expect(myResponse).toBeInstanceOf(ValidationNegativeFileModel)
        })
    })

    describe("#codeRequest",()=>{
        it("SHOULD validate code WHEN 'codeRequest' is called",async()=>{
            //Arrange
            const mockApiResponse = of({});
            StubHtppClient.post.and.returnValue(mockApiResponse);
            //Act
            const myResponse = await service.codeRequest().toPromise();
            //Arrange

            expect(myResponse).toBeInstanceOf(EmptyModel)
        })
    })


})
