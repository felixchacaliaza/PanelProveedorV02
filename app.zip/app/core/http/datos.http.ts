import { Injectable } from "@angular/core";
import { BcpNetworking, BcpAdapter } from '@bcp/ng-core-v3/networking';
import { Observable } from 'rxjs';
import { environment } from '@src/environments/environment';
import { PersonModel, IPersonRequest } from '../models/data.model';
import { map, take } from 'rxjs/operators';
import { EmptyModel } from '../models/empty.model';
import { InititalDataModel, IInititalDataHttpRequest } from '../models/initial-data.model';

@Injectable()
export class DatosHttp extends BcpNetworking {

    @BcpAdapter(InititalDataModel, "data")
    initialData(request: IInititalDataHttpRequest): Observable<EmptyModel> {
      let url: string = `${environment.API_BCP_URL}${environment.API_UX_CAS}/initial-data`;
      return this.networking.post(url,request)
        .pipe(map(
          (data: InititalDataModel) => {
            return data ? data : {};
          }
        ), take(1));
    }
}