import { Injectable } from "@angular/core";
import { BcpSessionStorage } from '@bcp/ng-core-v3';

export interface IUser {
    names: string;
    personType: string;
    customerType?: string;
    ruc: string;
    isInConsist: boolean;
    personId: string;
    documentType: string;
}

@Injectable()
export class AuthService {

    constructor(
        private _bcpSessionStorage: BcpSessionStorage
    ) {

    }  

    getUser():IUser{        
        return this._bcpSessionStorage.get("mnbcp.usr") ? JSON.parse(this._bcpSessionStorage.get("mnbcp.usr")) : {}  ;
    }
}