import { Injectable } from "@angular/core";
import { IExceptionDetail } from '../interfaces/IException';



export interface YM {
    code: string;
    hasMessage: boolean;
}

const LIST_YM: YM[] = [
    { code: "YM0001", hasMessage: false },
    { code: "YM0007", hasMessage: true }
]

@Injectable()
export class ExceptionService {

    /**
     * Buscar una excepción controlada pero no es necesario verificar si tiene un mensaje personalizado
     * @param codeYM Es el código YM para los errores controlados. Ejemplo: YM0001
     * @param exceptions Es la lista de excepciones donde se buscará el YM del error controlado
     */
    findExceptionWithoutMsg(codeYM: string, exceptions: IExceptionDetail[]): IExceptionDetail {
        let exception: IExceptionDetail;
        exceptions.forEach((except: IExceptionDetail) => {
            if (except.code && except.code == codeYM) {
                exception = except;
            }
        })
        return exception;
    }

    /**
     * Buscar una excepción constrolada pero es necesario verificar que tenga un mensaje personalizado
     * @param codeYM Es el código YM para los errores controlados. Ejemplo: YM0001
     * @param exceptions Es la lista de excepciones donde se buscará el YM del error controlado
     */
    findExceptionWithMsg(codeYM: string, exceptions: IExceptionDetail[]): IExceptionDetail {
        let exception: IExceptionDetail;
        exceptions.forEach((except: IExceptionDetail) => {
            if (except.code && except.code == codeYM && except.description) {
                exception = except;
            }
        })
        return exception;
    }

    /**
     * Verifica si se tiene la propiedad 'exceptionDetails' en la respuesta de error
     * @param error Es el contenido de HttpErrorResponse.error
     */
    checkExceptionDetails(error: any): boolean {
        if (error.hasOwnProperty("exceptionDetails")) {
            if (error.exceptionDetails.length > 0) return true;
            else return false;
        } else return false;

    }

    findCustomException(exceptionDetails: IExceptionDetail[]): any {
        let customException: any;
        LIST_YM.forEach((ym: YM) => {
            if(ym.hasMessage){
                let exception = this.findExceptionWithMsg(ym.code,exceptionDetails);
                if(exception) customException = exception;
            }else{
                let exception = this.findExceptionWithoutMsg(ym.code,exceptionDetails);
                if(exception) customException = exception;
            }
        })

        return customException;
    }

}