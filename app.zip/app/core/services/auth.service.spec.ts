import { AuthService } from "./auth.service";
import { BcpSessionStorage } from '@bcp/ng-core-v3';

describe("@AuthService", () => {
    let service: AuthService;
    const StubBcpSessionStorage = jasmine.createSpyObj(BcpSessionStorage,["get","set"]);
    beforeEach(() => {
        service = new AuthService(StubBcpSessionStorage)
    })

    describe("#getUser",()=>{
        it("Should get data user",()=>{
            StubBcpSessionStorage.get.and.returnValue('{"names":"luis","personType":"N","customerType":"CL","ruc":"","isInConsist": true,"personId":"123","documentType":"1"}');

            const user = service.getUser();
            expect(user).toEqual({names: "luis",personType:"N",customerType:"CL",ruc:"",isInConsist: true,personId:"123",documentType:"1"})
        })
    })
})