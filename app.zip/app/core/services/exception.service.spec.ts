import { ExceptionService } from "./exception.service";

describe("@ExceptionService", () => {
    let service: ExceptionService;

    beforeEach(() => {
        service = new ExceptionService();
    })

    describe("#findExceptionWithoutMsg", () => {
        it("SHOULD find a exception without message WHEN the method is called", () => {
            let listExceptions = [
                { code: "YM0001", description: "error inesperado" }
            ]
            let find = service.findExceptionWithoutMsg("YM0001", listExceptions);
            expect(find).toEqual({ code: "YM0001", description: "error inesperado" })
        })
    })

    describe("#findExceptionWithMsg", () => {
        it("SHOULD find a exception without message WHEN the method is called", () => {
            let listExceptions = [
                { code: "YM0001", description: "error inesperado" }
            ]
            let find = service.findExceptionWithMsg("YM0001", listExceptions);
            expect(find).toEqual({ code: "YM0001", description: "error inesperado" })
        })
    })

    describe("#checkExceptionDetails", () => {
        it("SHOULD check exception details message WHEN the method is called", () => {

            let error = { exceptionDetails: [{ code: "YM0001", description: "error inesperado" }] }
            let find = service.checkExceptionDetails(error);
            expect(find).toBe(true)
        })

        it("SHOULD check exception details message WHEN the method is called", () => {

            let error = { exceptionDetails: [] }
            let find = service.checkExceptionDetails(error);
            expect(find).toBe(false)
        })

        it("SHOULD check exception details message WHEN the method is called", () => {

            let error = { }
            let find = service.checkExceptionDetails(error);
            expect(find).toBe(false)
        })
    })

    describe("#findCustomException", () => {
        it("SHOULD find custom exception WHEN the method is called", () => {
            let listExceptions = [
                { code: "YM0007", description: "error inesperado" }
            ]
            let find = service.findCustomException(listExceptions);
            expect(find).toEqual({ code: "YM0007", description: "error inesperado" })
        })

        it("Don't SHOULD to find custom exception WHEN the method is called", () => {
            let listExceptions = [
                { code: "YM0007", component: "bcp" }
            ]
            let find = service.findCustomException(listExceptions);
            expect(find).toEqual(undefined)
        })

        it("SHOULD find custom exception WHEN the method is called", () => {
            let listExceptions = [
                { code: "YM0001", component: "abcp" }
            ]
            let find = service.findCustomException(listExceptions);
            expect(find).toEqual({ code: "YM0001", component: "abcp" })
        })
    })

})