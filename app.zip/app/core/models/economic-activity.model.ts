export interface IEconomicActivityHttpResponse {
  code?: string;
  name?: string;
  status?: boolean;
}
export class EconomicActivityModel {
  value?: string;
  display?: string;
  status?: boolean;
  constructor(
    data: IEconomicActivityHttpResponse
  ) {
    this.value = data.code;
    this.display = data.name;
    this.status = data.status;
  }
}
