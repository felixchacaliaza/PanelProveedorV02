export interface ITypeCompanyHttpResponse {
  code?: string;
  name?: string;
}
export class TypeCompanyModel {
  code?: string;
  name?: string;

  constructor(
    data: ITypeCompanyHttpResponse
  ) {
    this.code = data.code;
    this.name = data.name;

  }
}
