export interface IRegisterCurrentAccountHttpRequest {
  termConditions?: boolean;
  dataVeracity?: boolean;

}

export interface IRegisterCurrentAccountHttpResponse {
  requestNumber?: string,
  account?: {
    accountType?: string,
    accountNumber?: string,
    currency?: string,
    cci?: string,
  },
  company?: { businessName?: string },
  legalRepresentative?: { email?: string },
  branchOffice?: { department?: string, district?: string }


}

export class RegisterCurrentAccountModel {
  requestNumber?: string;
  account?: {
    accountType?: string;
    accountNumber?: string;
    currency?: string;
    cci?: string;
  };
  company?: { businessName?: string };
  legalRepresentative?: { email?: string };
  branchOffice?: { department?: string, district?: string }
  constructor(
    data: IRegisterCurrentAccountHttpResponse
  ) {
    this.requestNumber = data.requestNumber;
    this.account = data.account;
    this.company = data.company;
    this.legalRepresentative = data.legalRepresentative;
    this.branchOffice = data.branchOffice;
  }
}
