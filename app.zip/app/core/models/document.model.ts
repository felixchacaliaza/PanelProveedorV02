export interface IDocumentResponse{
    content:string;
    mimetype:string;
    fileName:string;
}

export class DocumentModel{
    content:string = "";
    mimetype:string = "";
    fileName:string = "";

    constructor(
        data: IDocumentResponse
    ){
        this.content = data.content;
        this.mimetype = data.mimetype;
        this.fileName = data.fileName;
    }
}