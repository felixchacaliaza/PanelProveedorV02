export interface IValidationNegativeFileHttpResponse {

  client?: {
    status?: string
  };
}

export class ValidationNegativeFileModel {
  // client?: {
  //   status?: string
  // };
  status: "denied" | "next" | undefined;
  constructor(
    data: IValidationNegativeFileHttpResponse
  ) {
    {
      if (JSON.stringify(data) !== '{}') {
        this.status = "denied";
      }else{
        if(data == undefined || data == null) this.status = undefined;
        else this.status = "next";
      }

    }

  }
}
