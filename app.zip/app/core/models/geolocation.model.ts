export interface IGeolocationResponse {
    code: string;
    description: string;
}

export class GeolocationModel {
    code: string;
    description: string;
    constructor(data: IGeolocationResponse) {
        this.code = data.code;
        this.description = data.description;
    }
}