export interface IPreviewsHttpRequest {
  isPreview?: boolean;
  requestCode?: number;

}

export interface IPreviewsHttpResponse {
  documents?: [
    {
      content?: string;
      mimetype?: string;
      fileName?: string;
    }
  ]

}

export class PreviewsModel {

  content?: string;
  mimetype?: string;
  fileName?: string;

  constructor(
    data: IPreviewsHttpResponse
  ) {
    this.content = data.documents[0].content;
    this.mimetype = data.documents[0].mimetype;
    this.fileName = data.documents[0].fileName;
  }
}
