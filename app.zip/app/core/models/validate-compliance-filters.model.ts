import { IEmptyResponse } from "./empty.model";

export interface IValidateComplianceFiltersHttpRequest {
  filterQuestions?: string;
  pep?: string;
  singleUseStatement?: boolean;
  groupEconomic?: string;
  activityEconomic?: string;
}


export class ValidateComplianceFiltersModel {

  constructor(
    data: IEmptyResponse
  ) {

  }
}
