export interface IQualificationRequest{
    rating:number;
    comment:string;
}