export interface IBranchOfficeHttpResponse {
  region?: string;
  district?: [
    {
      description?: string,
      branchOfficeId?: string
    }
  ]

}

export class BranchOfficeModel {
  region?: string;
  district?: [
    {
      description?: string,
      branchOfficeId?: string
    }
  ]
  constructor(
    data: IBranchOfficeHttpResponse
  ) {
    this.region = data.region;
    this.district = data.district;

  }
}
