export interface IValidationPersonRequest {
    idc: string;
}