export interface ICatalogRequest {
    code: string;
}

export interface ICatalogResponse {
    code: string;
    name: string;
}

export interface IOccupationResponse {
    laborTypeId: string;
    description: string;
    registerDate: string;
}

export class CatalogModel {
    code: string;
    name: string;

    constructor(response: ICatalogResponse) {
        this.code = response.code;
        this.name = response.name;
    }
}

export class OccupationModel{
    code:string;
    name:string;
    constructor(data: IOccupationResponse){
        this.code = data.laborTypeId;
        this.name = data.description;
    }
}
