import { IEmptyResponse } from "./empty.model";

export interface IInititalDataHttpRequest {

  //customize account
  currency?: {
    code?: string;
  };
  branchOffice?: {
    id?: string;
    department?: string;
    district?: string;

  };

  // register personal data
  legalRepresentative?: {
    email?: string;
    phone?: string;
    occupation?: string;
    profession?: string;
    laborCenter?: string;
    address?: {
      department?: {
        description?: string;
        code?: string;
      },
      province?: {
        description?: string;
        code?: string;
      },
      district?: {
        description?: string;
        code?: string;
      },
      address?: string;
    }
  };

  // register company data

  company?: {
    businessName?: string;
    businessType?: string;
    socialCapital?: string;
    address?: {
      department?: {
        description?: string;
        code?: string;
      },
      province?: {
        description?: string;
        code?: string;
      },
      district?: {
        description?: string;
        code?: string;
      },
      address?: string;
    }
  };


  configuration?: {
    step?: 'ACCOUNT_STEP' | 'LEGAL_REPRESENTATIVE_STEP' | 'COMPANY_STEP';
  };



}


export class InititalDataModel {

  constructor(
    data: IEmptyResponse
  ) {

  }
}
