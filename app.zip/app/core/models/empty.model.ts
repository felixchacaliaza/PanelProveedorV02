export interface IEmptyResponse{

}

export interface IEmptyRequest{
    
}
export class EmptyModel{

    constructor(
        data: IEmptyResponse
    ){

    }    
}