export interface IBcpSelectAutoComplete {
  value?: string;
  display?: string;
}
