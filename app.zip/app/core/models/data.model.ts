export interface IPersonRequest{
    email:string;
    telephoneNumber:string;
    laborTypeId:string;
    professionCode:string;
    laborCenter:string;
    codeDepartment:string;
    codeProvince:string;
    codeDistrict:string;
    department:string;
    province:string;
    district:string;
    address:string;
}

export interface IPersonResponse{
    email:string;
    telephoneNumber:string;
    laborTypeId:string;
    professionCode:string;
    laborCenter:string;
    codeDepartment:string;
    codeProvince:string;
    codeDistrict:string;
    department:string;
    province:string;
    district:string;
    address:string;
}

export class PersonModel{
    email:string;
    telephoneNumber:string;
    laborTypeId:string;
    professionCode:string;
    laborCenter:string;
    codeDepartment:string;
    codeProvince:string;
    codeDistrict:string;
    department:string;
    province:string;
    district:string;
    address:string;

    constructor(
        data: IPersonResponse
    ){
        this.email = data.email;
        this.telephoneNumber = data.telephoneNumber;
        this.laborTypeId = data.laborTypeId;
        this.professionCode = data.professionCode;
        this.laborCenter = data.laborCenter;
        this.codeDepartment = data.codeDepartment;
        this.codeProvince = data.codeProvince;
        this.codeDistrict = data.codeDistrict;
        this.department = data.department;
        this.province = data.province;
        this.district = data.district;
        this.address = data.address;
    }
}