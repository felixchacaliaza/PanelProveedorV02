import { Injectable } from "@angular/core";
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Select, Store } from "@ngxs/store";
import { Observable } from "rxjs";
import { StepState, StepStateModel } from '@src/app/states/step.state';
import { StatePresenter } from "@src/app/states/state.presenter";

@Injectable()
export class FatcaPepGuard implements CanActivate{
    // stepState$ = this._store.select<StepStateModel>(StepState.currentState);
  stepState: StepStateModel;
    constructor(
      private router: Router,
      private _statePresenter : StatePresenter,
      private _store: Store
    ){
      // this.stepState$.subscribe(stepState => {
      //   this.stepState = stepState
      // });
      this._statePresenter.stepState$.subscribe(stepState => {
        this.stepState = stepState
      });
    }
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {

        if(this.stepState.onlyStep === 0){
          this.router.navigate(["cta-cte/informacion"])
          return false;
        }else {
          return true;
        }


    }

}
