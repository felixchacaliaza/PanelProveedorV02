import { ViewError } from './views/view-error/view-error';
import { FatcaPepGuard } from './core/guards/fatca-pep.guard';
import { NgModule } from '@angular/core';
import { RouterModule, Routes, CanActivate } from '@angular/router';
import { LayoutRoot } from './layouts/layout-root/layout-root';
import { ViewEvaluation } from './views/view-evaluation/view-evaluation';
import { ViewFatcaAndPEP } from './views/view-fatca-pep/view-fatca-pep.view';
import { ViewInfo } from './views/view-info/view-info';
import { ViewCustomize } from './views/view-customize/view-customize';
import { ViewPersonal } from './views/view-personal/view-personal';
import { ViewCompany } from './views/view-company/view-company';
import { ViewDetail } from './views/view-detail/view-detail';
import { ViewCongratulations } from './views/view-congratulations/view-congratulations';

const routes: Routes = [
  {
    path: "",
    redirectTo: "cta-cte",
    pathMatch: "full"
  },
  {
    path: "cta-cte",
    component: LayoutRoot,
    children: [
      {
        path: "",
        redirectTo: "evaluacion",
        pathMatch: "full"
      },
      {
        path: "evaluacion",
        component: ViewEvaluation,
        data: { title: "BCP Mi Negocio - Evaluación" }
      },
      {
        path: "error",
        component: ViewError,
        data: { title: "BCP Mi Negocio - Error" }
      },
      {
        path: "informacion",
        component: ViewInfo,
        data: { title: "BCP Mi Negocio - Información" }
      },
      {
        path: "fatca-pep",
        component: ViewFatcaAndPEP,
        canActivate:[FatcaPepGuard],
        data: { title: "BCP Mi Negocio - FATCA & PEP" }
      },
      {
        path: "personaliza",
        component: ViewCustomize,
        data: { title: "BCP Mi Negocio - Personaliza tu cuenta corriente" }
      },
      {
        path: "datos-personales",
        component: ViewPersonal,
        data: { title: "BCP Mi Negocio - Regitra tus datos personales" }
      },
      {
        path: "datos-negocio",
        component: ViewCompany,
        data: { title: "BCP Mi Negocio - Registra tus datos del negocio" }
      },
      {
        path: "detalle",
        component: ViewDetail,
        data: { title: "BCP Mi Negocio - Revisa los detalles de la cuenta" }
      },
      {
        path: "felicitaciones",
        component: ViewCongratulations,
        data: { title: "BCP Mi Negocio - La cuenta corriente ha sido creada"}
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
